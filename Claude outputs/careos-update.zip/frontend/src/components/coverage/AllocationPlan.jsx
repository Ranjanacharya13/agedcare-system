import { useMemo, useState } from "react";
import { useAuth } from "../../context/AuthContext.jsx";
import { suggestAssignments } from "../../api/algorithms.js";
import { createAssignmentsInBulk } from "../../api/assignments.js";
import { isAborted } from "../../api/client.js";
import Button from "../common/Button.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";
import HowItWorks from "../common/HowItWorks.jsx";

/**
 * Propose a primary carer for every resident who lacks one, then let a
 * person edit and confirm it.
 *
 * Three steps on purpose. The algorithm proposes, the user amends, and only
 * then is anything written — because the cost function knows about workload
 * and clinical scope and knows nothing about who a resident actually gets
 * on with. A plan that applied itself would be asking to be trusted about
 * something it cannot see.
 *
 * Run on demand rather than on page load: it is a computation over every
 * resident and every staff member, and a plan nobody asked for is a plan
 * nobody reads.
 *
 * This is also where the whole-set allocation earns its place. Filling each
 * gap with its own best candidate gives the first resident considered the
 * best carer and leaves the rest with whoever remains; allocating all of
 * them together accepts a slightly worse match for one resident when that
 * frees a much better one for another. The footnote states what that was
 * worth, so the claim is checkable rather than asserted.
 */
export const KEY_WORKER_STEPS = [
  {
    title: "Every resident without a key worker is compared with every staff member.",
    text: "Each pairing gets a cost — lower is a better match.",
  },
  {
    title: "Knowing the resident matters most.",
    text:
      "Someone who has written chart entries for this resident in the last 30 days already knows them, so the pairing costs less. A resident with dementia who settles with one carer should keep that carer.",
  },
  {
    title: "Then workload and clinical fit.",
    text:
      "The cost rises with how much the carer already carries (the risk scores of their residents, and how many), and with how unwell the resident is compared with what the carer's role can do — a critical resident needs a nurse more than a stable one does.",
  },
  {
    title: "Everyone is allocated together.",
    text:
      "Instead of giving each resident their own best match in turn, the Hungarian algorithm finds the combination with the lowest total cost for all of them. When two residents want the same carer, it works out who needs them more.",
  },
  {
    title: "You decide.",
    text: "Nothing is saved until you confirm, and you can change or untick any line first.",
  },
];

export default function AllocationPlan({ onApplied }) {
  const { can } = useAuth();
  const [plan, setPlan] = useState(null);
  const [choices, setChoices] = useState({});
  const [running, setRunning] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const run = async () => {
    setRunning(true);
    setError(null);
    try {
      const next = await suggestAssignments();
      setPlan(next);
      // The proposal seeds the form; from here the user's edits are the
      // truth, and re-running is what goes back to the algorithm's answer.
      setChoices(
        Object.fromEntries(
          next.suggestions.map((row) => [
            row.resident_id,
            { employeeId: row.employee_id || "", include: Boolean(row.employee_id) },
          ])
        )
      );
    } catch (err) {
      if (!isAborted(err)) setError(err);
    } finally {
      setRunning(false);
    }
  };

  const setChoice = (residentId, patch) =>
    setChoices((current) => ({
      ...current,
      [residentId]: { ...current[residentId], ...patch },
    }));

  const confirmed = useMemo(
    () =>
      Object.entries(choices)
        .filter(([, choice]) => choice.include && choice.employeeId)
        .map(([resident_id, choice]) => ({
          resident_id,
          employee_id: choice.employeeId,
          assignment_type: "Primary",
        })),
    [choices]
  );

  const confirm = async () => {
    setSaving(true);
    setError(null);
    try {
      const outcome = await createAssignmentsInBulk(confirmed);
      // The plan described a world that no longer exists — clear it rather
      // than leave rows on screen that have already been acted on. The
      // outcome is handed upwards rather than shown here, because the page
      // reloads its figures afterwards and this panel may legitimately
      // disappear with the last gap; the report of what happened must not
      // disappear with it.
      setPlan(null);
      setChoices({});
      onApplied?.(outcome);
    } catch (err) {
      if (!isAborted(err)) setError(err);
    } finally {
      setSaving(false);
    }
  };

  // Deciding staffing is a clinical call, so both the suggestion and the
  // confirmation are writes on the assignments group. A care worker can see
  // the gaps but not fill them, and offering a button that 403s is worse
  // than not offering it.
  if (!can("assignments", "write")) return null;

  return (
    <section className="algo-panel">
      <h2 className="section-title">Suggest a key worker for each</h2>
      <p className="text-muted">
        Proposes one primary carer for every resident above, preferring staff who already know them
        and spreading the load fairly. Change anyone you disagree with, untick anyone you are not
        ready to decide, then confirm.
      </p>

      <HowItWorks title="How are carers chosen?" steps={KEY_WORKER_STEPS} />

      <Button variant={plan ? "secondary" : "primary"} onClick={run} disabled={running || saving}>
        {running ? "Working it out…" : plan ? "Start again" : "Suggest key workers"}
      </Button>

      <ErrorBanner error={error} />
      {running && <Skeleton rows={4} />}

      {plan && !running && (
        <>
          {plan.suggestions.length === 0 ? (
            <p className="algo-note">
              Nothing to allocate &mdash; every active resident already has a primary carer.
            </p>
          ) : (
            <>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th className="plan-include-cell">Assign</th>
                      <th>Resident</th>
                      <th>Risk</th>
                      <th>Primary carer</th>
                      <th>Why</th>
                    </tr>
                  </thead>
                  <tbody>
                    {plan.suggestions.map((row) => (
                      <PlanRow
                        key={row.resident_id}
                        row={row}
                        choice={choices[row.resident_id]}
                        onChange={(patch) => setChoice(row.resident_id, patch)}
                      />
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="plan-actions">
                <Button onClick={confirm} disabled={saving || confirmed.length === 0}>
                  {saving
                    ? "Assigning…"
                    : `Confirm ${confirmed.length} assignment${confirmed.length === 1 ? "" : "s"}`}
                </Button>
                <span className="text-muted">
                  Creates each as the resident&rsquo;s <strong>primary</strong> carer, starting
                  today. Nothing is written until you confirm.
                </span>
              </div>

              <p className="algo-meta">
                {plan.residents_needing_a_carer} resident(s) matched against{" "}
                {plan.candidates_considered} staff member(s) in {plan.solve_ms} ms.{" "}
                {plan.unmatched_greedy > plan.unmatched_optimal ? (
                  <>
                    Taking each gap in turn would have left {plan.unmatched_greedy} resident(s)
                    with nobody, because the one carer still eligible for them would already have
                    gone to someone easier to match. This plan leaves{" "}
                    {plan.unmatched_optimal === 0 ? "none" : plan.unmatched_optimal}.
                  </>
                ) : plan.improvement_over_greedy > 0 ? (
                  <>
                    Filling each gap one at a time would have cost {plan.greedy_total_cost} on the
                    same measure of workload and clinical fit; this plan costs{" "}
                    {plan.optimal_total_cost} &mdash; a {percent(plan)}% better spread.
                  </>
                ) : (
                  <>
                    Nothing to trade off this time: with these residents and this staff list,
                    taking each gap in turn happens to give the same answer.
                  </>
                )}{" "}
                {plan.unmatched_optimal > 0 && (
                  <strong>
                    {plan.unmatched_optimal} resident(s) could not be matched at all &mdash; there
                    are not enough eligible staff.
                  </strong>
                )}
              </p>
            </>
          )}
        </>
      )}
    </section>
  );
}

/** One editable line of the plan. */
function PlanRow({ row, choice, onChange }) {
  const options = row.alternatives || [];
  const selected = options.find((c) => c.employee_id === choice?.employeeId);
  const changed = Boolean(row.employee_id) && choice?.employeeId !== row.employee_id;

  return (
    <tr className={choice?.include ? "" : "plan-row-skipped"}>
      <td className="plan-include-cell">
        <input
          type="checkbox"
          checked={Boolean(choice?.include)}
          disabled={options.length === 0}
          onChange={(event) => onChange({ include: event.target.checked })}
          aria-label={`Assign a carer to ${row.first_name} ${row.last_name}`}
        />
      </td>
      <td>
        {row.first_name} {row.last_name}
        {row.room_number && <small className="algo-subtle">Room {row.room_number}</small>}
      </td>
      <td>
        {row.risk_band ? (
          <StatusBadge value={row.risk_band} badgeKind="riskBand" />
        ) : (
          <span className="text-muted">&mdash;</span>
        )}
      </td>
      <td>
        {options.length === 0 ? (
          <span className="coverage-critical">Nobody available</span>
        ) : (
          <>
            <select
              className="plan-carer-select"
              value={choice?.employeeId || ""}
              onChange={(event) => onChange({ employeeId: event.target.value })}
              aria-label={`Primary carer for ${row.first_name} ${row.last_name}`}
            >
              {options.map((candidate) => (
                <option key={candidate.employee_id} value={candidate.employee_id}>
                  {candidate.first_name} {candidate.last_name}
                  {candidate.role ? ` · ${candidate.role}` : ""}
                </option>
              ))}
            </select>
            {/* Named rather than merely styled, so it is obvious on review
                which lines are the user's own decisions. */}
            {changed && <small className="algo-subtle">changed from suggestion</small>}
          </>
        )}
      </td>
      <td>
        <span className="suggestion-reason">{selected?.reason || row.reason}</span>
        {/* Where taking residents one at a time would have chosen someone
            else, say so on the row: that is the algorithm's whole case. */}
        {row.one_at_a_time_employee_id && row.one_at_a_time_employee_id !== row.employee_id && (
          <small className="one-at-a-time">
            One at a time, {row.first_name} would have got {row.one_at_a_time_employee_name}
            {" "}— their best match was already taken.
          </small>
        )}
      </td>
    </tr>
  );
}

/** What actually happened when the plan was confirmed. Rendered by the page
 *  rather than the panel, so it outlives the gaps it just filled. */
export function ApplyResult({ result }) {
  const created = result.created.length;
  // A batch where something was rejected is not a success, even if most of
  // it worked. Green with a red line inside it reads as "done" at a glance,
  // which is exactly the glance that would miss the resident still without
  // a carer.
  const tone = result.failed.length > 0 ? "plan-result has-failures" : "plan-result";

  return (
    <div className={tone} role="status">
      <p>
        <strong>
          {created} carer{created === 1 ? "" : "s"} assigned.
        </strong>{" "}
        {/* Only claim the whole job is done when it is. Saying "each
            resident now has a key worker" above a list of ones who do not
            is how a screen teaches people to stop reading it. */}
        {created > 0 &&
          result.failed.length === 0 &&
          "Each resident now has a named key worker on their care team."}
      </p>

      {result.failed.length > 0 && (
        <>
          <p className="coverage-critical">
            {result.failed.length} could not be assigned:
          </p>
          <ul className="plan-failures">
            {result.failed.map((failure) => (
              <li key={`${failure.resident_id}-${failure.employee_id}`}>{failure.reason}</li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

/** Improvement as a percentage of the naive plan's cost. Guarded because a
 *  zero-cost greedy plan (every carer idle) would otherwise divide by zero. */
function percent({ greedy_total_cost: greedy, improvement_over_greedy: gain }) {
  if (!greedy) return 0;
  return Math.round((gain / greedy) * 100);
}
