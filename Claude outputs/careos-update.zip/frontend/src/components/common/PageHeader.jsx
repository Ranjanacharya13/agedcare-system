/**
 * The top of every workspace page: a title, one line saying what the page is
 * for, and the page's own actions on the right. Consistent so that a person
 * moving between screens always knows where to look for "add" or "suggest".
 */
export default function PageHeader({ title, subtitle, actions, children }) {
  return (
    <header className="page-header">
      <div className="page-header-text">
        <h1 className="page-title">{title}</h1>
        {subtitle && <p className="page-header-subtitle">{subtitle}</p>}
      </div>
      {actions && <div className="page-header-actions">{actions}</div>}
      {children}
    </header>
  );
}
