import { Link } from "react-router-dom";

/**
 * One panel of an overview: a heading, a short body, and a link to the tab
 * where the full record lives. Overviews are for reading at a glance; the
 * link is how a reader gets from "something is off" to the detail.
 */
export default function InfoCard({ title, to, linkLabel = "Open", tone, children, className = "" }) {
  return (
    <section className={`info-card${tone ? ` info-card-${tone}` : ""} ${className}`.trim()}>
      <header className="info-card-header">
        <h3>{title}</h3>
        {to && (
          <Link to={to} className="info-card-link">
            {linkLabel} →
          </Link>
        )}
      </header>
      <div className="info-card-body">{children}</div>
    </section>
  );
}
