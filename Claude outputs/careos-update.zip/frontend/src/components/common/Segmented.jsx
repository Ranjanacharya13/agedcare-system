/**
 * A row of pill buttons: filters on a list, or the records inside one section
 * of a detail page. Deliberately lighter than the main tabs above it, so the
 * two levels read as "section" and "part of that section".
 */
export default function Segmented({ options, value, onChange, label }) {
  return (
    <div className="segmented" role="tablist" aria-label={label}>
      {options.map((option) => (
        <button
          key={option.key}
          type="button"
          role="tab"
          aria-selected={value === option.key}
          className={`segmented-option${value === option.key ? " is-active" : ""}`}
          onClick={() => onChange(option.key)}
        >
          {option.label}
          {option.count !== undefined && option.count !== null && (
            <span className="segmented-count">{option.count}</span>
          )}
        </button>
      ))}
    </div>
  );
}
