/** A compact two-column list of labelled facts. Empty values are skipped
 *  rather than shown as dashes, so a sparse record does not look broken. */
export default function KeyValue({ items }) {
  const shown = items.filter(([, value]) => value !== null && value !== undefined && value !== "");
  if (!shown.length) return null;
  return (
    <dl className="kv">
      {shown.map(([label, value]) => (
        <div key={label} className="kv-row">
          <dt>{label}</dt>
          <dd>{value}</dd>
        </div>
      ))}
    </dl>
  );
}
