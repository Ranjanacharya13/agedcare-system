/**
 * "How does this work?" — the algorithm explained in the place it runs,
 * in steps a care manager would recognise, closed until someone asks.
 *
 * The explanation lives beside the result on purpose. A suggestion people
 * cannot interrogate gets either rubber-stamped or ignored; one they can
 * check against what they know gets used properly.
 */
export default function HowItWorks({ title = "How does this work?", steps, children, open = false }) {
  return (
    <details className="how-it-works" open={open}>
      <summary>
        <span className="how-it-works-mark" aria-hidden="true">?</span>
        {title}
      </summary>
      <div className="how-it-works-body">
        {steps && (
          <ol className="how-it-works-steps">
            {steps.map((step, index) => (
              <li key={index}>
                {step.title && <strong>{step.title}</strong>}
                <span>{step.text}</span>
              </li>
            ))}
          </ol>
        )}
        {children}
      </div>
    </details>
  );
}
