import { useState } from "react";
import Button from "../common/Button.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";
import { EMPLOYEE_ROLE } from "../../config/enums.js";
import { createOpenShift } from "../../api/roster.js";
import { addDaysToKey, facilityInstant } from "../../utils/time.js";

// The three shifts almost every care home runs. Choosing one fills the
// times in; "Custom" leaves them editable.
const PATTERNS = [
  { key: "morning", label: "Morning 07:00–15:00", start: "07:00", end: "15:00" },
  { key: "evening", label: "Evening 15:00–23:00", start: "15:00", end: "23:00" },
  { key: "night", label: "Night 23:00–07:00", start: "23:00", end: "07:00" },
  { key: "custom", label: "Custom", start: "09:00", end: "17:00" },
];

// Times typed here are facility times, whatever the browser's own zone.
const combine = (day, clock) => facilityInstant(day, clock);

/**
 * Add a shift that needs someone: the date, the hours, and the kind of
 * person it needs. A shift ending at or before its start time runs past
 * midnight, which is what a night shift does.
 */
export default function OpenShiftForm({ defaultDay, onCreated, onCancel }) {
  const [day, setDay] = useState(defaultDay);
  const [pattern, setPattern] = useState("morning");
  const [start, setStart] = useState("07:00");
  const [end, setEnd] = useState("15:00");
  const [role, setRole] = useState("Registered Nurse");
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const choosePattern = (key) => {
    const chosen = PATTERNS.find((p) => p.key === key);
    setPattern(key);
    setStart(chosen.start);
    setEnd(chosen.end);
  };

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    setError(null);
    try {
      const shiftStart = combine(day, start);
      // Ending at or before the start means it runs past midnight.
      const shiftEnd = end <= start ? combine(addDaysToKey(day, 1), end) : combine(day, end);
      const created = await createOpenShift({
        shift_start: shiftStart.toISOString(),
        shift_end: shiftEnd.toISOString(),
        role,
        location: location || null,
        notes: notes || null,
      });
      onCreated(created);
    } catch (err) {
      setError(err);
      setSaving(false);
    }
  };

  return (
    <form className="resource-form" onSubmit={submit}>
      <ErrorBanner error={error} />
      <label className="form-field">
        <span className="form-field-label">Date<span className="required-mark">*</span></span>
        <input type="date" className="input-text" value={day} required onChange={(e) => setDay(e.target.value)} />
      </label>
      <label className="form-field">
        <span className="form-field-label">Shift</span>
        <select className="input-select" value={pattern} onChange={(e) => choosePattern(e.target.value)}>
          {PATTERNS.map((p) => (
            <option key={p.key} value={p.key}>
              {p.label}
            </option>
          ))}
        </select>
      </label>
      <div className="form-row">
        <label className="form-field">
          <span className="form-field-label">Starts</span>
          <input
            type="time"
            className="input-text"
            value={start}
            onChange={(e) => {
              setPattern("custom");
              setStart(e.target.value);
            }}
          />
        </label>
        <label className="form-field">
          <span className="form-field-label">Ends</span>
          <input
            type="time"
            className="input-text"
            value={end}
            onChange={(e) => {
              setPattern("custom");
              setEnd(e.target.value);
            }}
          />
        </label>
      </div>
      <label className="form-field">
        <span className="form-field-label">Needs</span>
        <select className="input-select" value={role} onChange={(e) => setRole(e.target.value)}>
          {EMPLOYEE_ROLE.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>
      </label>
      <label className="form-field">
        <span className="form-field-label">Where</span>
        <input className="input-text" value={location} placeholder="e.g. Wing A" onChange={(e) => setLocation(e.target.value)} />
      </label>
      <label className="form-field">
        <span className="form-field-label">Why it is needed</span>
        <textarea className="input-textarea" value={notes} onChange={(e) => setNotes(e.target.value)} />
      </label>
      <div className="resource-form-actions">
        <Button type="button" variant="secondary" onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button type="submit" disabled={saving}>
          {saving ? "Adding…" : "Add open shift"}
        </Button>
      </div>
    </form>
  );
}
