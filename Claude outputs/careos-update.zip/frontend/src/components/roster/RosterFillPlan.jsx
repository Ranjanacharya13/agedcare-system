import { useMemo, useState } from "react";
import { optimiseRoster, assignShifts } from "../../api/roster.js";
import { isAborted } from "../../api/client.js";
import Button from "../common/Button.jsx";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";
import HowItWorks from "../common/HowItWorks.jsx";
import { formatDayLabel, formatTimeRange } from "../../utils/format.js";

export const ROSTER_STEPS = [
  {
    title: "Only people who are free.",
    text: "Anyone already working a shift that overlaps is ruled out for that shift — no double-booking, ever.",
  },
  {
    title: "Everyone else gets a cost for each shift.",
    text:
      "Lower is better. It goes up with the hours they already have that week and the residents they are responsible for (their care load), and jumps sharply if the shift needs a role they do not hold.",
  },
  {
    title: "Then the whole week is solved at once.",
    text:
      "Instead of filling Tuesday, then Wednesday, then Thursday, the Hungarian algorithm finds the one allocation with the lowest total cost across every open shift. Filling in date order can give away the only nurse free on Thursday to Tuesday, and then Thursday has nobody suitable.",
  },
  {
    title: "Nothing is saved until you confirm.",
    text: "Change or untick any line first. The server checks every line again when you confirm.",
  },
];

/**
 * Suggest who should take each open shift this week, let a manager change
 * it, then write it. Mirrors the key-worker allocation on purpose: propose,
 * amend, confirm.
 */
export default function RosterFillPlan({ openShifts, onApplied, onClose }) {
  const [plan, setPlan] = useState(null);
  const [choices, setChoices] = useState({});
  const [running, setRunning] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const run = async () => {
    setRunning(true);
    setError(null);
    try {
      const result = await optimiseRoster(openShifts.map((s) => s.id));
      setPlan(result);
      setChoices(
        Object.fromEntries(
          result.assignments.map((a) => [
            a.shift_id,
            { employeeId: a.employee_id || "", include: Boolean(a.employee_id) },
          ])
        )
      );
    } catch (err) {
      if (!isAborted(err)) setError(err);
    } finally {
      setRunning(false);
    }
  };

  const shiftById = useMemo(() => Object.fromEntries(openShifts.map((s) => [s.id, s])), [openShifts]);
  const greedyById = useMemo(
    () => Object.fromEntries((plan?.greedy_assignments || []).map((g) => [g.shift_id, g])),
    [plan]
  );

  const confirmed = Object.entries(choices)
    .filter(([, c]) => c.include && c.employeeId)
    .map(([shift_id, c]) => ({ shift_id, employee_id: c.employeeId }));

  const confirm = async () => {
    setSaving(true);
    setError(null);
    try {
      const outcome = await assignShifts(confirmed);
      onApplied(outcome);
    } catch (err) {
      if (!isAborted(err)) setError(err);
      setSaving(false);
    }
  };

  const set = (id, patch) => setChoices((c) => ({ ...c, [id]: { ...c[id], ...patch } }));

  // The rows where filling in date order would have chosen differently —
  // shown side by side, because that difference *is* the argument for
  // solving the week as a whole.
  const differences = (plan?.assignments || []).filter(
    (a) => greedyById[a.shift_id] && greedyById[a.shift_id].employee_id !== a.employee_id
  );

  return (
    <section className="plan-panel">
      <div className="plan-panel-header">
        <div>
          <h2 className="section-title">Fill {openShifts.length} open shift{openShifts.length === 1 ? "" : "s"}</h2>
          <p className="text-muted">
            Suggests one person for each open shift this week, balancing hours and care load and
            never double-booking anyone. You review it before anything is saved.
          </p>
        </div>
        <Button variant="secondary" size="sm" onClick={onClose}>
          Close
        </Button>
      </div>

      <HowItWorks title="How are people chosen?" steps={ROSTER_STEPS} />

      {!plan && (
        <Button onClick={run} disabled={running}>
          {running ? "Working it out…" : "Suggest who takes each shift"}
        </Button>
      )}
      <ErrorBanner error={error} />
      {running && <Skeleton rows={4} />}

      {plan && !running && (
        <>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th className="plan-include-cell">Assign</th>
                  <th>Shift</th>
                  <th>Needs</th>
                  <th>Suggested</th>
                  <th>Why</th>
                </tr>
              </thead>
              <tbody>
                {plan.assignments.map((a) => {
                  const choice = choices[a.shift_id] || {};
                  const shift = shiftById[a.shift_id];
                  const picked = a.alternatives.find((c) => c.employee_id === choice.employeeId);
                  const changed = a.employee_id && choice.employeeId !== a.employee_id;
                  return (
                    <tr key={a.shift_id} className={choice.include ? "" : "plan-row-skipped"}>
                      <td className="plan-include-cell">
                        <input
                          type="checkbox"
                          checked={Boolean(choice.include)}
                          disabled={!a.alternatives.length}
                          onChange={(e) => set(a.shift_id, { include: e.target.checked })}
                          aria-label="Include this shift"
                        />
                      </td>
                      <td>
                        <span className="cell-stack">
                          <strong>{formatDayLabel(a.shift_start)}</strong>
                          <small>{formatTimeRange(a.shift_start, a.shift_end)}</small>
                          {shift?.notes && <small className="text-muted">{shift.notes}</small>}
                        </span>
                      </td>
                      <td>{a.shift_role || "Any role"}</td>
                      <td>
                        {a.alternatives.length ? (
                          <>
                            <select
                              className="plan-carer-select"
                              value={choice.employeeId || ""}
                              onChange={(e) => set(a.shift_id, { employeeId: e.target.value, include: true })}
                            >
                              {!choice.employeeId && <option value="">Choose…</option>}
                              {a.alternatives.map((c) => (
                                <option key={c.employee_id} value={c.employee_id}>
                                  {c.employee_name}
                                  {c.employee_role ? ` · ${c.employee_role}` : ""}
                                </option>
                              ))}
                            </select>
                            {changed && <small className="algo-subtle">changed from suggestion</small>}
                          </>
                        ) : (
                          <span className="coverage-critical">{a.unassigned_reason || "Nobody is free"}</span>
                        )}
                      </td>
                      <td>
                        <span className="suggestion-reason">{picked?.reason || a.reason || "—"}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="plan-actions">
            <Button onClick={confirm} disabled={saving || confirmed.length === 0}>
              {saving ? "Saving…" : `Confirm ${confirmed.length} shift${confirmed.length === 1 ? "" : "s"}`}
            </Button>
            <Button variant="secondary" onClick={run} disabled={saving}>
              Start again
            </Button>
          </div>

          <div className="compare-box">
            <p className="compare-title">
              {differences.length
                ? `Why not just fill them in date order? It would have gone differently on ${differences.length} shift${differences.length === 1 ? "" : "s"}:`
                : "Filling these in date order happens to give the same answer this time."}
            </p>
            {differences.length > 0 && (
              <ul className="compare-list">
                {differences.map((a) => {
                  const g = greedyById[a.shift_id];
                  return (
                    <li key={a.shift_id}>
                      <strong>
                        {formatDayLabel(a.shift_start)} {a.shift_role}
                      </strong>
                      <span>
                        date order → <em>{g.employee_name || "nobody"}</em>
                        {g.reason && g.reason.startsWith("not a") ? " (outside their role)" : ""}
                      </span>
                      <span>
                        whole week → <em>{a.employee_name || "nobody"}</em>
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
            <p className="algo-meta">
              Total cost {plan.comparison.optimal_total_cost} against {plan.comparison.greedy_total_cost} in
              date order
              {plan.comparison.percentage_saving > 0 && ` — ${plan.comparison.percentage_saving}% better`}. Solved
              in {plan.solve_ms} ms over {plan.shifts_considered} shifts × {plan.candidates_considered} staff.
            </p>
          </div>
        </>
      )}
    </section>
  );
}
