import { Outlet, useLocation } from "react-router-dom";
import Nav from "./Nav.jsx";

export default function AppShell() {
  const location = useLocation();

  return (
    <div className="app-shell">
      <Nav />
      <main className="app-content">
        {/* Keyed on the page, not the full path: switching tabs inside one
            resident or staff member should not remount and refetch the
            whole page, only a move to a different page should. */}
        <div key={location.pathname.split("/").slice(0, 4).join("/")} className="page-transition">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
