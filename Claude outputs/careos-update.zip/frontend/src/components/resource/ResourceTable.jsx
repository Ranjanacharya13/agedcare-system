import Table from "../common/Table.jsx";
import Button from "../common/Button.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import { useDirectory } from "../../hooks/useDirectory.js";
import { personLabel } from "../../hooks/useDirectory.js";
import {
  formatDate,
  formatDateTime,
  formatTime,
  formatBoolean,
  formatNumber,
  formatNpr,
  daysUntil,
} from "../../utils/format.js";

//: Long free text is cut in the table and shown in full when the row opens.
const TRUNCATE_AT = 70;

function truncate(text) {
  if (typeof text !== "string" || text.length <= TRUNCATE_AT) return text;
  return `${text.slice(0, TRUNCATE_AT).trimEnd()}…`;
}

function Expiry({ value }) {
  if (!value) return <span className="text-muted">No expiry</span>;
  const days = daysUntil(value);
  const label = formatDate(value);
  if (days < 0) return <span className="expiry expiry-past">{label} · expired</span>;
  if (days <= 60) return <span className="expiry expiry-soon">{label} · {days} days</span>;
  return <span>{label}</span>;
}

function Stars({ value }) {
  if (!value) return "—";
  return (
    <span className="stars" aria-label={`${value} out of 5`}>
      {"★".repeat(value)}
      <span className="stars-empty">{"★".repeat(5 - value)}</span>
    </span>
  );
}

/** Render one field's value for display. Shared by the table and the
 *  detail view, so a value looks the same in both. `full` skips truncation. */
export function renderValue(field, row, { residentsById, employeesById }, { full = false, format } = {}) {
  const value = row[field.name];
  if (format === "npr") return formatNpr(value);
  if (format === "expiry") return <Expiry value={value} />;
  if (format === "stars") return <Stars value={value} />;

  switch (field.type) {
    case "enum":
      return <StatusBadge value={value} badgeKind={field.badgeKind} />;
    case "boolean":
      return field.badgeKind ? (
        <StatusBadge value={value ? "true" : "false"} badgeKind={field.badgeKind} />
      ) : (
        formatBoolean(value)
      );
    case "date":
      return formatDate(value);
    case "datetime":
      return formatDateTime(value);
    case "time":
      return formatTime(value);
    case "number":
      return formatNumber(value);
    case "reference": {
      if (!value) return "—";
      if (field.reference.scope === "global") {
        const source = field.reference.resource === "residents" ? residentsById : employeesById;
        const person = source[value];
        return person ? personLabel(person, field.reference.labelFields) : "Unknown";
      }
      return "Linked";
    }
    case "textarea":
    case "text":
      if (value === null || value === undefined || value === "") return "—";
      return full ? value : truncate(value);
    default:
      return value ?? "—";
  }
}

export default function ResourceTable({
  resource,
  items,
  onOpen,
  onEdit,
  onDelete,
  onRowClick,
  extraRowActions,
  canWrite = true,
}) {
  const directory = useDirectory();

  // A config may name the few columns worth scanning; without one, fall back
  // to the first handful of short fields so a wide record never spills into
  // a dozen columns.
  const tableFields = resource.columns
    ? resource.columns.map((name) => resource.fields.find((f) => f.name === name)).filter(Boolean)
    : resource.fields
        .filter((f) => f.type !== "group" && f.showInTable !== false && f.type !== "textarea")
        .slice(0, 6);

  const showActions = canWrite || extraRowActions;

  const columns = [
    ...tableFields.map((field) => ({
      key: field.name,
      label: field.label,
      render: (row) => renderValue(field, row, directory, { format: resource.formats?.[field.name] }),
    })),
    ...(resource.timestampField && !resource.columns?.includes(resource.timestampField)
      ? [
          {
            key: resource.timestampField,
            label: "Recorded",
            render: (row) => formatDateTime(row[resource.timestampField]),
          },
        ]
      : []),
    ...(showActions
      ? [
          {
            key: "__actions",
            label: "",
            render: (row) => (
              <div className="row-actions" onClick={(e) => e.stopPropagation()}>
                {extraRowActions && extraRowActions(row)}
                {canWrite && (
                  <>
                    <Button variant="secondary" size="sm" onClick={() => onEdit(row)}>
                      Edit
                    </Button>
                    <Button variant="danger" size="sm" onClick={() => onDelete(row)}>
                      Delete
                    </Button>
                  </>
                )}
              </div>
            ),
          },
        ]
      : []),
  ];

  const rows = resource.sort ? [...items].sort(resource.sort) : items;

  return (
    <Table
      columns={columns}
      rows={rows}
      onRowClick={onRowClick || onOpen}
      emptyMessage={`No ${(resource.title || resource.label).toLowerCase()} recorded yet.`}
    />
  );
}
