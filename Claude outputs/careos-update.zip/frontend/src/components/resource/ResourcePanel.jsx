import { useState } from "react";
import { useApiResource } from "../../hooks/useApiResource.js";
import { useAuth } from "../../context/AuthContext.jsx";
import ResourceTable from "./ResourceTable.jsx";
import ResourceForm from "./ResourceForm.jsx";
import RecordDetail from "./RecordDetail.jsx";
import Modal from "../common/Modal.jsx";
import Button from "../common/Button.jsx";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";

// `onChanged` fires after any successful create/update/delete. Panels that
// sit under a summary of the same data (the resident care team) use it to
// re-read that summary, so the two halves of the screen cannot disagree.
//
// Clicking a row opens the whole record read-only; editing is a deliberate
// second step. Add, edit and delete are hidden — not disabled — for roles
// that cannot write this record's permission group: a button that can only
// fail teaches people that the screen is unreliable.
export default function ResourcePanel({
  resource,
  parentId,
  extraRowActions,
  onRowClick,
  hideAdd,
  onChanged,
  showDescription = false,
}) {
  const { can } = useAuth();
  const canWrite = !resource.group || can(resource.group, "write");
  const { items, loading, error, create, update, remove } = useApiResource(resource, parentId);
  const [editingRecord, setEditingRecord] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const name = resource.title ? resource.title.replace(/s$/, "") : resource.label;
  const noun = resource.label || name;

  const openCreate = () => {
    setEditingRecord(null);
    setShowForm(true);
  };
  const openEdit = (record) => {
    setViewing(null);
    setEditingRecord(record);
    setShowForm(true);
  };
  const closeForm = () => setShowForm(false);

  const handleSubmit = async (values) => {
    if (editingRecord) {
      await update(editingRecord.id, values);
    } else {
      await create(values);
    }
    setShowForm(false);
    onChanged?.();
  };

  const confirmDelete = async () => {
    await remove(deleteTarget.id);
    setDeleteTarget(null);
    onChanged?.();
  };

  return (
    <div className="resource-panel fade-slide-in">
      {(showDescription && resource.description) || (!hideAdd && canWrite) ? (
        <div className="resource-panel-header">
          {showDescription && resource.description && (
            <p className="resource-panel-description">{resource.description}</p>
          )}
          {!hideAdd && canWrite && (
            <Button variant="primary" size="sm" onClick={openCreate}>
              + Add {noun.toLowerCase()}
            </Button>
          )}
        </div>
      ) : null}

      <ErrorBanner error={error} />

      {loading ? (
        <Skeleton rows={3} />
      ) : (
        <ResourceTable
          resource={resource}
          items={items}
          onOpen={setViewing}
          onEdit={openEdit}
          onDelete={setDeleteTarget}
          onRowClick={onRowClick}
          extraRowActions={extraRowActions}
          canWrite={canWrite}
        />
      )}

      {viewing && (
        <Modal
          title={`${noun} details`}
          onClose={() => setViewing(null)}
          footer={
            canWrite ? (
              <>
                <Button variant="danger" onClick={() => { setDeleteTarget(viewing); setViewing(null); }}>
                  Delete
                </Button>
                <Button variant="primary" onClick={() => openEdit(viewing)}>
                  Edit
                </Button>
              </>
            ) : null
          }
        >
          <RecordDetail resource={resource} record={viewing} />
        </Modal>
      )}

      {showForm && (
        <Modal title={`${editingRecord ? "Edit" : "Add"} ${noun.toLowerCase()}`} onClose={closeForm}>
          <ResourceForm
            resource={resource}
            record={editingRecord}
            parentId={parentId}
            onSubmit={handleSubmit}
            onCancel={closeForm}
          />
        </Modal>
      )}

      {deleteTarget && (
        <Modal
          title={`Delete this ${noun.toLowerCase()}?`}
          onClose={() => setDeleteTarget(null)}
          footer={
            <>
              <Button variant="secondary" onClick={() => setDeleteTarget(null)}>
                Cancel
              </Button>
              <Button variant="danger" onClick={confirmDelete}>
                Delete
              </Button>
            </>
          }
        >
          <p>This can&rsquo;t be undone. The change is recorded in the audit log.</p>
        </Modal>
      )}
    </div>
  );
}
