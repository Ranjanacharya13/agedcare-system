import { useCallback } from "react";
import { Link } from "react-router-dom";
import { useAsync } from "../../hooks/useAsync.js";
import { getRoster } from "../../api/roster.js";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";
import { formatTimeRange } from "../../utils/format.js";
import { addDaysToKey, facilityDayKey, facilityInstant } from "../../utils/time.js";

/** Who is working today, now first — the first thing a manager checks at
 *  handover. Open shifts today are shown too, because they are the gap. */
export default function TodayOnShift() {
  const load = useCallback((signal) => {
    const today = facilityDayKey();
    return getRoster(facilityInstant(today), facilityInstant(addDaysToKey(today, 1)), { signal });
  }, []);
  const { data, loading, error } = useAsync(load, [load]);
  const now = new Date();

  const shifts = (data || []).filter((s) => s.status !== "Cancelled");
  const onNow = shifts.filter((s) => new Date(s.shift_start) <= now && now < new Date(s.shift_end));
  const later = shifts.filter((s) => new Date(s.shift_start) > now);

  return (
    <section className="card fade-slide-in">
      <div className="card-heading">
        <h2>On shift today</h2>
        <Link to="/admin/roster" className="info-card-link">
          Roster →
        </Link>
      </div>
      <ErrorBanner error={error} />
      {loading ? (
        <Skeleton rows={4} />
      ) : (
        <>
          <p className="text-muted">
            {onNow.length} working now · {later.length} later today
          </p>
          <ul className="shift-list">
            {[...onNow, ...later].slice(0, 10).map((s) => (
              <li key={s.id} className="shift-row">
                <div>
                  {s.is_open ? (
                    <span className="coverage-critical">Open shift</span>
                  ) : (
                    <Link to={`/admin/employees/${s.employee_id}`} className="shift-employee">
                      {s.employee_name}
                    </Link>
                  )}
                  <span className="text-muted"> — {s.role || "Any role"}</span>
                </div>
                <div className="shift-time">{formatTimeRange(s.shift_start, s.shift_end)}</div>
                {onNow.includes(s) && <span className="on-shift-now">Now</span>}
              </li>
            ))}
          </ul>
        </>
      )}
    </section>
  );
}
