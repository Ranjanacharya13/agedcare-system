import { useState } from "react";
import Button from "../common/Button.jsx";
import Modal from "../common/Modal.jsx";
import ResourceForm from "../resource/ResourceForm.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { createResourceApi } from "../../api/resourceApi.js";
import { employeesConfig } from "../../config/employees.config.js";
import { formatShortDate, formatRelativeDay, initials } from "../../utils/format.js";

const employeesApi = createResourceApi(employeesConfig);

function tenure(hireDate) {
  if (!hireDate) return null;
  const years = (Date.now() - new Date(hireDate).getTime()) / (365.25 * 86400000);
  if (years < 1) return "less than a year";
  const whole = Math.floor(years);
  return `${whole} year${whole === 1 ? "" : "s"}`;
}

export default function EmployeeHeaderCard({ employee, summary, onUpdated }) {
  const { can } = useAuth();
  const [editing, setEditing] = useState(false);

  const handleSubmit = async (values) => {
    const updated = await employeesApi.update(employee.id, values);
    onUpdated(updated);
    setEditing(false);
  };

  return (
    <div className="header-card person-header fade-slide-in">
      <div className="header-card-body">
        <div className="avatar avatar-lg avatar-staff">{initials(employee.first_name, employee.last_name)}</div>
        <div className="header-card-main">
          <h1>
            {employee.first_name} {employee.last_name}
          </h1>
          <p className="person-header-facts">
            {[
              employee.role || "No role set",
              employee.employment_status,
              employee.hire_date && `with us ${tenure(employee.hire_date)} (since ${formatShortDate(employee.hire_date)})`,
            ]
              .filter(Boolean)
              .join(" · ")}
          </p>
          <div className="header-card-meta">
            {summary?.on_shift_now ? (
              <span className="on-shift-now">On shift now</span>
            ) : summary?.next_shift_start ? (
              <span className="text-muted">Next shift {formatRelativeDay(summary.next_shift_start)}</span>
            ) : null}
            {summary && summary.caseload > 0 && (
              <span className="badge badge-info">
                {summary.caseload} resident{summary.caseload === 1 ? "" : "s"}
                {summary.primary_for ? ` · key worker for ${summary.primary_for}` : ""}
              </span>
            )}
            {!employee.active && <StatusBadge value="Inactive" badgeKind="verified" />}
          </div>
          <p className="text-muted person-header-contact">
            {employee.phone && <a href={`tel:${employee.phone}`}>{employee.phone}</a>}
            {employee.phone && employee.email && " · "}
            {employee.email}
          </p>
        </div>
      </div>
      {can("employees", "write") && (
        <Button variant="secondary" size="sm" onClick={() => setEditing(true)}>
          Edit details
        </Button>
      )}

      {editing && (
        <Modal title="Edit staff member" onClose={() => setEditing(false)}>
          <ResourceForm
            resource={employeesConfig}
            record={employee}
            onSubmit={handleSubmit}
            onCancel={() => setEditing(false)}
          />
        </Modal>
      )}
    </div>
  );
}
