import { useState } from "react";
import Button from "../common/Button.jsx";
import Modal from "../common/Modal.jsx";
import ResourceForm from "../resource/ResourceForm.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { createResourceApi } from "../../api/resourceApi.js";
import { residentsConfig } from "../../config/residents.config.js";
import { ageFrom, formatShortDate, initials } from "../../utils/format.js";

const residentsApi = createResourceApi(residentsConfig);

/**
 * Who this is, in the order a carer needs it: name and room, then how
 * at-risk they are and who their key worker is, then who to call. It stays
 * visible on every tab so the context never scrolls away.
 */
export default function ResidentHeaderCard({ resident, risk, careTeam, onUpdated }) {
  const { can } = useAuth();
  const [editing, setEditing] = useState(false);

  const handleSubmit = async (values) => {
    const updated = await residentsApi.update(resident.id, values);
    onUpdated(updated);
    setEditing(false);
  };

  const age = ageFrom(resident.dob);
  const primary = careTeam?.members?.find((m) => m.active && m.assignment_type === "Primary");
  const contact = resident.emergency_contact;

  return (
    <div className="header-card person-header fade-slide-in">
      <div className="header-card-body">
        <div className="avatar avatar-lg">{initials(resident.first_name, resident.last_name)}</div>
        <div className="header-card-main">
          <h1>
            {resident.first_name} {resident.last_name}
          </h1>
          <p className="person-header-facts">
            {[
              resident.room_number && `Room ${resident.room_number}`,
              age !== null && `${age} years`,
              resident.gender,
              resident.admission_date && `here since ${formatShortDate(resident.admission_date)}`,
            ]
              .filter(Boolean)
              .join(" · ")}
          </p>
          <div className="header-card-meta">
            {risk && (
              <span className="risk-pill">
                <StatusBadge value={risk.band} badgeKind="riskBand" />
                <span className="risk-pill-score">risk {risk.score}/100</span>
              </span>
            )}
            {resident.cognitive_status && <span className="badge badge-neutral">{resident.cognitive_status}</span>}
            {careTeam &&
              (primary ? (
                <span className="person-header-keyworker">
                  Key worker <strong>{primary.first_name} {primary.last_name}</strong>
                  {primary.on_shift_now && <span className="on-shift-now"> on shift</span>}
                </span>
              ) : (
                <span className="coverage-critical">No key worker named</span>
              ))}
            {!resident.active && <StatusBadge value="Inactive" badgeKind="verified" />}
          </div>
          {contact?.name && (
            <p className="text-muted person-header-contact">
              Emergency contact: {contact.name}
              {contact.relationship && ` (${contact.relationship})`}
              {contact.phone && (
                <>
                  {" · "}
                  <a href={`tel:${contact.phone}`}>{contact.phone}</a>
                </>
              )}
            </p>
          )}
        </div>
      </div>
      {can("residents", "write") && (
        <Button variant="secondary" size="sm" onClick={() => setEditing(true)}>
          Edit details
        </Button>
      )}

      {editing && (
        <Modal title="Edit resident" onClose={() => setEditing(false)}>
          <ResourceForm
            resource={residentsConfig}
            record={resident}
            onSubmit={handleSubmit}
            onCancel={() => setEditing(false)}
          />
        </Modal>
      )}
    </div>
  );
}
