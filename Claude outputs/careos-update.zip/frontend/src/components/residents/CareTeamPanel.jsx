import { useCallback, useState } from "react";
import { Link } from "react-router-dom";
import { useAsync } from "../../hooks/useAsync.js";
import { getCareTeam } from "../../api/assignments.js";
import ResourcePanel from "../resource/ResourcePanel.jsx";
import SuggestedCarers from "./SuggestedCarers.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";
import { assignmentsConfig } from "../../config/assignments.config.js";
import { formatDateTime } from "../../utils/format.js";

/**
 * Who looks after this resident.
 *
 * Two halves on purpose: a read view that answers "who do I call right
 * now", and the standard CRUD panel below it for changing the team. The
 * read view comes from `/care-team`, which resolves names and live shift
 * state server-side — the raw assignment rows carry only ids, and rendering
 * them would mean a lookup per row in the browser.
 */
export default function CareTeamPanel({ residentId, onChanged }) {
  // Bumped after any edit so the summary above re-reads rather than going
  // stale against the table below it.
  const [version, setVersion] = useState(0);
  // The page header shows the key worker too, so it is told as well.
  const bump = () => {
    setVersion((v) => v + 1);
    onChanged?.();
  };

  const load = useCallback(
    (signal) => getCareTeam(residentId, { signal }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [residentId, version]
  );
  const { data, loading, error } = useAsync(load, [load]);

  return (
    <div className="care-team">
      {loading && <Skeleton rows={3} />}
      <ErrorBanner error={error} />

      {data && !loading && (
        <>
          {!data.has_primary && (
            <p className="coverage-warning" role="status">
              No primary carer assigned. Every resident should have one named key worker who
              knows them and is the family&rsquo;s point of contact.
            </p>
          )}

          {data.members.length > 0 && (
            <p className="text-muted care-team-summary">
              {data.members.filter((m) => m.active).length} active carer(s)
              {data.on_shift_count > 0
                ? ` · ${data.on_shift_count} on shift right now`
                : " · none currently on shift"}
            </p>
          )}

          <ul className="care-team-list">
            {data.members.map((member) => (
              <li
                key={member.assignment_id}
                className={`care-team-member${member.active ? "" : " is-ended"}`}
              >
                <span className="care-team-avatar" aria-hidden="true">
                  {member.first_name[0]}
                  {member.last_name[0]}
                </span>
                <span className="care-team-identity">
                  <Link to={`/admin/employees/${member.employee_id}`}>
                    {member.first_name} {member.last_name}
                  </Link>
                  <small>{member.role || "Role not set"}</small>
                </span>
                <StatusBadge value={member.assignment_type} badgeKind="assignmentType" />
                <span className="care-team-shift">
                  {member.on_shift_now ? (
                    <span className="on-shift-now">On shift now</span>
                  ) : member.next_shift_start ? (
                    <span className="text-muted">
                      Next: {formatDateTime(member.next_shift_start)}
                    </span>
                  ) : (
                    <span className="text-muted">No upcoming shift</span>
                  )}
                </span>
                {!member.active && <span className="text-muted">Ended</span>}
              </li>
            ))}
          </ul>
        </>
      )}

      <h3 className="section-title">Manage assignments</h3>
      {/* The ranking sits immediately above the form that acts on it, so the
          suggestion arrives at the moment of the decision rather than on a
          screen someone would have to think to visit. Held back until the
          care team is known, because whether this resident already has a key
          worker decides what a suggestion here would even mean. */}
      {data && (
        <SuggestedCarers
          residentId={residentId}
          version={version}
          hasPrimary={data.has_primary}
          onAssigned={bump}
        />
      )}
      {/* Keyed on the version so an assignment made from the suggestion
          above remounts the table below it. The panel owns its own fetch and
          has no refresh handle; remounting is blunt but it is the honest
          way to say "everything you were looking at has changed". */}
      <ResourcePanel
        key={version}
        resource={assignmentsConfig}
        parentId={residentId}
        onChanged={bump}
      />
    </div>
  );
}
