import { Link } from "react-router-dom";
import { useRecords } from "../../hooks/useRecords.js";
import { useDirectory, personLabel } from "../../hooks/useDirectory.js";
import {
  assistance,
  behaviour,
  fallRisk,
  incidents,
  medicalHistory,
  medicalInventory,
  medications,
  sleepChart,
} from "../../config/residentResourceConfigs.js";
import InfoCard from "../common/InfoCard.jsx";
import KeyValue from "../common/KeyValue.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import Skeleton from "../common/Skeleton.jsx";
import { daysUntil, formatDayLabel, formatShortDate, timeAgo } from "../../utils/format.js";
import { formatDayKey } from "../../utils/time.js";

const SIGNAL_LABELS = {
  fall_risk: "Fall risk",
  recent_incidents: "Recent incidents",
  assistance_level: "Assistance needed",
  cognitive_status: "Cognitive status",
  recent_behaviour: "Recent behaviour",
};

/** The body of a card: a skeleton while loading, a quiet line on failure or
 *  when there is nothing to show, otherwise the content. */
function CardBody({ state, empty, children }) {
  if (state.loading) return <Skeleton rows={2} />;
  if (state.error) return <p className="text-muted">Not available.</p>;
  if (!state.data || (Array.isArray(state.data) && state.data.length === 0)) {
    return <p className="text-muted">{empty}</p>;
  }
  return children(state.data);
}

/**
 * A resident at a glance. Every card answers one question a carer walking
 * onto the floor would ask — how at-risk are they, who looks after them,
 * what are they taking, what are they allergic to, how did they sleep, what
 * has happened recently — and links to the tab that holds the full record.
 */
export default function ResidentOverview({ residentId, risk, careTeam }) {
  const base = `/admin/residents/${residentId}`;
  const { employeesById } = useDirectory();
  const meds = useRecords(medications, residentId);
  const history = useRecords(medicalHistory, residentId);
  const mobility = useRecords(assistance, residentId, { limit: 1 });
  const falls = useRecords(fallRisk, residentId, { limit: 1 });
  const sleep = useRecords(sleepChart, residentId, { limit: 7 });
  const events = useRecords(incidents, residentId, { limit: 20 });
  const moods = useRecords(behaviour, residentId, { limit: 3 });
  const supplies = useRecords(medicalInventory, residentId);

  const who = (id) => personLabel(employeesById[id]) || "—";

  return (
    <div className="overview-grid">
      <InfoCard title="Risk" to={`${base}/risk-score`} linkLabel="How it's scored">
        {risk ? (
          <>
            <div className="overview-risk">
              <span className={`overview-risk-score overview-risk-${risk.band.toLowerCase()}`}>{risk.score}</span>
              <span>
                <StatusBadge value={risk.band} badgeKind="riskBand" />
                <small className="text-muted"> out of 100</small>
              </span>
            </div>
            <ul className="overview-signals">
              {Object.entries(risk.breakdown)
                .filter(([, item]) => item.points > 0)
                .sort(([, a], [, b]) => b.points - a.points)
                .slice(0, 3)
                .map(([key, item]) => (
                  <li key={key}>
                    <span>{SIGNAL_LABELS[key] || key}</span>
                    <span className="text-muted">{item.value}</span>
                    <strong>+{item.points}</strong>
                  </li>
                ))}
            </ul>
          </>
        ) : (
          <Skeleton rows={2} />
        )}
      </InfoCard>

      <InfoCard title="Care team" to={`${base}/care-team`} linkLabel="Manage">
        {!careTeam ? (
          <Skeleton rows={2} />
        ) : careTeam.members.filter((m) => m.active).length === 0 ? (
          <p className="coverage-critical">Nobody is assigned yet.</p>
        ) : (
          <ul className="overview-list">
            {careTeam.members
              .filter((m) => m.active)
              .map((m) => (
                <li key={m.assignment_id}>
                  <Link to={`/admin/employees/${m.employee_id}`}>
                    {m.first_name} {m.last_name}
                  </Link>
                  <StatusBadge value={m.assignment_type} badgeKind="assignmentType" />
                  {m.on_shift_now ? (
                    <span className="on-shift-now">On shift</span>
                  ) : (
                    <small className="text-muted">{m.role}</small>
                  )}
                </li>
              ))}
          </ul>
        )}
      </InfoCard>

      <InfoCard title="Medications" to={`${base}/medications`} linkLabel="All medications">
        <CardBody state={meds} empty="No medications on record.">
          {(rows) => {
            const current = rows.filter((m) => m.active !== false);
            return current.length ? (
              <ul className="overview-list overview-list-plain">
                {current.map((m) => (
                  <li key={m.id}>
                    <strong>{m.medication_name}</strong>
                    <span className="text-muted">
                      {[m.dosage, m.frequency].filter(Boolean).join(" · ")}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted">No current medications.</p>
            );
          }}
        </CardBody>
      </InfoCard>

      <InfoCard title="Health" to={`${base}/medical-history`} linkLabel="Medical history">
        <CardBody state={history} empty="No medical history recorded.">
          {(rows) => {
            const latest = rows[0];
            const allergic = latest.allergies && !/^none/i.test(latest.allergies);
            return (
              <>
                {allergic && <p className="allergy-alert">Allergy: {latest.allergies}</p>}
                <KeyValue
                  items={[
                    ["Diagnosis", latest.diagnosis],
                    ["Conditions", latest.chronic_conditions],
                    ["Allergies", allergic ? null : latest.allergies],
                    ["Doctor", latest.doctor_name],
                  ]}
                />
                {latest.notes && <p className="overview-note">{latest.notes}</p>}
              </>
            );
          }}
        </CardBody>
      </InfoCard>

      <InfoCard title="Mobility & falls" to={`${base}/assistance`} linkLabel="Mobility">
        <CardBody state={mobility} empty="No mobility assessment yet.">
          {(rows) => (
            <KeyValue
              items={[
                ["Assistance", <StatusBadge key="a" value={rows[0].assistance_level} />],
                ["Mobility", rows[0].mobility],
                ["Transfers", rows[0].transfer_notes],
                [
                  "Fall risk",
                  falls.data?.[0] ? (
                    <span key="f">
                      <StatusBadge value={falls.data[0].risk_level} badgeKind="riskBand" />{" "}
                      <small className="text-muted">assessed {formatShortDate(falls.data[0].assessment_date)}</small>
                    </span>
                  ) : null,
                ],
              ]}
            />
          )}
        </CardBody>
      </InfoCard>

      <InfoCard title="Last 7 nights" to={`${base}/sleep-chart`} linkLabel="Sleep chart">
        <CardBody state={sleep} empty="No sleep recorded this week.">
          {(rows) => {
            const nights = [...rows].sort((a, b) => (a.sleep_date > b.sleep_date ? 1 : -1));
            const average = nights.reduce((sum, n) => sum + (n.total_hours || 0), 0) / nights.length;
            return (
              <>
                <div className="sleep-bars" role="img" aria-label={`Average ${average.toFixed(1)} hours`}>
                  {nights.map((n) => (
                    <span key={n.id} className="sleep-bar" title={`${formatDayLabel(n.sleep_date)}: ${n.total_hours} h`}>
                      <span
                        className={`sleep-bar-fill${(n.total_hours || 0) < 6 ? " is-short" : ""}`}
                        style={{ height: `${Math.min((n.total_hours || 0) / 9, 1) * 100}%` }}
                      />
                      <small>{formatDayKey(n.sleep_date, { weekday: "narrow" })}</small>
                    </span>
                  ))}
                </div>
                <p className="text-muted">
                  Average {average.toFixed(1)} h
                  {nights.some((n) => n.disturbances) && " · disturbed nights recorded"}
                </p>
              </>
            );
          }}
        </CardBody>
      </InfoCard>

      <InfoCard title="Incidents" to={`${base}/incidents`} linkLabel="All incidents">
        <CardBody state={events} empty="No incidents on record.">
          {(rows) => (
            <ul className="overview-list overview-list-plain">
              {rows.slice(0, 3).map((i) => (
                <li key={i.id}>
                  <span className="cell-inline">
                    <StatusBadge value={i.severity} badgeKind="incidentSeverity" />
                    <strong>{i.incident_type}</strong>
                  </span>
                  <span className="text-muted">
                    {timeAgo(i.occurred_at)} · {i.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </InfoCard>

      <InfoCard title="Recent behaviour" to={`${base}/behaviour`} linkLabel="Behaviour chart">
        <CardBody state={moods} empty="Nothing recorded recently.">
          {(rows) => (
            <ul className="overview-list overview-list-plain">
              {rows.map((b) => (
                <li key={b.id}>
                  <span>{b.behaviour}</span>
                  <span className="text-muted">
                    {timeAgo(b.recorded_at)}
                    {b.recorded_by && ` · ${who(b.recorded_by)}`}
                    {b.outcome && ` · ${b.outcome}`}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </InfoCard>

      <InfoCard title="Supplies" to={`${base}/medical-inventory`} linkLabel="All supplies">
        <CardBody state={supplies} empty="No personal supplies recorded.">
          {(rows) => (
            <ul className="overview-list overview-list-plain">
              {rows.map((item) => {
                const days = daysUntil(item.expiry_date);
                return (
                  <li key={item.id}>
                    <span>
                      <strong>{item.item_name}</strong> <span className="text-muted">× {item.quantity} {item.unit}</span>
                    </span>
                    {days !== null && days <= 60 ? (
                      <span className={`expiry ${days < 0 ? "expiry-past" : "expiry-soon"}`}>
                        {days < 0 ? "expired" : `expires in ${days} days`}
                      </span>
                    ) : null}
                  </li>
                );
              })}
            </ul>
          )}
        </CardBody>
      </InfoCard>
    </div>
  );
}
