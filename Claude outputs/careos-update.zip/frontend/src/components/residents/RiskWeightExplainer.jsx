import { useAsync } from "../../hooks/useAsync.js";
import { getRiskWeightModel } from "../../api/algorithms.js";
import Skeleton from "../common/Skeleton.jsx";

/**
 * Where the risk weights come from.
 *
 * Mounted only when someone opens the disclosure on the risk card, so the
 * request costs nothing for the majority who never ask. The point is that a
 * nurse who disagrees with a score can see what the model thinks matters
 * before deciding whether to trust it — a number with no derivation behind it
 * gets either obeyed or dismissed, and both are wrong.
 */
export default function RiskWeightExplainer() {
  const { data, loading, error } = useAsync((signal) => getRiskWeightModel({ signal }), []);

  if (loading) return <Skeleton rows={4} />;
  if (error || !data) {
    return <p className="text-muted">The weighting could not be loaded just now.</p>;
  }

  return (
    <div className="weight-disclosure-body">
      <ol className="how-it-works-steps">
        <li>
          <strong>Five things are checked.</strong>
          <span>
            The latest fall-risk assessment, incidents in the last 90 days, how much help the
            resident needs to move, their cognitive status, and behaviour events in the last 30 days.
          </span>
        </li>
        <li>
          <strong>Each is scored from 0 to 1</strong>
          <span>for how serious it is — a high fall risk is 1, a medium one 0.5, no concerns 0.</span>
        </li>
        <li>
          <strong>Each is multiplied by how much it matters.</strong>
          <span>
            The weights below were not picked by hand: every pair of signals was compared once —
            &ldquo;how much more does a fall risk matter than behaviour?&rdquo; — and the Analytic
            Hierarchy Process turned those comparisons into weights that add up to 100.
          </span>
        </li>
        <li>
          <strong>Added up, that gives a score out of 100.</strong>
          <span>75 or more is Critical, 50 or more High, 25 or more Medium, otherwise Low.</span>
        </li>
      </ol>

      <ul className="algo-weight-list">
        {data.criteria.map((item) => (
          <li className="algo-weight" key={item.criterion}>
            <span className="algo-weight-name">{item.criterion.replaceAll("_", " ")}</span>
            <span className="algo-weight-bar">
              <span style={{ width: `${item.percentage}%` }} />
            </span>
            <span className="algo-weight-value">{item.percentage}%</span>
          </li>
        ))}
      </ul>

      <div className={`algo-verdict ${data.is_consistent ? "is-ok" : "is-bad"}`}>
        <strong>
          {data.is_consistent
            ? "The comparisons hold together"
            : "The comparisons contradict each other"}
        </strong>
        <span>
          Consistency ratio {data.consistency_ratio}, against a limit of{" "}
          {data.consistency_threshold}. This is a check on the judgements themselves: if fall risk
          was rated far above assistance, and assistance far above incidents, then fall risk must
          also come out well above incidents. A ratio over the limit means it did not, and the
          weights would not be safe to use.
        </span>
      </div>

      <p className="algo-subtle">{data.method}</p>
    </div>
  );
}
