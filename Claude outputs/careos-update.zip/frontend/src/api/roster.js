import { get, post } from "./client.js";

/** Every shift starting in [from, to), open ones included, names resolved.
 *  The week boundaries are the browser's, so "Monday" is local Monday. */
export const getRoster = (from, to, options) =>
  get(
    `/roster/shifts?from=${encodeURIComponent(from.toISOString())}&to=${encodeURIComponent(
      to.toISOString()
    )}`,
    options
  );

/** Add a shift nobody holds yet. */
export const createOpenShift = (body, options) => post("/roster/shifts", body, options);

/** Hungarian allocation of the given open shifts. Suggests only. */
export const optimiseRoster = (shiftIds, options) =>
  post("/roster/optimise", { shift_ids: shiftIds, max_candidates: 200 }, options);

/** Give open shifts to people. Resolves with {assigned, failed}. */
export const assignShifts = (assignments, options) =>
  post("/roster/assign", { assignments }, options);
