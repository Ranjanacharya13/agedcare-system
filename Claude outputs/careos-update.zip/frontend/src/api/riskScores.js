import { get } from "./client.js";

export const getRiskScores = (options) => get("/risk-scores?limit=1000", options);
export const getResidentRiskScore = (residentId, options) =>
  get(`/residents/${residentId}/risk-score`, options);
