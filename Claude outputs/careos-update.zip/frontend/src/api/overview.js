import { get } from "./client.js";

/** Every resident with risk band, key worker and counts — for the list page. */
export const getResidentOverview = (options) => get("/overview/residents", options);

/** Every staff member with caseload, hours and next shift — for the list page. */
export const getStaffOverview = (options) => get("/overview/staff", options);

/** Counts and a to-do list, already trimmed to what this user's role may see. */
export const getDashboard = (options) => get("/overview/dashboard", options);
