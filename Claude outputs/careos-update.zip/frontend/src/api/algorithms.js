import { get, post } from "./client.js";

/**
 * The algorithms are not a screen of their own — they run inside the
 * workflows they serve. These are the endpoints those workflows call.
 * (Roster optimisation lives in api/roster.js, beside the roster it fills.)
 */

/** Ranked carers for one resident, while adding a single assignment. */
export const getSuggestedCarers = (residentId, options) =>
  get(`/residents/${residentId}/suggested-carers?limit=5`, options);

/** One optimal allocation across every resident missing a primary carer. */
export const suggestAssignments = (options) =>
  post("/coverage/suggest-assignments", undefined, options);

/** How the risk weights were derived — shown inside the risk score card. */
export const getRiskWeightModel = (options) => get("/risk-weights", options);
