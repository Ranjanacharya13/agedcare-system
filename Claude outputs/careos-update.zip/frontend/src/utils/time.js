// Times are shown in the care home's timezone, not the viewer's.
//
// A roster that says a shift starts at 07:00 has to say 07:00 to the nurse
// in Kathmandu and to the manager checking it from abroad; otherwise the
// same shift reads as 11:15 in Sydney and 01:15 in London, and nobody can
// agree on what the roster says. Nepal has no daylight saving, but nothing
// here assumes that — offsets are looked up per instant.
//
// Set VITE_FACILITY_TIMEZONE in frontend/.env to use another IANA zone.

export const FACILITY_TIME_ZONE = import.meta.env.VITE_FACILITY_TIMEZONE || "Asia/Kathmandu";

const DAY = 86400000;
const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;

const partsFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: FACILITY_TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});

export function isDateOnly(value) {
  return typeof value === "string" && DATE_ONLY.test(value);
}

/** Wall-clock parts of an instant, as the facility sees it. */
export function facilityParts(value) {
  const out = {};
  for (const part of partsFormatter.formatToParts(new Date(value))) {
    if (part.type !== "literal") out[part.type] = Number(part.value);
  }
  if (out.hour === 24) out.hour = 0;
  return out;
}

const pad = (n) => String(n).padStart(2, "0");

/** "YYYY-MM-DD" of an instant (or a date-only string) in the facility. */
export function facilityDayKey(value = new Date()) {
  if (isDateOnly(value)) return value;
  const p = facilityParts(value);
  return `${p.year}-${pad(p.month)}-${pad(p.day)}`;
}

function offsetAt(instant) {
  const p = facilityParts(instant);
  const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return asUtc - Math.floor(instant.getTime() / 1000) * 1000;
}

/** The instant at which the facility's clock reads `clock` on `dayKey`. */
export function facilityInstant(dayKey, clock = "00:00") {
  const [y, m, d] = dayKey.split("-").map(Number);
  const [h, mi] = clock.split(":").map(Number);
  const guess = Date.UTC(y, m - 1, d, h, mi);
  const first = offsetAt(new Date(guess));
  let time = guess - first;
  const second = offsetAt(new Date(time));
  if (second !== first) time = guess - second;
  return new Date(time);
}

export function addDaysToKey(dayKey, n) {
  const [y, m, d] = dayKey.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

/** Monday of the facility week containing `dayKey`. */
export function mondayKey(dayKey = facilityDayKey()) {
  const [y, m, d] = dayKey.split("-").map(Number);
  const weekday = (new Date(Date.UTC(y, m - 1, d)).getUTCDay() + 6) % 7;
  return addDaysToKey(dayKey, -weekday);
}

export function daysBetweenKeys(from, to) {
  const toUtc = (key) => {
    const [y, m, d] = key.split("-").map(Number);
    return Date.UTC(y, m - 1, d);
  };
  return Math.round((toUtc(to) - toUtc(from)) / DAY);
}

/** Format a date-only key with the viewer's locale, without shifting it. */
export function formatDayKey(dayKey, options) {
  const [y, m, d] = dayKey.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString(undefined, { ...options, timeZone: "UTC" });
}

/** Options to add to any toLocale* call on an instant or a date-only value. */
export function zoneFor(value) {
  return { timeZone: isDateOnly(value) ? "UTC" : FACILITY_TIME_ZONE };
}
