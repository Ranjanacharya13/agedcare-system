import {
  FACILITY_TIME_ZONE,
  daysBetweenKeys,
  facilityDayKey,
  facilityParts,
  zoneFor,
} from "./time.js";

// Every date and time on screen goes through here, and every one is shown in
// the facility's timezone (utils/time.js). Date-only values ("2026-09-21")
// are formatted as the calendar date they name, never shifted by a zone.

export function formatDate(value) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString(undefined, zoneFor(value));
}

export function formatDateTime(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString(undefined, {
    ...zoneFor(value),
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
}

export function formatTime(value) {
  if (!value) return "—";
  return value.slice(0, 5);
}

export function formatBoolean(value) {
  if (value === null || value === undefined) return "—";
  return value ? "Yes" : "No";
}

export function formatNumber(value) {
  if (value === null || value === undefined) return "—";
  return String(value);
}

export function initials(firstName, lastName) {
  return `${(firstName || "?")[0]}${(lastName || "")[0] || ""}`.toUpperCase();
}

export function formatRelativeDay(value) {
  if (!value) return "—";
  const diffDays = daysBetweenKeys(facilityDayKey(), facilityDayKey(value));
  const time = formatClock(value);
  if (diffDays === 0) return `Today, ${time}`;
  if (diffDays === 1) return `Tomorrow, ${time}`;
  return new Date(value).toLocaleString(undefined, {
    timeZone: FACILITY_TIME_ZONE,
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
}

/** Value for a <input type="datetime-local">, in facility time. */
export function toDatetimeInputValue(value) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  const p = facilityParts(d);
  const pad = (n) => String(n).padStart(2, "0");
  return `${p.year}-${pad(p.month)}-${pad(p.day)}T${pad(p.hour)}:${pad(p.minute)}`;
}

// --- friendlier forms, used by the summary screens ---------------------------

export function formatShortDate(value) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString(undefined, {
    ...zoneFor(value),
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatDayLabel(value) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString(undefined, {
    ...zoneFor(value),
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}

export function formatClock(value) {
  if (!value) return "—";
  return new Date(value).toLocaleTimeString(undefined, {
    timeZone: FACILITY_TIME_ZONE,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
}

export function formatTimeRange(start, end) {
  return `${formatClock(start)}–${formatClock(end)}`;
}

/** "3 days ago", "in 2 days", "today" — for things people judge by recency. */
export function timeAgo(value) {
  if (!value) return "—";
  const days = daysBetweenKeys(facilityDayKey(value), facilityDayKey());
  if (days === 0) return "today";
  if (days === 1) return "yesterday";
  if (days === -1) return "tomorrow";
  if (days > 0) return `${days} days ago`;
  return `in ${-days} days`;
}

/** Whole days from today until `value` (negative when it has passed). */
export function daysUntil(value) {
  if (!value) return null;
  return daysBetweenKeys(facilityDayKey(), facilityDayKey(value));
}

export function ageFrom(dob) {
  if (!dob) return null;
  const [by, bm, bd] = dob.split("-").map(Number);
  const [ty, tm, td] = facilityDayKey().split("-").map(Number);
  return ty - by - (tm < bm || (tm === bm && td < bd) ? 1 : 0);
}

/** Nepali rupees, as money is shown on a Nepali payslip. */
export function formatNpr(value) {
  if (value === null || value === undefined) return "—";
  return `Rs ${Number(value).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}
