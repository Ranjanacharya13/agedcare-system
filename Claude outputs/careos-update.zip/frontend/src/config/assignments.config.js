import { ASSIGNMENT_TYPE } from "./enums.js";

// Care assignments are resident-scoped for editing (you add a carer *to* a
// resident), which is why this uses the standard parent-scoped shape and
// drops straight into ResourcePanel. Reading happens from both directions
// via the enriched care-team and caseload endpoints.
export const assignmentsConfig = {
  slug: "assignments",
  // Permission group (config/permissions.js) — decides who sees add/edit/delete.
  group: "assignments",
  label: "Assignment",
  parent: { resource: "residents" },
  timestampField: null,
  fields: [
    {
      name: "employee_id",
      label: "Staff Member",
      type: "reference",
      required: true,
      reference: {
        resource: "employees",
        scope: "global",
        labelFields: ["first_name", "last_name"],
      },
    },
    {
      name: "assignment_type",
      label: "Role on Care Team",
      type: "enum",
      options: ASSIGNMENT_TYPE,
      defaultValue: "Secondary",
      badgeKind: "assignmentType",
      required: true,
    },
    { name: "start_date", label: "Start Date", type: "date" },
    { name: "end_date", label: "End Date", type: "date" },
    { name: "active", label: "Active", type: "boolean", defaultValue: true },
    { name: "notes", label: "Notes", type: "textarea" },
  ],
};
