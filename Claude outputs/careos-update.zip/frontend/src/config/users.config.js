import { ACCESS_ROLE } from "./enums.js";

// Staff login accounts. Separate from employeesConfig on purpose: an employee
// is an HR record, a user is a way to sign in. Not every employee needs an
// account, and a family login will have no employee record at all.
export const usersConfig = {
  slug: "users",
  // Permission group (config/permissions.js) — decides who sees add/edit/delete.
  group: "users",
  label: "Account",
  parent: null,
  timestampField: null,
  fields: [
    { name: "email", label: "Email", type: "text", required: true },
    { name: "full_name", label: "Full Name", type: "text" },
    {
      name: "access_role",
      label: "Access Role",
      type: "enum",
      options: ACCESS_ROLE,
      required: true,
      badgeKind: "accessRole",
    },
    {
      name: "employee_id",
      label: "Linked Employee",
      type: "reference",
      reference: { scope: "global", resource: "employees", labelFields: ["first_name", "last_name"] },
    },
    {
      name: "password",
      label: "Initial Password",
      type: "text",
      required: true,
      // Set once, then never rendered again — changing it goes through the
      // reset action, which does not round-trip the existing value.
      createOnly: true,
      showInTable: false,
    },
    { name: "active", label: "Active", type: "boolean", defaultValue: true },
    { name: "last_login_at", label: "Last Sign-In", type: "datetime", readOnly: true },
  ],
};
