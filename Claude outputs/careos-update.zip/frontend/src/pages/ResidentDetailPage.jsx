import { useCallback, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAsync } from "../hooks/useAsync.js";
import { useAuth } from "../context/AuthContext.jsx";
import { createResourceApi } from "../api/resourceApi.js";
import { getResidentRiskScore } from "../api/riskScores.js";
import { getCareTeam } from "../api/assignments.js";
import { residentsConfig } from "../config/residents.config.js";
import { RESIDENT_SECTIONS, locate, visibleSections } from "../config/sections.js";
import ResidentHeaderCard from "../components/residents/ResidentHeaderCard.jsx";
import ResidentOverview from "../components/residents/ResidentOverview.jsx";
import RiskScoreCard from "../components/residents/RiskScoreCard.jsx";
import CareTeamPanel from "../components/residents/CareTeamPanel.jsx";
import ResourcePanel from "../components/resource/ResourcePanel.jsx";
import Tabs from "../components/common/Tabs.jsx";
import Segmented from "../components/common/Segmented.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";

const residentsApi = createResourceApi(residentsConfig);

/**
 * One resident. Five sections instead of thirteen tabs: an overview, the
 * care team, and three groups of records — health, daily care, safety —
 * arranged the way a care manager thinks about a person. Old deep links
 * (`/residents/:id/incidents`) still land on the right record.
 */
export default function ResidentDetailPage() {
  const { residentId, tab } = useParams();
  const navigate = useNavigate();
  const { can } = useAuth();
  const [resident, setResident] = useState(null);
  const [teamVersion, setTeamVersion] = useState(0);

  const loadResident = useCallback((signal) => residentsApi.getOne(residentId, { signal }), [residentId]);
  const { data: fetched, loading, error } = useAsync(loadResident, [loadResident]);

  // Loaded once here and shared: the header shows the band and key worker
  // on every tab, and the overview needs both too.
  const loadRisk = useCallback(
    (signal) => (can("analytics", "read") ? getResidentRiskScore(residentId, { signal }) : Promise.resolve(null)),
    [residentId, can]
  );
  const loadTeam = useCallback(
    (signal) => (can("assignments", "read") ? getCareTeam(residentId, { signal }) : Promise.resolve(null)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [residentId, can, teamVersion]
  );
  const { data: risk } = useAsync(loadRisk, [loadRisk]);
  const { data: careTeam } = useAsync(loadTeam, [loadTeam]);

  const sections = visibleSections(RESIDENT_SECTIONS, can);
  const { section, part } = locate(sections, tab);
  const current = resident || fetched;

  if (loading && !current) return <Skeleton rows={6} />;
  if (error) return <ErrorBanner error={error} />;
  if (!current) return null;

  const go = (segment) =>
    navigate(segment === "overview" ? `/admin/residents/${residentId}` : `/admin/residents/${residentId}/${segment}`);

  return (
    <div className="page">
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <Link to="/admin/residents">Residents</Link>
        <span aria-hidden="true">/</span>
        <span>
          {current.first_name} {current.last_name}
        </span>
      </nav>

      <ResidentHeaderCard resident={current} risk={risk} careTeam={careTeam} onUpdated={setResident} />

      <Tabs
        tabs={sections.map((s) => ({ key: s.key, label: s.label }))}
        activeKey={section.key}
        onChange={go}
      />

      <div className="tab-panel">
        {section.key === "overview" && <ResidentOverview residentId={residentId} risk={risk} careTeam={careTeam} />}
        {section.key === "care-team" && (
          <CareTeamPanel residentId={residentId} onChanged={() => setTeamVersion((v) => v + 1)} />
        )}

        {section.parts && (
          <>
            {section.parts.length > 1 && (
              <Segmented
                label={section.label}
                value={part.slug}
                onChange={go}
                options={section.parts.map((p) => ({ key: p.slug, label: p.title || p.label }))}
              />
            )}
            {part.slug === "risk-score" ? (
              <RiskScoreCard residentId={residentId} />
            ) : (
              <ResourcePanel key={part.slug} resource={part} parentId={residentId} showDescription />
            )}
          </>
        )}
      </div>
    </div>
  );
}
