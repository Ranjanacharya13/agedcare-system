import { useCallback, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useAsync } from "../hooks/useAsync.js";
import { useAuth } from "../context/AuthContext.jsx";
import { getRoster } from "../api/roster.js";
import PageHeader from "../components/common/PageHeader.jsx";
import Segmented from "../components/common/Segmented.jsx";
import Button from "../components/common/Button.jsx";
import Modal from "../components/common/Modal.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";
import OpenShiftForm from "../components/roster/OpenShiftForm.jsx";
import RosterFillPlan from "../components/roster/RosterFillPlan.jsx";
import { formatClock, formatShortDate } from "../utils/format.js";
import { addDaysToKey, facilityDayKey, facilityInstant, formatDayKey, mondayKey } from "../utils/time.js";

const ROLE_FILTERS = [
  { key: "all", label: "Everyone", roles: null },
  { key: "nursing", label: "Nurses", roles: ["Registered Nurse"] },
  { key: "care", label: "Carers", roles: ["Care Coordinator", "Care Planner"] },
  { key: "support", label: "Kitchen & laundry", roles: ["Kitchen Staff", "Laundry Staff"] },
  { key: "office", label: "Office", roles: ["Manager", "Administrator"] },
];

function parseWeek(value) {
  return mondayKey(value && /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : facilityDayKey());
}

/**
 * The week, day by day: who is on, and which shifts nobody holds yet. Open
 * shifts are filled here — by hand, or by asking the optimiser for the best
 * allocation across the whole week and then confirming it.
 */
export default function RosterPage() {
  const { can } = useAuth();
  const canPlan = can("roster_planning", "write");
  const [params, setParams] = useSearchParams();
  // Weeks are facility weeks: Monday 00:00 in the care home's timezone,
  // wherever the person looking at the roster happens to be.
  const weekKey = parseWeek(params.get("week"));
  const [version, setVersion] = useState(0);
  const [filter, setFilter] = useState("all");
  const [adding, setAdding] = useState(false);
  const [filling, setFilling] = useState(false);
  const [applied, setApplied] = useState(null);

  const load = useCallback(
    (signal) =>
      getRoster(facilityInstant(weekKey), facilityInstant(addDaysToKey(weekKey, 7)), { signal }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [weekKey, version]
  );
  const { data, loading, error } = useAsync(load, [load]);

  const shifts = useMemo(() => (data || []).filter((s) => s.status !== "Cancelled"), [data]);
  const roles = ROLE_FILTERS.find((f) => f.key === filter)?.roles;
  const visible = shifts.filter((s) => !roles || roles.includes(s.role));
  const openShifts = shifts.filter((s) => s.is_open);
  const upcomingOpen = openShifts.filter((s) => new Date(s.shift_end) > new Date());
  const people = new Set(shifts.filter((s) => !s.is_open).map((s) => s.employee_id));
  const hours = shifts
    .filter((s) => !s.is_open)
    .reduce((sum, s) => sum + (new Date(s.shift_end) - new Date(s.shift_start)) / 3600000, 0);

  const days = Array.from({ length: 7 }, (_, i) => addDaysToKey(weekKey, i));
  const today = facilityDayKey();

  const moveWeek = (offset) => {
    setParams({ week: addDaysToKey(weekKey, offset * 7) });
    setFilling(false);
    setApplied(null);
  };

  return (
    <div className="page">
      <PageHeader
        title="Roster"
        subtitle="Who is working when. Open shifts are rostered demand that nobody holds yet."
        actions={
          canPlan && (
            <>
              <Button variant="secondary" onClick={() => setAdding(true)}>
                + Open shift
              </Button>
              <Button onClick={() => setFilling(true)} disabled={!upcomingOpen.length}>
                Fill open shifts{upcomingOpen.length ? ` (${upcomingOpen.length})` : ""}
              </Button>
            </>
          )
        }
      />

      <div className="week-nav">
        <Button variant="secondary" size="sm" onClick={() => moveWeek(-1)} aria-label="Previous week">
          ‹ Previous
        </Button>
        <strong className="week-nav-label">
          {formatShortDate(weekKey)} – {formatShortDate(addDaysToKey(weekKey, 6))}
        </strong>
        <Button variant="secondary" size="sm" onClick={() => moveWeek(1)} aria-label="Next week">
          Next ›
        </Button>
        {weekKey !== mondayKey() && (
          <Button variant="secondary" size="sm" onClick={() => setParams({})}>
            This week
          </Button>
        )}
      </div>

      {data && (
        <p className="text-muted roster-summary">
          {shifts.length} shifts · {people.size} people rostered · {Math.round(hours)} hours
          {openShifts.length > 0 && (
            <>
              {" · "}
              <span className="coverage-critical">{openShifts.length} open</span>
            </>
          )}
        </p>
      )}

      {applied && (
        <div className={`plan-result${applied.failed.length ? " has-failures" : ""}`} role="status">
          <p>
            <strong>
              {applied.assigned.length} shift{applied.assigned.length === 1 ? "" : "s"} filled.
            </strong>
          </p>
          {applied.failed.length > 0 && (
            <>
              <p className="coverage-critical">{applied.failed.length} could not be filled:</p>
              <ul className="plan-failures">
                {applied.failed.map((f) => (
                  <li key={f.shift_id}>{f.reason}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}

      {filling && (
        <RosterFillPlan
          key={weekKey + version}
          openShifts={upcomingOpen}
          onClose={() => setFilling(false)}
          onApplied={(outcome) => {
            setApplied(outcome);
            setFilling(false);
            setVersion((v) => v + 1);
          }}
        />
      )}

      <Segmented
        label="Show"
        value={filter}
        onChange={setFilter}
        options={ROLE_FILTERS.map((f) => ({ key: f.key, label: f.label }))}
      />

      <ErrorBanner error={error} />
      {loading && !data ? (
        <Skeleton rows={6} />
      ) : (
        <div className="week-grid">
          {days.map((key) => {
            const dayShifts = visible
              .filter((s) => facilityDayKey(s.shift_start) === key)
              .sort((a, b) => new Date(a.shift_start) - new Date(b.shift_start));
            return (
              <section key={key} className={`week-day${key === today ? " is-today" : ""}`}>
                <header className="week-day-header">
                  <span>{formatDayKey(key, { weekday: "short" })}</span>
                  <strong>{Number(key.slice(8, 10))}</strong>
                </header>
                {dayShifts.length === 0 ? (
                  <p className="week-day-empty">—</p>
                ) : (
                  <ul className="week-day-shifts">
                    {dayShifts.map((s) => (
                      <li key={s.id} className={`roster-chip${s.is_open ? " is-open" : ""}`} title={s.notes || ""}>
                        <span className="roster-chip-time">
                          {formatClock(s.shift_start)}–{formatClock(s.shift_end)}
                        </span>
                        {s.is_open ? (
                          <span className="roster-chip-name">Open</span>
                        ) : (
                          <Link className="roster-chip-name" to={`/admin/employees/${s.employee_id}/shifts`}>
                            {s.employee_name}
                          </Link>
                        )}
                        <span className="roster-chip-role">{s.role}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            );
          })}
        </div>
      )}

      {adding && (
        <Modal title="Add an open shift" onClose={() => setAdding(false)}>
          <OpenShiftForm
            defaultDay={days.find((d) => d >= today) || days[0]}
            onCancel={() => setAdding(false)}
            onCreated={() => {
              setAdding(false);
              setVersion((v) => v + 1);
            }}
          />
        </Modal>
      )}
    </div>
  );
}
