import { useCallback, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAsync } from "../hooks/useAsync.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useDirectory } from "../hooks/useDirectory.js";
import { getStaffOverview } from "../api/overview.js";
import { createResourceApi } from "../api/resourceApi.js";
import { employeesConfig } from "../config/employees.config.js";
import PageHeader from "../components/common/PageHeader.jsx";
import SearchInput from "../components/common/SearchInput.jsx";
import Segmented from "../components/common/Segmented.jsx";
import Table from "../components/common/Table.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";
import Button from "../components/common/Button.jsx";
import Modal from "../components/common/Modal.jsx";
import ResourceForm from "../components/resource/ResourceForm.jsx";
import { formatRelativeDay } from "../utils/format.js";

const employeesApi = createResourceApi(employeesConfig);

// Filters by what someone does, grouped the way a roster is planned.
const ROLE_FILTERS = [
  { key: "all", label: "Everyone", roles: null },
  { key: "nursing", label: "Nurses", roles: ["Registered Nurse"] },
  { key: "care", label: "Carers", roles: ["Care Coordinator", "Care Planner"] },
  { key: "support", label: "Kitchen & laundry", roles: ["Kitchen Staff", "Laundry Staff"] },
  { key: "office", label: "Office", roles: ["Manager", "Administrator"] },
];

/**
 * Everyone employed here: what they do, whether they are on shift, how many
 * hours they have this week and how much they are carrying. Separate from
 * Login accounts — an employment record is not a way to sign in.
 */
export default function EmployeesListPage() {
  const navigate = useNavigate();
  const { can } = useAuth();
  const { refresh: refreshDirectory } = useDirectory();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [adding, setAdding] = useState(false);

  const load = useCallback((signal) => getStaffOverview({ signal }), []);
  const { data, loading, error } = useAsync(load, [load]);

  const counts = useMemo(
    () =>
      Object.fromEntries(
        ROLE_FILTERS.map((f) => [
          f.key,
          (data || []).filter((e) => !f.roles || f.roles.includes(e.role)).length,
        ])
      ),
    [data]
  );

  const rows = useMemo(() => {
    const roles = ROLE_FILTERS.find((f) => f.key === filter)?.roles;
    const needle = query.trim().toLowerCase();
    return (data || []).filter((e) => {
      if (roles && !roles.includes(e.role)) return false;
      if (!needle) return true;
      return [e.first_name, e.last_name, e.role, e.phone, e.email]
        .filter(Boolean)
        .some((v) => v.toLowerCase().includes(needle));
    });
  }, [data, query, filter]);

  const columns = [
    {
      key: "name",
      label: "Name",
      render: (e) => (
        <span className="cell-stack">
          <strong>
            {e.first_name} {e.last_name}
          </strong>
          <small>{[e.role, e.employment_status].filter(Boolean).join(" · ")}</small>
        </span>
      ),
    },
    {
      key: "shift",
      label: "Shift",
      render: (e) =>
        e.on_shift_now ? (
          <span className="on-shift-now">On shift now</span>
        ) : e.next_shift_start ? (
          <span className="text-muted">Next: {formatRelativeDay(e.next_shift_start)}</span>
        ) : (
          <span className="text-muted">Nothing rostered</span>
        ),
    },
    {
      key: "hours",
      label: "Hours this week",
      render: (e) => (e.hours_this_week ? `${e.hours_this_week} h` : <span className="text-muted">—</span>),
    },
    {
      key: "caseload",
      label: "Residents",
      render: (e) =>
        e.caseload ? (
          <span className="cell-stack">
            <span>
              {e.caseload} resident{e.caseload === 1 ? "" : "s"}
              {e.primary_for ? ` · key worker for ${e.primary_for}` : ""}
            </span>
            <small className="text-muted">risk load {e.risk_load}</small>
          </span>
        ) : (
          <span className="text-muted">—</span>
        ),
    },
    {
      key: "contact",
      label: "Contact",
      render: (e) => <span className="text-muted">{e.phone || "—"}</span>,
    },
  ];

  const create = async (values) => {
    const created = await employeesApi.create(values);
    setAdding(false);
    refreshDirectory();
    navigate(`/admin/employees/${created.id}`);
  };

  return (
    <div className="page">
      <PageHeader
        title="Staff"
        subtitle="Everyone employed here. Sign-in access is managed separately, under Login accounts."
        actions={
          can("employees", "write") && <Button onClick={() => setAdding(true)}>+ Add staff member</Button>
        }
      />

      <div className="list-toolbar">
        <SearchInput value={query} onChange={setQuery} placeholder="Search name, role or phone" />
        <Segmented
          label="Filter staff"
          value={filter}
          onChange={setFilter}
          options={ROLE_FILTERS.map((f) => ({ key: f.key, label: f.label, count: counts[f.key] }))}
        />
      </div>

      <ErrorBanner error={error} />
      {loading && !data ? (
        <Skeleton rows={8} />
      ) : (
        <Table
          columns={columns}
          rows={rows}
          onRowClick={(e) => navigate(`/admin/employees/${e.id}`)}
          emptyMessage={query || filter !== "all" ? "Nobody matches." : "No staff yet."}
        />
      )}

      {adding && (
        <Modal title="Add staff member" onClose={() => setAdding(false)}>
          <ResourceForm resource={employeesConfig} onSubmit={create} onCancel={() => setAdding(false)} />
        </Modal>
      )}
    </div>
  );
}
