import { useCallback, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAsync } from "../hooks/useAsync.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useDirectory } from "../hooks/useDirectory.js";
import { getResidentOverview } from "../api/overview.js";
import { createResourceApi } from "../api/resourceApi.js";
import { residentsConfig } from "../config/residents.config.js";
import PageHeader from "../components/common/PageHeader.jsx";
import SearchInput from "../components/common/SearchInput.jsx";
import Segmented from "../components/common/Segmented.jsx";
import Table from "../components/common/Table.jsx";
import StatusBadge from "../components/common/StatusBadge.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";
import Button from "../components/common/Button.jsx";
import Modal from "../components/common/Modal.jsx";
import ResourceForm from "../components/resource/ResourceForm.jsx";

const residentsApi = createResourceApi(residentsConfig);
const BANDS = ["Critical", "High", "Medium", "Low"];

/**
 * Everyone living here, with what a person scans the list for: where they
 * are, how at-risk they are, and who their key worker is. Opening a row is
 * for the detail; the list itself should answer "who needs attention".
 */
export default function ResidentsListPage() {
  const navigate = useNavigate();
  const { can } = useAuth();
  const { refresh: refreshDirectory } = useDirectory();
  const [query, setQuery] = useState("");
  const [band, setBand] = useState("all");
  const [adding, setAdding] = useState(false);

  const load = useCallback((signal) => getResidentOverview({ signal }), []);
  const { data, loading, error } = useAsync(load, [load]);

  const counts = useMemo(() => {
    const out = { all: data?.length ?? 0, "no-key-worker": 0 };
    for (const r of data || []) {
      out[r.risk_band] = (out[r.risk_band] || 0) + 1;
      if (!r.primary_carer_id) out["no-key-worker"] += 1;
    }
    return out;
  }, [data]);

  const rows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return (data || []).filter((r) => {
      if (band === "no-key-worker" && r.primary_carer_id) return false;
      if (BANDS.includes(band) && r.risk_band !== band) return false;
      if (!needle) return true;
      return [r.first_name, r.last_name, r.room_number, r.primary_carer_name]
        .filter(Boolean)
        .some((v) => v.toLowerCase().includes(needle));
    });
  }, [data, query, band]);

  const columns = [
    {
      key: "room",
      label: "Room",
      render: (r) => <span className="room-tag">{r.room_number || "—"}</span>,
    },
    {
      key: "name",
      label: "Resident",
      render: (r) => (
        <span className="cell-stack">
          <strong>
            {r.first_name} {r.last_name}
          </strong>
          <small>
            {[r.age && `${r.age} yrs`, r.gender, r.cognitive_status].filter(Boolean).join(" · ")}
          </small>
        </span>
      ),
    },
    {
      key: "risk",
      label: "Risk",
      render: (r) =>
        r.risk_band ? (
          <span className="cell-inline">
            <StatusBadge value={r.risk_band} badgeKind="riskBand" />
            <small className="text-muted">{r.risk_score}</small>
          </span>
        ) : (
          "—"
        ),
    },
    {
      key: "carer",
      label: "Key worker",
      render: (r) =>
        r.primary_carer_name ? (
          <span className="cell-stack">
            <span>{r.primary_carer_name}</span>
            <small className="text-muted">{r.care_team_size} on care team</small>
          </span>
        ) : (
          <span className="coverage-critical">None named</span>
        ),
    },
    {
      key: "meds",
      label: "Medications",
      render: (r) => r.active_medications || <span className="text-muted">None</span>,
    },
    {
      key: "incidents",
      label: "Open incidents",
      render: (r) =>
        r.open_incidents ? (
          <span className="badge badge-warning">{r.open_incidents} open</span>
        ) : (
          <span className="text-muted">—</span>
        ),
    },
  ];

  const create = async (values) => {
    const created = await residentsApi.create(values);
    setAdding(false);
    refreshDirectory();
    navigate(`/admin/residents/${created.id}`);
  };

  return (
    <div className="page">
      <PageHeader
        title="Residents"
        subtitle="Everyone living here — sorted by room. Risk is scored from each resident's own records."
        actions={
          can("residents", "write") && (
            <Button onClick={() => setAdding(true)}>+ Add resident</Button>
          )
        }
      />

      <div className="list-toolbar">
        <SearchInput value={query} onChange={setQuery} placeholder="Search name, room or key worker" />
        <Segmented
          label="Filter residents"
          value={band}
          onChange={setBand}
          options={[
            { key: "all", label: "All", count: counts.all },
            ...BANDS.map((b) => ({ key: b, label: b, count: counts[b] || 0 })),
            { key: "no-key-worker", label: "No key worker", count: counts["no-key-worker"] },
          ]}
        />
      </div>

      <ErrorBanner error={error} />
      {loading && !data ? (
        <Skeleton rows={8} />
      ) : (
        <Table
          columns={columns}
          rows={rows}
          onRowClick={(r) => navigate(`/admin/residents/${r.id}`)}
          emptyMessage={query || band !== "all" ? "No residents match." : "No residents yet."}
        />
      )}

      {adding && (
        <Modal title="Add resident" onClose={() => setAdding(false)}>
          <ResourceForm
            resource={residentsConfig}
            onSubmit={create}
            onCancel={() => setAdding(false)}
          />
        </Modal>
      )}
    </div>
  );
}
