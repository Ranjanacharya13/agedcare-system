import { useCallback } from "react";
import { useAsync } from "../hooks/useAsync.js";
import { useAuth } from "../context/AuthContext.jsx";
import { getDashboard } from "../api/overview.js";
import { facilityDayKey, formatDayKey } from "../utils/time.js";
import StatCard from "../components/dashboard/StatCard.jsx";
import AttentionList from "../components/dashboard/AttentionList.jsx";
import TodayOnShift from "../components/dashboard/TodayOnShift.jsx";
import RiskScoreLeaderboard from "../components/dashboard/RiskScoreLeaderboard.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";
import {
  IconAlert,
  IconCalendar,
  IconClock,
  IconComplaints,
  IconEmployees,
  IconResidents,
} from "../components/layout/Icons.jsx";

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

const BANDS = ["Critical", "High", "Medium", "Low"];

/**
 * Start of the day: how the facility stands, and what needs doing. Every
 * number is a link to the page where it can be acted on, and the list below
 * them is the same information as a to-do list, most urgent first.
 */
export default function DashboardPage() {
  const { displayName } = useAuth();
  const load = useCallback((signal) => getDashboard({ signal }), []);
  const { data, loading, error } = useAsync(load, [load]);

  const today = formatDayKey(facilityDayKey(), { weekday: "long", month: "long", day: "numeric" });
  const firstName = (displayName || "").split(" ")[0];

  return (
    <div className="page">
      <div className="dashboard-hero fade-slide-in">
        <p className="dashboard-hero-eyebrow">{today}</p>
        <h1 className="page-title dashboard-hero-title">
          {greeting()}
          {firstName && !firstName.includes("@") ? `, ${firstName}` : ""}
        </h1>
        <p className="text-muted">Here is how the home stands and what needs doing.</p>
      </div>

      <ErrorBanner error={error} />
      {loading && !data ? (
        <Skeleton rows={4} />
      ) : data ? (
        <>
          <div className="stat-grid">
            <StatCard
              icon={<IconResidents size={20} />}
              label="Residents"
              value={data.residents_total}
              tone="primary"
              to="/admin/residents"
            />
            {data.residents_without_primary !== null && (
              <StatCard
                icon={<IconAlert size={20} />}
                label="No key worker"
                value={data.residents_without_primary}
                tone={data.residents_without_primary ? "danger" : "primary"}
                to="/admin/coverage"
              />
            )}
            {data.staff_on_shift_now !== null && (
              <StatCard
                icon={<IconEmployees size={20} />}
                label="On shift now"
                value={data.staff_on_shift_now}
                tone="secondary"
                to="/admin/roster"
              />
            )}
            {data.open_shifts_next_14_days !== null && (
              <StatCard
                icon={<IconClock size={20} />}
                label="Open shifts"
                value={data.open_shifts_next_14_days}
                tone={data.open_shifts_next_14_days ? "danger" : "info"}
                to="/admin/roster"
              />
            )}
            {data.open_incidents !== null && (
              <StatCard
                icon={<IconAlert size={20} />}
                label="Open incidents"
                value={data.open_incidents}
                tone="info"
                to="/admin/residents"
              />
            )}
            {data.open_complaints !== null && (
              <StatCard
                icon={<IconComplaints size={20} />}
                label="Open complaints"
                value={data.open_complaints}
                tone="info"
                to="/admin/complaints"
              />
            )}
            {data.pending_appointments !== null && (
              <StatCard
                icon={<IconCalendar size={20} />}
                label="New enquiries"
                value={data.pending_appointments}
                tone="info"
                to="/admin/appointments"
              />
            )}
          </div>

          <div className="band-strip" aria-label="Residents by risk band">
            {BANDS.map((band) => (
              <span
                key={band}
                className={`band-strip-segment band-${band.toLowerCase()}`}
                style={{ flexGrow: data.residents_by_band[band] || 0 }}
                title={`${band}: ${data.residents_by_band[band] || 0}`}
              >
                {data.residents_by_band[band] ? `${band} ${data.residents_by_band[band]}` : ""}
              </span>
            ))}
          </div>

          <div className="dashboard-grid dashboard-grid-main">
            <section className="card fade-slide-in">
              <div className="card-heading">
                <h2>Needs attention</h2>
                <span className="text-muted">{data.attention.length} item{data.attention.length === 1 ? "" : "s"}</span>
              </div>
              <AttentionList items={data.attention} />
            </section>
            <div className="dashboard-side">
              <TodayOnShift />
              <RiskScoreLeaderboard />
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
