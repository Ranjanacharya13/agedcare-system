import { useCallback, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAsync } from "../hooks/useAsync.js";
import { useAuth } from "../context/AuthContext.jsx";
import { createResourceApi } from "../api/resourceApi.js";
import { getStaffOverview } from "../api/overview.js";
import { employeesConfig } from "../config/employees.config.js";
import { EMPLOYEE_SECTIONS, locate, visibleSections } from "../config/sections.js";
import EmployeeHeaderCard from "../components/employees/EmployeeHeaderCard.jsx";
import EmployeeOverview from "../components/employees/EmployeeOverview.jsx";
import ShiftSuggestionsModal from "../components/employees/ShiftSuggestionsModal.jsx";
import CaseloadPanel from "../components/employees/CaseloadPanel.jsx";
import ResourcePanel from "../components/resource/ResourcePanel.jsx";
import Button from "../components/common/Button.jsx";
import Tabs from "../components/common/Tabs.jsx";
import Segmented from "../components/common/Segmented.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";

const employeesApi = createResourceApi(employeesConfig);

/**
 * One staff member: an overview, the residents they look after, and three
 * groups of records — their roster, their employment, their credentials.
 * Employment and credentials are leadership-only and simply do not appear
 * for anyone else.
 */
export default function EmployeeDetailPage() {
  const { employeeId, tab } = useParams();
  const navigate = useNavigate();
  const { can } = useAuth();
  const [employee, setEmployee] = useState(null);
  const [suggestShiftId, setSuggestShiftId] = useState(null);

  const loadEmployee = useCallback((signal) => employeesApi.getOne(employeeId, { signal }), [employeeId]);
  const { data: fetched, loading, error } = useAsync(loadEmployee, [loadEmployee]);
  const loadSummary = useCallback((signal) => getStaffOverview({ signal }), []);
  const { data: summaries } = useAsync(loadSummary, [loadSummary]);
  const summary = summaries?.find((s) => s.id === employeeId);

  const sections = visibleSections(EMPLOYEE_SECTIONS, can);
  const { section, part } = locate(sections, tab);
  const current = employee || fetched;

  if (loading && !current) return <Skeleton rows={6} />;
  if (error) return <ErrorBanner error={error} />;
  if (!current) return null;

  const go = (segment) =>
    navigate(segment === "overview" ? `/admin/employees/${employeeId}` : `/admin/employees/${employeeId}/${segment}`);

  return (
    <div className="page">
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <Link to="/admin/employees">Staff</Link>
        <span aria-hidden="true">/</span>
        <span>
          {current.first_name} {current.last_name}
        </span>
      </nav>

      <EmployeeHeaderCard employee={current} summary={summary} onUpdated={setEmployee} />

      <Tabs tabs={sections.map((s) => ({ key: s.key, label: s.label }))} activeKey={section.key} onChange={go} />

      <div className="tab-panel">
        {section.key === "overview" && <EmployeeOverview employeeId={employeeId} />}
        {section.key === "caseload" && <CaseloadPanel employeeId={employeeId} />}

        {section.parts && (
          <>
            {section.parts.length > 1 && (
              <Segmented
                label={section.label}
                value={part.slug}
                onChange={go}
                options={section.parts.map((p) => ({ key: p.slug, label: p.title || p.label }))}
              />
            )}
            <ResourcePanel
              key={part.slug}
              resource={part}
              parentId={employeeId}
              showDescription
              extraRowActions={
                part.slug === "shifts" && can("roster_planning", "read")
                  ? (shift) =>
                      new Date(shift.shift_end) > new Date() ? (
                        <Button variant="secondary" size="sm" onClick={() => setSuggestShiftId(shift.id)}>
                          Who could cover?
                        </Button>
                      ) : null
                  : undefined
              }
            />
          </>
        )}
      </div>

      {suggestShiftId && (
        <ShiftSuggestionsModal shiftId={suggestShiftId} onClose={() => setSuggestShiftId(null)} />
      )}
    </div>
  );
}
