import { useCallback, useMemo } from "react";
import { useAsync } from "./useAsync.js";
import { createResourceApi } from "../api/resourceApi.js";

/**
 * One record type for one person, read-only — what an overview card needs.
 * Each card loads on its own, so one slow or forbidden table leaves a quiet
 * gap in the overview instead of blanking the whole page.
 */
export function useRecords(config, parentId, { limit = 100, enabled = true } = {}) {
  const api = useMemo(() => createResourceApi(config), [config]);
  const load = useCallback(
    (signal) => (enabled ? api.list({ parentId, limit, signal }) : Promise.resolve(null)),
    [api, parentId, limit, enabled]
  );
  return useAsync(load, [load]);
}
