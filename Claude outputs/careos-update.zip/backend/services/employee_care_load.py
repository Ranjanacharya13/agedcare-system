"""How much an employee is already carrying.

Care load is the sum of the risk scores of the residents an employee is
actively assigned to — primary, secondary or relief — and the resident count
alongside it. Three critical residents are a heavier load than six stable
ones, which is why the scores are summed rather than the heads counted.

This used to be *inferred*: before `resident_assignments` existed, the only
trace of who cared for whom was the author column on chart entries, so the
load was reconstructed from who had recently written about which resident.
That read as zero for most staff and rewarded people who charted less. Now
that assignments are recorded, the load comes from them — and the roster
optimiser and the shift suggestions, which both call this, weigh the same
responsibility the Coverage page shows.

Chart authorship is still used, for a different question: *familiarity* —
whether a carer already knows a resident. That lives in `carer_matching`.
"""

import asyncio

from supabase import AsyncClient

from backend.services.risk_scoring import RiskScoringService


async def get_employee_care_load(
    employee_id: str,
    client: AsyncClient,
    risk_scoring_service: RiskScoringService,
) -> tuple[float, int]:
    """(sum of assigned residents' risk scores, number of residents)."""
    response = await (
        client.table("resident_assignments")
        .select("resident_id")
        .eq("employee_id", employee_id)
        .eq("active", True)
        .execute()
    )
    resident_ids = {row["resident_id"] for row in response.data}
    if not resident_ids:
        return 0.0, 0

    results = await asyncio.gather(
        *(risk_scoring_service.get_resident_score(rid) for rid in resident_ids)
    )
    scores = [result.score for result in results if result is not None]
    return float(sum(scores)), len(resident_ids)
