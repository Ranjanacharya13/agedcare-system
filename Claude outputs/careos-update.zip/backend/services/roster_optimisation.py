"""Optimal roster assignment.

`shift_matching.py` answers "who could cover this one shift?" — a ranked
list for a human to choose from. This module answers the harder question:
"given these N unfilled shifts and these M available staff, which complete
allocation is best overall?"

Those are genuinely different problems. Filling each shift with its own
best-ranked candidate is locally optimal and globally not, because the best
candidate for shift A is often also the best for shift B, and whichever
shift is processed first takes them. The Hungarian algorithm minimises the
total across the whole allocation instead, and this service reports both so
the difference is measured rather than asserted.

Cost model
----------
cost(employee, shift) =
      CARE_LOAD_WEIGHT  * normalised recent care load
    + HOURS_WEIGHT      * normalised hours already rostered that week
    + ROLE_MISMATCH_PENALTY if the shift names a role the employee lacks
    + infinity          if the employee already works an overlapping shift

Both variable terms are normalised to [0, 1] before weighting, for the same
reason the risk score normalises its signals: care load is an unbounded sum
of 0-100 risk scores while weekly hours tops out around 40, so combining the
raw numbers would let care load silently dominate.

A hard conflict is infinity rather than a large number because it is a
constraint, not a preference — no amount of fairness saving justifies
double-booking a nurse.
"""

from __future__ import annotations

import asyncio
import math
import time
from datetime import datetime

from supabase import AsyncClient

from backend.algorithms.hungarian import greedy_assignment, solve_assignment
from backend.models.employee import Employee
from backend.models.employee_shift import EmployeeShift
from backend.repositories.base import SupabaseRepository
from backend.repositories.employee_repository import EmployeeRepository
from backend.schemas.roster import (
    RosterAssignmentOut,
    RosterCandidateOut,
    RosterComparisonOut,
    RosterOptimiseOut,
)
from backend.services.employee_care_load import get_employee_care_load
from backend.services.risk_scoring import RiskScoringService

#: Relative importance of the two soft objectives. Care load is weighted
#: higher than hours because spreading *risk* matters more than spreading
#: time — a carer with four high-risk residents is under more pressure than
#: one with six low-risk ones, even on identical hours.
CARE_LOAD_WEIGHT = 1.0
HOURS_WEIGHT = 0.6

#: Added when the shift names a role the employee does not hold. Large
#: enough to lose against any combination of the soft terms, small enough
#: that a mismatched body still beats an unfilled shift.
ROLE_MISMATCH_PENALTY = 5.0

#: What leaving a shift unfilled costs when comparing two allocations.
#: Must exceed the worst possible real assignment cost (1.0 + 0.6 + 5.0 =
#: 6.6) so that covering a shift badly always beats not covering it. Used
#: only for scoring the comparison — the algorithm already maximises
#: coverage, because a forbidden pair is priced above any real alternative.
UNFILLED_SHIFT_PENALTY = 10.0

#: Denominators for normalisation. Care load is a sum of 0-100 risk scores
#: over residents recently attended; 400 is roughly four high-risk
#: residents, at which point someone is fully loaded.
CARE_LOAD_SATURATION = 400.0
WEEKLY_HOURS_SATURATION = 40.0


class RosterOptimisationService:
    def __init__(self, client: AsyncClient, risk_scoring_service: RiskScoringService):
        self._client = client
        self._risk_scoring_service = risk_scoring_service
        self._employee_repository = EmployeeRepository(client)
        self._shift_repository = SupabaseRepository(
            client,
            "employee_shifts",
            EmployeeShift,
            order_column="shift_start",
            parent_field="employee_id",
        )

    # --- data gathering --------------------------------------------------

    async def _load_shifts(
        self,
        shift_ids: list[str] | None,
        from_date: datetime | None,
        to_date: datetime | None,
    ) -> list[EmployeeShift]:
        if shift_ids:
            shifts = await asyncio.gather(
                *(self._shift_repository.get_by_id(str(sid)) for sid in shift_ids)
            )
            return _chronological([s for s in shifts if s is not None])

        all_shifts = await self._shift_repository.list_all(0, 2000)
        selected = []
        for shift in all_shifts:
            # Only open shifts. Re-allocating shifts people already hold is a
            # different operation, and doing it silently because a date range
            # happened to include them would reshuffle a published roster.
            if shift.employee_id is not None:
                continue
            if from_date and shift.shift_start < from_date:
                continue
            if to_date and shift.shift_start > to_date:
                continue
            selected.append(shift)
        return _chronological(selected)

    async def _employee_profile(
        self, employee: Employee, week_key: tuple[int, int]
    ) -> dict:
        """Everything the cost function needs about one candidate, fetched
        once rather than once per shift — the whole point of building a
        matrix is that each cell is then arithmetic, not I/O."""
        shifts = await self._shift_repository.list_for_parent(str(employee.id), 0, 200)
        care_load, residents = await get_employee_care_load(
            str(employee.id), self._client, self._risk_scoring_service
        )
        week_hours = sum(
            (s.shift_end - s.shift_start).total_seconds() / 3600
            for s in shifts
            if s.shift_start.isocalendar()[:2] == week_key
        )
        return {
            "employee": employee,
            "shifts": shifts,
            "care_load": care_load,
            "residents": residents,
            "week_hours": week_hours,
        }

    # --- the cost matrix -------------------------------------------------

    def _cost(self, profile: dict, shift: EmployeeShift) -> tuple[float, dict]:
        employee = profile["employee"]

        conflict = any(
            other.shift_start < shift.shift_end and other.shift_end > shift.shift_start
            for other in profile["shifts"]
            if str(other.id) != str(shift.id)
        )
        if conflict:
            return math.inf, {
                "care_load": 0.0,
                "hours_this_week": 0.0,
                "role_mismatch": 0.0,
                "total": math.inf,
            }

        care_component = CARE_LOAD_WEIGHT * min(
            profile["care_load"] / CARE_LOAD_SATURATION, 1.0
        )
        hours_component = HOURS_WEIGHT * min(
            profile["week_hours"] / WEEKLY_HOURS_SATURATION, 1.0
        )
        mismatch = (
            ROLE_MISMATCH_PENALTY
            if shift.role and employee.role and str(employee.role) != shift.role
            else 0.0
        )
        total = care_component + hours_component + mismatch
        return total, {
            "care_load": round(care_component, 4),
            "hours_this_week": round(hours_component, 4),
            "role_mismatch": mismatch,
            "total": round(total, 4),
        }

    # --- entry point -----------------------------------------------------

    async def optimise(
        self,
        shift_ids: list[str] | None = None,
        from_date: datetime | None = None,
        to_date: datetime | None = None,
        max_candidates: int = 200,
    ) -> RosterOptimiseOut:
        shifts = await self._load_shifts(shift_ids, from_date, to_date)
        if not shifts:
            return _empty_result()

        week_key = shifts[0].shift_start.isocalendar()[:2]
        employees = await self._employee_repository.list_all(0, max_candidates)
        candidates = [e for e in employees if e.active]

        if not candidates:
            return _empty_result(shifts_considered=len(shifts))

        profiles = await asyncio.gather(
            *(self._employee_profile(e, week_key) for e in candidates)
        )

        # Rows are shifts, columns are employees. Rows <= columns is the
        # normal case (more staff than unfilled shifts); the solver handles
        # the reverse too, leaving the surplus shifts unassigned.
        cost_matrix: list[list[float]] = []
        components: list[list[dict]] = []
        for shift in shifts:
            row = []
            component_row = []
            for profile in profiles:
                value, parts = self._cost(profile, shift)
                row.append(value)
                component_row.append(parts)
            cost_matrix.append(row)
            components.append(component_row)

        started = time.perf_counter()
        optimal = solve_assignment(cost_matrix)
        greedy = greedy_assignment(cost_matrix)
        solve_ms = (time.perf_counter() - started) * 1000

        optimal_out = _to_assignments(
            shifts, profiles, optimal.rows_to_cols, cost_matrix, components, with_alternatives=True
        )
        greedy_out = _to_assignments(shifts, profiles, greedy.rows_to_cols, cost_matrix, components)

        differing = sum(
            1
            for a, b in zip(optimal.rows_to_cols, greedy.rows_to_cols)
            if a != b
        )

        total_shifts = len(shifts)
        unfilled_optimal = total_shifts - optimal.assigned_count
        unfilled_greedy = total_shifts - greedy.assigned_count
        optimal_effective = optimal.total_cost + unfilled_optimal * UNFILLED_SHIFT_PENALTY
        greedy_effective = greedy.total_cost + unfilled_greedy * UNFILLED_SHIFT_PENALTY

        saving = greedy_effective - optimal_effective
        percentage = (saving / greedy_effective * 100) if greedy_effective > 0 else 0.0

        return RosterOptimiseOut(
            shifts_considered=len(shifts),
            candidates_considered=len(candidates),
            matrix_rows=len(cost_matrix),
            matrix_cols=len(cost_matrix[0]),
            assignments=optimal_out,
            greedy_assignments=greedy_out,
            comparison=RosterComparisonOut(
                optimal_assignment_cost=round(optimal.total_cost, 4),
                greedy_assignment_cost=round(greedy.total_cost, 4),
                unfilled_shift_penalty=UNFILLED_SHIFT_PENALTY,
                unfilled_optimal=unfilled_optimal,
                unfilled_greedy=unfilled_greedy,
                optimal_total_cost=round(optimal_effective, 4),
                greedy_total_cost=round(greedy_effective, 4),
                absolute_saving=round(saving, 4),
                percentage_saving=round(percentage, 2),
                optimal_assigned=optimal.assigned_count,
                greedy_assigned=greedy.assigned_count,
                differing_shifts=differing,
            ),
            solve_ms=round(solve_ms, 3),
            cost_model={
                "care_load_weight": CARE_LOAD_WEIGHT,
                "hours_weight": HOURS_WEIGHT,
                "role_mismatch_penalty": ROLE_MISMATCH_PENALTY,
                "care_load_saturation": CARE_LOAD_SATURATION,
                "weekly_hours_saturation": WEEKLY_HOURS_SATURATION,
                "unfilled_shift_penalty": UNFILLED_SHIFT_PENALTY,
            },
        )


def _chronological(shifts: list[EmployeeShift]) -> list[EmployeeShift]:
    """Rows in date order.

    The optimal allocation does not depend on row order — that is the point
    of it. The greedy baseline does, when two cells cost the same, and date
    order is how a person actually fills a roster: Tuesday before Thursday.
    Sorting here makes the comparison reproducible and makes the greedy
    column mean "what you would have got by filling it in order".
    """
    return sorted(shifts, key=lambda shift: shift.shift_start)


#: How many other people to offer per shift when the plan is reviewed.
ALTERNATIVES_PER_SHIFT = 6


def _reason(profile: dict, parts: dict, shift: EmployeeShift) -> str:
    """Why this person, in words a rostering manager would use."""
    employee = profile["employee"]
    bits = []
    if parts.get("role_mismatch"):
        bits.append(f"not a {shift.role} — would be working outside their role")
    elif employee.role:
        bits.append(str(employee.role))
    bits.append(f"{round(profile['week_hours'])} h already rostered that week")
    if profile["residents"]:
        bits.append(
            f"responsible for {profile['residents']} resident(s), care load {round(profile['care_load'])}"
        )
    else:
        bits.append("no residents assigned")
    return "; ".join(bits)


def _to_assignments(
    shifts: list[EmployeeShift],
    profiles: list[dict],
    rows_to_cols: list[int | None],
    cost_matrix: list[list[float]],
    components: list[list[dict]],
    with_alternatives: bool = False,
) -> list[RosterAssignmentOut]:
    out = []
    for row, shift in enumerate(shifts):
        col = rows_to_cols[row] if row < len(rows_to_cols) else None

        alternatives = []
        if with_alternatives:
            ranked = sorted(
                (c for c in range(len(profiles)) if not math.isinf(cost_matrix[row][c])),
                key=lambda c: cost_matrix[row][c],
            )[:ALTERNATIVES_PER_SHIFT]
            if col is not None and col not in ranked:
                ranked.insert(0, col)
            for c in ranked:
                person = profiles[c]["employee"]
                alternatives.append(
                    RosterCandidateOut(
                        employee_id=person.id,
                        employee_name=f"{person.first_name} {person.last_name}",
                        employee_role=str(person.role) if person.role else None,
                        cost=round(cost_matrix[row][c], 4),
                        reason=_reason(profiles[c], components[row][c], shift),
                    )
                )

        if col is None:
            reachable = any(not math.isinf(value) for value in cost_matrix[row])
            out.append(
                RosterAssignmentOut(
                    shift_id=shift.id,
                    shift_start=shift.shift_start,
                    shift_end=shift.shift_end,
                    shift_role=shift.role,
                    unassigned_reason=(
                        "More shifts than available staff"
                        if reachable
                        else "Every candidate has a clashing shift"
                    ),
                    alternatives=alternatives,
                )
            )
            continue

        employee = profiles[col]["employee"]
        out.append(
            RosterAssignmentOut(
                shift_id=shift.id,
                shift_start=shift.shift_start,
                shift_end=shift.shift_end,
                shift_role=shift.role,
                employee_id=employee.id,
                employee_name=f"{employee.first_name} {employee.last_name}",
                employee_role=str(employee.role) if employee.role else None,
                cost=round(cost_matrix[row][col], 4),
                reason=_reason(profiles[col], components[row][col], shift),
                alternatives=alternatives,
            )
        )
    return out


def _empty_result(shifts_considered: int = 0) -> RosterOptimiseOut:
    return RosterOptimiseOut(
        shifts_considered=shifts_considered,
        candidates_considered=0,
        matrix_rows=0,
        matrix_cols=0,
        assignments=[],
        greedy_assignments=[],
        comparison=RosterComparisonOut(
            optimal_assignment_cost=0.0,
            greedy_assignment_cost=0.0,
            unfilled_shift_penalty=UNFILLED_SHIFT_PENALTY,
            unfilled_optimal=0,
            unfilled_greedy=0,
            optimal_total_cost=0.0,
            greedy_total_cost=0.0,
            absolute_saving=0.0,
            percentage_saving=0.0,
            optimal_assigned=0,
            greedy_assigned=0,
            differing_shifts=0,
        ),
        solve_ms=0.0,
        cost_model={},
    )
