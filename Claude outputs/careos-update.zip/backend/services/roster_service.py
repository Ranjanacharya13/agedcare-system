"""The roster as a week: who is on when, which shifts nobody holds yet, and
the write that fills them.

The optimiser (`roster_optimisation.py`) decides *who should* take each open
shift and writes nothing. This service is the other half — it shows the
week and applies whatever allocation a person approved, whether it came
from the optimiser or from their own judgement.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from fastapi import HTTPException, status
from supabase import AsyncClient

from backend.models.employee import Employee
from backend.models.employee_shift import EmployeeShift, ShiftStatus
from backend.repositories.base import SupabaseRepository
from backend.repositories.employee_repository import EmployeeRepository
from backend.schemas.roster import (
    OpenShiftCreate,
    RosterShiftOut,
    ShiftAssignmentFailure,
    ShiftAssignmentItem,
    ShiftAssignmentOut,
)


def _aware(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


def _overlaps(a: EmployeeShift, b: EmployeeShift) -> bool:
    return _aware(a.shift_start) < _aware(b.shift_end) and _aware(a.shift_end) > _aware(b.shift_start)


class RosterService:
    def __init__(self, client: AsyncClient):
        self._client = client
        self._shift_repository = SupabaseRepository(
            client,
            "employee_shifts",
            EmployeeShift,
            order_column="shift_start",
            parent_field="employee_id",
        )
        self._employee_repository = EmployeeRepository(client)

    # --- reading ----------------------------------------------------------

    async def list_between(self, start: datetime, end: datetime) -> list[RosterShiftOut]:
        response, employees = await asyncio.gather(
            self._client.table("employee_shifts")
            .select("*")
            .gte("shift_start", start.isoformat())
            .lt("shift_start", end.isoformat())
            .order("shift_start")
            .range(0, 1999)
            .execute(),
            self._employee_repository.list_all(0, 1000),
        )
        by_id = {str(e.id): e for e in employees}
        shifts = [EmployeeShift(**row) for row in response.data]
        shifts.sort(key=lambda s: _aware(s.shift_start))
        return [self._out(shift, by_id.get(str(shift.employee_id))) for shift in shifts]

    @staticmethod
    def _out(shift: EmployeeShift, employee: Employee | None) -> RosterShiftOut:
        return RosterShiftOut(
            id=shift.id,
            employee_id=shift.employee_id,
            employee_name=f"{employee.first_name} {employee.last_name}" if employee else None,
            employee_role=str(employee.role) if employee and employee.role else None,
            shift_start=shift.shift_start,
            shift_end=shift.shift_end,
            role=shift.role,
            location=shift.location,
            status=str(shift.status),
            notes=shift.notes,
            is_open=shift.employee_id is None,
        )

    # --- writing ----------------------------------------------------------

    async def create_open_shift(self, data: OpenShiftCreate) -> RosterShiftOut:
        if _aware(data.shift_end) <= _aware(data.shift_start):
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY, "A shift has to end after it starts"
            )
        shift = EmployeeShift(
            employee_id=None,
            shift_start=data.shift_start,
            shift_end=data.shift_end,
            role=data.role,
            location=data.location,
            notes=data.notes,
            status=ShiftStatus.SCHEDULED,
        )
        created = await self._shift_repository.create(shift)
        return self._out(created, None)

    async def assign(self, items: list[ShiftAssignmentItem]) -> ShiftAssignmentOut:
        """Give open shifts to people, one line at a time.

        Each line is checked against the database *and* against the lines
        before it in the same batch: two open night shifts handed to the
        same nurse would each look fine on their own. Sequential for the
        same reason as the carer confirmation — correctness is worth a few
        round-trips on a batch of a dozen.
        """
        assigned: list[RosterShiftOut] = []
        failed: list[ShiftAssignmentFailure] = []
        taken_in_batch: dict[str, list[EmployeeShift]] = {}

        for item in items:
            try:
                shift, employee = await self._check(item, taken_in_batch)
            except HTTPException as rejection:
                failed.append(
                    ShiftAssignmentFailure(
                        shift_id=item.shift_id,
                        employee_id=item.employee_id,
                        reason=str(rejection.detail),
                    )
                )
                continue

            updated = await self._shift_repository.update(
                str(shift.id),
                {
                    "employee_id": str(employee.id),
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                },
            )
            taken_in_batch.setdefault(str(employee.id), []).append(updated)
            assigned.append(self._out(updated, employee))

        return ShiftAssignmentOut(assigned=assigned, failed=failed)

    async def _check(
        self, item: ShiftAssignmentItem, taken_in_batch: dict[str, list[EmployeeShift]]
    ) -> tuple[EmployeeShift, Employee]:
        shift, employee = await asyncio.gather(
            self._shift_repository.get_by_id(str(item.shift_id)),
            self._employee_repository.get_by_id(str(item.employee_id)),
        )
        if shift is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "That shift no longer exists")
        if employee is None or not employee.active:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "That staff member is not active")
        if shift.employee_id is not None:
            holder = await self._employee_repository.get_by_id(str(shift.employee_id))
            name = f"{holder.first_name} {holder.last_name}" if holder else "someone else"
            raise HTTPException(
                status.HTTP_409_CONFLICT, f"This shift has already been given to {name}"
            )

        existing = await self._shift_repository.list_for_parent(str(employee.id), 0, 500)
        clash = next(
            (
                other
                for other in [*existing, *taken_in_batch.get(str(employee.id), [])]
                if other.status != ShiftStatus.CANCELLED and _overlaps(other, shift)
            ),
            None,
        )
        if clash is not None:
            # No clock time in the message: the server does not know which
            # timezone the reader is in, and a time in the wrong zone is
            # worse than none. The roster screen shows the clash in context.
            raise HTTPException(
                status.HTTP_409_CONFLICT,
                f"{employee.first_name} {employee.last_name} already has a shift that overlaps this one",
            )
        return shift, employee
