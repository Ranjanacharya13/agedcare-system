"""Read models for the screens that summarise many records at once.

The generic CRUD endpoints return one table at a time, which is right for
editing and wrong for scanning: a list of residents that shows neither their
risk nor who looks after them makes the reader open every row to find out.
These bundle what a person scans for, resolved on the server in a handful
of queries rather than one request per row from the browser.
"""

from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel


class ResidentSummaryOut(BaseModel):
    id: UUID
    first_name: str
    last_name: str
    room_number: str | None = None
    age: int | None = None
    gender: str | None = None
    cognitive_status: str | None = None
    admission_date: date | None = None
    active: bool = True
    risk_score: int | None = None
    risk_band: str | None = None
    primary_carer_id: UUID | None = None
    primary_carer_name: str | None = None
    care_team_size: int = 0
    active_medications: int = 0
    open_incidents: int = 0


class StaffSummaryOut(BaseModel):
    id: UUID
    first_name: str
    last_name: str
    role: str | None = None
    employment_status: str | None = None
    active: bool = True
    phone: str | None = None
    email: str | None = None
    caseload: int = 0
    primary_for: int = 0
    risk_load: int = 0
    hours_this_week: float = 0.0
    next_shift_start: datetime | None = None
    on_shift_now: bool = False


class AttentionItem(BaseModel):
    """One thing on the dashboard that someone should act on, with where to
    go to act on it. `link` is an app route, not an API path."""

    kind: str
    severity: str  # "high" | "medium" | "low"
    title: str
    detail: str | None = None
    link: str


class DashboardSummaryOut(BaseModel):
    residents_total: int = 0
    residents_by_band: dict[str, int] = {}
    residents_without_primary: int | None = None
    staff_active: int = 0
    staff_on_shift_now: int | None = None
    open_shifts_next_14_days: int | None = None
    open_incidents: int | None = None
    pending_leave: int | None = None
    expiring_credentials: int | None = None
    open_complaints: int | None = None
    pending_appointments: int | None = None
    #: Fields left as None are ones this user's role may not see — the
    #: screen hides the tile rather than showing a misleading zero.
    attention: list[AttentionItem] = []
