from datetime import datetime
from uuid import UUID

from pydantic import BaseModel

from backend.models.employee_shift import ShiftStatus


class ShiftCreate(BaseModel):
    shift_start: datetime
    shift_end: datetime
    role: str | None = None
    location: str | None = None
    status: ShiftStatus | None = ShiftStatus.SCHEDULED
    notes: str | None = None


class ShiftUpdate(BaseModel):
    shift_start: datetime | None = None
    shift_end: datetime | None = None
    role: str | None = None
    location: str | None = None
    status: ShiftStatus | None = None
    notes: str | None = None


class ShiftOut(BaseModel):
    id: UUID
    #: None for an open shift — rostered demand nobody has been given yet.
    #: The column has always been nullable; this schema used to insist on a
    #: value, which made the whole shift list fail with a 500 the moment a
    #: single open shift existed.
    employee_id: UUID | None = None
    shift_start: datetime
    shift_end: datetime
    role: str | None = None
    location: str | None = None
    status: ShiftStatus
    notes: str | None = None
    created_at: datetime
    updated_at: datetime
