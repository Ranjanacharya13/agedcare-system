"""Demonstration data for CareOS.

`dataset.build()` returns a complete, internally consistent facility — the
people, their records, and the relationships between them — as plain
Pydantic models. It touches no database. `backend/scripts/seed_dummy_data.py`
writes it to Supabase; the tests load it into in-memory fakes and check that
the algorithms behave the way the data was designed to make them behave.
"""
