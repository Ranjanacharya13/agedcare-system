"""An in-memory stand-in for the Supabase client, for tests that need the
real services end to end.

It implements the part of the PostgREST query builder this codebase uses —
select / eq / gte / is_ / not_ / in_ / order / range / maybe_single, and
insert / update / delete — against lists of JSON-shaped dicts. It is not a
database: no constraints, no joins. It exists so that a test can hand the
*real* risk scorer, carer matcher and roster optimiser the demo dataset and
check what they conclude, without Postgres.
"""

from __future__ import annotations

import copy
from datetime import date, datetime, timezone
from types import SimpleNamespace
from uuid import uuid4


def _comparable(value):
    """Dates, timestamps and plain values, made comparable with each other.

    Rows hold ISO strings in several shapes — a bare date, a timestamp in
    Nepal time, a cutoff in UTC — and comparing those as strings gives the
    wrong answer as soon as the offsets differ.
    """
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError:
            return value
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day, tzinfo=timezone.utc)
    return value


class _Negate:
    def __init__(self, query):
        self._query = query

    def is_(self, column, value):
        expected = None if value in ("null", None) else value
        self._query._filters.append(lambda row: row.get(column) is not expected)
        return self._query


class _Query:
    def __init__(self, store: list[dict], action: str, payload=None):
        self._store = store
        self._action = action
        self._payload = payload
        self._filters = []
        self._order = None
        self._range = None
        self._single = False

    # --- filters ---------------------------------------------------------

    def select(self, *_columns):
        return self

    def eq(self, column, value):
        self._filters.append(lambda row: str(row.get(column)) == str(value)
                             if not isinstance(value, bool) else row.get(column) is value)
        return self

    def gte(self, column, value):
        bound = _comparable(value)
        self._filters.append(
            lambda row: row.get(column) is not None and _comparable(row[column]) >= bound
        )
        return self

    def lte(self, column, value):
        bound = _comparable(value)
        self._filters.append(
            lambda row: row.get(column) is not None and _comparable(row[column]) <= bound
        )
        return self

    def lt(self, column, value):
        bound = _comparable(value)
        self._filters.append(
            lambda row: row.get(column) is not None and _comparable(row[column]) < bound
        )
        return self

    def in_(self, column, values):
        wanted = {str(v) for v in values}
        self._filters.append(lambda row: str(row.get(column)) in wanted)
        return self

    def is_(self, column, value):
        expected = None if value in ("null", None) else value
        self._filters.append(lambda row: row.get(column) is expected)
        return self

    @property
    def not_(self):
        return _Negate(self)

    def order(self, column, desc=False):
        self._order = (column, desc)
        return self

    def range(self, start, end):
        self._range = (start, end)
        return self

    def limit(self, count):
        self._range = (0, count - 1)
        return self

    def maybe_single(self):
        self._single = True
        return self

    # --- execution -------------------------------------------------------

    def _matching(self):
        return [row for row in self._store if all(f(row) for f in self._filters)]

    async def execute(self):
        if self._action == "select":
            rows = self._matching()
            if self._order:
                column, desc = self._order
                rows.sort(
                    key=lambda row: (row.get(column) is None, _comparable(row.get(column)) or 0),
                    reverse=desc,
                )
            if self._range:
                start, end = self._range
                rows = rows[start : end + 1]
            rows = copy.deepcopy(rows)
            if self._single:
                return SimpleNamespace(data=rows[0] if rows else None)
            return SimpleNamespace(data=rows)

        if self._action == "insert":
            docs = self._payload if isinstance(self._payload, list) else [self._payload]
            created = []
            for doc in docs:
                row = {**doc, "id": doc.get("id") or str(uuid4())}
                self._store.append(row)
                created.append(copy.deepcopy(row))
            return SimpleNamespace(data=created)

        if self._action == "update":
            changed = []
            for row in self._matching():
                row.update(self._payload)
                changed.append(copy.deepcopy(row))
            return SimpleNamespace(data=changed)

        if self._action == "delete":
            doomed = self._matching()
            for row in doomed:
                self._store.remove(row)
            return SimpleNamespace(data=copy.deepcopy(doomed))

        raise NotImplementedError(self._action)


class _Table:
    def __init__(self, store: list[dict]):
        self._store = store

    def select(self, *columns):
        return _Query(self._store, "select")

    def insert(self, payload):
        return _Query(self._store, "insert", payload)

    def update(self, payload):
        return _Query(self._store, "update", payload)

    def delete(self):
        return _Query(self._store, "delete")


class FakeSupabase:
    def __init__(self, tables: dict[str, list[dict]] | None = None):
        self.tables: dict[str, list[dict]] = tables or {}

    def table(self, name: str) -> _Table:
        return _Table(self.tables.setdefault(name, []))

    @classmethod
    def from_demo(cls, data) -> "FakeSupabase":
        return cls(
            {
                table: [model.model_dump(mode="json") for model in models]
                for table, models in data.tables.items()
            }
        )
