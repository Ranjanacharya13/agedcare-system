"""The week roster, filling open shifts, and the summary screens — run
against the demo facility through the in-memory Supabase stand-in."""

from datetime import date, datetime, timedelta, timezone

import pytest

from backend.demo.dataset import NPT, build
from backend.models.user import AccessRole
from backend.schemas.roster import OpenShiftCreate, ShiftAssignmentItem
from backend.services.overview_service import OverviewService
from backend.services.risk_scoring import RiskScoringService
from backend.services.roster_service import RosterService
from backend.tests.fake_supabase import FakeSupabase

# Today, for the same reason as test_demo_dataset: the services read the clock.
TODAY = datetime.now(NPT).date()


@pytest.fixture
def data():
    return build(TODAY)


@pytest.fixture
def client(data):
    return FakeSupabase.from_demo(data)


def _next_week():
    monday = TODAY - timedelta(days=TODAY.weekday()) + timedelta(days=7)
    start = datetime.combine(monday, datetime.min.time(), tzinfo=NPT)
    return start, start + timedelta(days=7)


def _open_shift(data, weekday_name):
    return next(
        s for s in data.rows("employee_shifts")
        if s.employee_id is None and s.shift_start.strftime("%A") == weekday_name
        and s.role == "Registered Nurse"
    )


# --- the week -------------------------------------------------------------


@pytest.mark.anyio
async def test_the_week_view_shows_open_shifts_alongside_filled_ones(client):
    start, end = _next_week()
    shifts = await RosterService(client).list_between(start, end)
    open_ = [s for s in shifts if s.is_open]
    filled = [s for s in shifts if not s.is_open]
    assert len(open_) == 5
    assert filled and all(s.employee_name for s in filled)
    assert [s.shift_start for s in shifts] == sorted(s.shift_start for s in shifts)


@pytest.mark.anyio
async def test_an_open_shift_can_be_added(client):
    start, _ = _next_week()
    created = await RosterService(client).create_open_shift(
        OpenShiftCreate(shift_start=start + timedelta(hours=7), shift_end=start + timedelta(hours=15),
                        role="Registered Nurse")
    )
    assert created.is_open and created.employee_id is None


@pytest.mark.anyio
async def test_a_shift_that_ends_before_it_starts_is_refused(client):
    start, _ = _next_week()
    with pytest.raises(Exception):
        await RosterService(client).create_open_shift(
            OpenShiftCreate(shift_start=start + timedelta(hours=15), shift_end=start + timedelta(hours=7))
        )


# --- filling open shifts ----------------------------------------------------


@pytest.mark.anyio
async def test_assigning_an_open_shift_gives_it_to_that_person(data, client):
    thursday = _open_shift(data, "Thursday")
    result = await RosterService(client).assign(
        [ShiftAssignmentItem(shift_id=thursday.id, employee_id=data.employee_ids["pooja"])]
    )
    assert result.failed == []
    assert result.assigned[0].employee_name == "Pooja Adhikari"
    assert result.assigned[0].is_open is False


@pytest.mark.anyio
async def test_someone_already_working_then_is_refused_with_a_reason(data, client):
    """Bikash already works Thursday night — the reason the optimiser gave
    this shift to Pooja. Assigning it to him by hand must be refused."""
    thursday = _open_shift(data, "Thursday")
    result = await RosterService(client).assign(
        [ShiftAssignmentItem(shift_id=thursday.id, employee_id=data.employee_ids["bikash"])]
    )
    assert result.assigned == []
    assert "overlaps" in result.failed[0].reason


@pytest.mark.anyio
async def test_the_same_person_cannot_take_two_overlapping_shifts_in_one_batch(data, client):
    service = RosterService(client)
    start, _ = _next_week()
    a = await service.create_open_shift(OpenShiftCreate(
        shift_start=start + timedelta(days=5, hours=9), shift_end=start + timedelta(days=5, hours=17)))
    b = await service.create_open_shift(OpenShiftCreate(
        shift_start=start + timedelta(days=5, hours=12), shift_end=start + timedelta(days=5, hours=20)))
    nabin = data.employee_ids["nabin"]
    result = await service.assign([
        ShiftAssignmentItem(shift_id=a.id, employee_id=nabin),
        ShiftAssignmentItem(shift_id=b.id, employee_id=nabin),
    ])
    assert len(result.assigned) == 1 and len(result.failed) == 1


@pytest.mark.anyio
async def test_a_shift_already_filled_is_not_silently_reassigned(data, client):
    service = RosterService(client)
    thursday = _open_shift(data, "Thursday")
    await service.assign([ShiftAssignmentItem(shift_id=thursday.id, employee_id=data.employee_ids["pooja"])])
    again = await service.assign(
        [ShiftAssignmentItem(shift_id=thursday.id, employee_id=data.employee_ids["sarita"])]
    )
    assert "already been given to Pooja Adhikari" in again.failed[0].reason


# --- summaries -----------------------------------------------------------------


@pytest.mark.anyio
async def test_the_resident_list_shows_risk_and_key_worker(data, client):
    rows = await OverviewService(client, RiskScoringService(client)).resident_summaries()
    by_name = {r.first_name: r for r in rows}
    assert by_name["Ram Bahadur"].risk_band == "Critical"
    assert by_name["Ram Bahadur"].primary_carer_name == "Anjali Gurung"
    assert by_name["Tek Bahadur"].primary_carer_name is None
    assert by_name["Hari Prasad"].open_incidents == 1


@pytest.mark.anyio
async def test_the_staff_list_shows_real_caseloads(data, client):
    rows = await OverviewService(client, RiskScoringService(client)).staff_summaries()
    asmita = next(r for r in rows if r.first_name == "Asmita")
    assert asmita.caseload == 3 and asmita.primary_for == 3


@pytest.mark.anyio
async def test_the_dashboard_hides_what_a_care_worker_may_not_see(client):
    service = OverviewService(client, RiskScoringService(client))
    manager = await service.dashboard(AccessRole.MANAGER)
    carer = await service.dashboard(AccessRole.CARE_WORKER)

    assert manager.open_complaints is not None and manager.expiring_credentials is not None
    assert carer.open_complaints is None and carer.expiring_credentials is None
    assert not any(item.kind in ("credential", "leave", "complaint") for item in carer.attention)


@pytest.mark.anyio
async def test_the_dashboard_puts_unallocated_high_risk_residents_first(client):
    summary = await OverviewService(client, RiskScoringService(client)).dashboard(AccessRole.MANAGER)
    assert summary.residents_without_primary == 4
    assert summary.attention[0].kind == "coverage" and summary.attention[0].severity == "high"
    assert summary.residents_by_band == {"Critical": 3, "High": 4, "Medium": 3, "Low": 4}
