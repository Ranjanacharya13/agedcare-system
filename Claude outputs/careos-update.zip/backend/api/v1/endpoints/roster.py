from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, status

from backend.algorithms.ahp import CONSISTENCY_THRESHOLD, build_matrix
from backend.api.deps import get_roster_optimisation_service, get_roster_service
from backend.config.risk_weights import (
    JUDGEMENTS,
    RISK_CRITERIA,
    RISK_WEIGHT_MODEL,
)
from backend.schemas.risk_score import AHPCriterionOut, RiskWeightModelOut
from backend.schemas.roster import (
    OpenShiftCreate,
    RosterOptimiseOut,
    RosterOptimiseRequest,
    RosterShiftOut,
    ShiftAssignmentIn,
    ShiftAssignmentOut,
)
from backend.services.roster_optimisation import RosterOptimisationService
from backend.services.roster_service import RosterService

#: Running the optimiser — a POST, guarded by "roster_planning".
router = APIRouter()

#: Reading the weight model — a GET, guarded by the read-only "analytics".
weights_router = APIRouter()


@router.post("/roster/optimise", response_model=RosterOptimiseOut)
async def optimise_roster(
    payload: RosterOptimiseRequest,
    service: RosterOptimisationService = Depends(get_roster_optimisation_service),
):
    """Assign staff to shifts at minimum total cost (Hungarian algorithm).

    Advisory, like the per-shift suggestions it supersedes — nothing is
    written to `employee_shifts`. A human still confirms the roster; this
    endpoint tells them what the best possible one looks like, and what the
    greedy alternative would have cost.
    """
    return await service.optimise(
        shift_ids=[str(s) for s in payload.shift_ids] if payload.shift_ids else None,
        from_date=payload.from_date,
        to_date=payload.to_date,
        max_candidates=payload.max_candidates,
    )


@router.get("/roster/shifts", response_model=list[RosterShiftOut])
async def list_roster(
    start: datetime = Query(alias="from"),
    end: datetime = Query(alias="to"),
    service: RosterService = Depends(get_roster_service),
):
    """Every shift starting in [from, to), open ones included, with names
    resolved. The browser sends its own week boundaries, so "Monday" means
    Monday where the user is rather than in UTC."""
    if end <= start:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "'to' must be after 'from'")
    if end - start > timedelta(days=42):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "At most six weeks at a time")
    return await service.list_between(start, end)


@router.post("/roster/shifts", response_model=RosterShiftOut, status_code=status.HTTP_201_CREATED)
async def create_open_shift(
    data: OpenShiftCreate, service: RosterService = Depends(get_roster_service)
):
    """Add a shift nobody holds yet — demand to be filled."""
    return await service.create_open_shift(data)


@router.post("/roster/assign", response_model=ShiftAssignmentOut)
async def assign_open_shifts(
    payload: ShiftAssignmentIn, service: RosterService = Depends(get_roster_service)
):
    """Give open shifts to people — the confirm step after the optimiser's
    suggestion, or a manager's own choice. Always 200: the body says which
    lines were applied and which were refused, and why."""
    return await service.assign(payload.assignments)


@weights_router.get("/risk-weights", response_model=RiskWeightModelOut)
async def get_risk_weight_model():
    """How the resident risk weights were derived, and whether the
    judgements behind them hold together.

    Exposed as an endpoint rather than buried in a config file so the
    weighting can be inspected by anyone using the system — if a nurse
    disagrees with a score, the first useful question is what the model
    thinks matters and why.
    """
    model = RISK_WEIGHT_MODEL
    return RiskWeightModelOut(
        method="Analytic Hierarchy Process (Saaty) — principal eigenvector by power iteration",
        criteria=[
            AHPCriterionOut(
                criterion=name,
                weight=round(model.weights[name], 6),
                percentage=round(model.weights[name] * 100, 2),
            )
            for name in sorted(RISK_CRITERIA, key=lambda c: -model.weights[c])
        ],
        comparison_matrix=[
            [round(value, 4) for value in row]
            for row in build_matrix(RISK_CRITERIA, JUDGEMENTS)
        ],
        lambda_max=round(model.lambda_max, 6),
        consistency_index=round(model.consistency_index, 6),
        consistency_ratio=round(model.consistency_ratio, 6),
        consistency_threshold=CONSISTENCY_THRESHOLD,
        is_consistent=model.is_consistent,
        verdict=model.verdict,
    )
