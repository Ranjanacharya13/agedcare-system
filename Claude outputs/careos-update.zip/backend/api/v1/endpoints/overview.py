from fastapi import APIRouter, Depends

from backend.api.auth_deps import CurrentUser
from backend.api.deps import get_overview_service
from backend.schemas.overview import DashboardSummaryOut, ResidentSummaryOut, StaffSummaryOut
from backend.services.overview_service import OverviewService

# Three routers because they are three different audiences, each mounted
# under its own permission group in router.py.
residents_router = APIRouter()
staff_router = APIRouter()
dashboard_router = APIRouter()


@residents_router.get("/overview/residents", response_model=list[ResidentSummaryOut])
async def resident_overview(service: OverviewService = Depends(get_overview_service)):
    """Every resident with what the list screen needs to be scanned rather
    than opened row by row: room, age, risk band, primary carer, and counts
    of active medications and open incidents."""
    return await service.resident_summaries()


@staff_router.get("/overview/staff", response_model=list[StaffSummaryOut])
async def staff_overview(service: OverviewService = Depends(get_overview_service)):
    """Every employee with caseload, risk load, hours this week and next
    shift."""
    return await service.staff_summaries()


@dashboard_router.get("/overview/dashboard", response_model=DashboardSummaryOut)
async def dashboard(
    user: CurrentUser, service: OverviewService = Depends(get_overview_service)
):
    """Facility-wide counts and a to-do list, trimmed to what this user's
    role is allowed to read."""
    return await service.dashboard(user.access_role)
