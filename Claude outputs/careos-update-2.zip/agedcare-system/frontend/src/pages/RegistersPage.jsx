import { useCallback, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useAsync } from "../hooks/useAsync.js";
import { useDirectory, personLabel } from "../hooks/useDirectory.js";
import { createResourceApi } from "../api/resourceApi.js";
import { R, E } from "../config/sections.js";
import PageHeader from "../components/common/PageHeader.jsx";
import Segmented from "../components/common/Segmented.jsx";
import SearchInput from "../components/common/SearchInput.jsx";
import Pager from "../components/common/Pager.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";
import Modal from "../components/common/Modal.jsx";
import Button from "../components/common/Button.jsx";
import ResourceTable from "../components/resource/ResourceTable.jsx";
import RecordDetail from "../components/resource/RecordDetail.jsx";

const PAGE = 50;

// One facility-wide list per record type — every resident's incidents in
// one place, every staff member's leave requests in one place. These are the
// backend's flat "list all" routes (GET /incidents, /leave, …); each row is
// also on the person's own page, which a click takes you to.
const REGISTERS = [
  { key: "incidents", owner: "residents", config: R.incidents, hint: "Every incident across the home, newest first." },
  { key: "medications", owner: "residents", config: R.medications, hint: "Every prescription for every resident." },
  { key: "fall-risk", owner: "residents", config: R["fall-risk"], hint: "All fall-risk assessments." },
  { key: "behaviour", owner: "residents", config: R.behaviour, hint: "Behaviour events across the home." },
  { key: "medical-inventory", owner: "residents", config: R["medical-inventory"], hint: "Personal supplies and when they expire." },
  { key: "leave", owner: "employees", config: E.leave, hint: "Leave requests — pending ones need a decision." },
  { key: "registration", owner: "employees", config: E.registration, hint: "Professional registrations and their expiry." },
  { key: "qualifications", owner: "employees", config: E.qualifications, hint: "Certificates and training, soonest expiry first." },
  { key: "time-entries", owner: "employees", config: E["time-entries"], hint: "Clock-ins and clock-outs." },
  { key: "payroll", owner: "employees", config: E.payroll, hint: "Pay runs for everyone." },
];

/**
 * Registers: the facility-wide view of each kind of record.
 *
 * A person's page answers "what about Ram Bahadur?"; this answers "what
 * about everyone?" — all open incidents, all pending leave, every credential
 * about to lapse — without opening fourteen pages.
 */
export default function RegistersPage() {
  const { can } = useAuth();
  const navigate = useNavigate();
  const directory = useDirectory();
  const [params, setParams] = useSearchParams();
  const [skip, setSkip] = useState(0);
  const [query, setQuery] = useState("");
  const [viewing, setViewing] = useState(null);

  const available = REGISTERS.filter((r) => r.config && (!r.config.group || can(r.config.group, "read")));
  const active = available.find((r) => r.key === params.get("list")) || available[0];
  const api = useMemo(() => (active ? createResourceApi(active.config) : null), [active]);

  const load = useCallback(
    (signal) => (api ? api.list({ skip, limit: PAGE, signal }) : Promise.resolve([])),
    [api, skip]
  );
  const { data, loading, error } = useAsync(load, [load]);

  if (!active) {
    return (
      <div className="page">
        <PageHeader title="Registers" subtitle="Your role cannot read any facility-wide register." />
      </div>
    );
  }

  const ownerField = active.owner === "residents" ? "resident_id" : "employee_id";
  const people = active.owner === "residents" ? directory.residentsById : directory.employeesById;
  const nameOf = (row) => personLabel(people[row[ownerField]]) || "Unknown";

  const rows = (data || []).filter((row) =>
    query ? nameOf(row).toLowerCase().includes(query.trim().toLowerCase()) : true
  );

  const choose = (key) => {
    setSkip(0);
    setQuery("");
    setParams({ list: key });
  };

  const personColumn = {
    key: "__person",
    label: active.owner === "residents" ? "Resident" : "Staff member",
    render: (row) => (
      <Link
        to={`/admin/${active.owner}/${row[ownerField]}/${active.config.slug}`}
        onClick={(e) => e.stopPropagation()}
      >
        <strong>{nameOf(row)}</strong>
      </Link>
    ),
  };

  const byOwner = (owner) =>
    available.filter((r) => r.owner === owner).map((r) => ({ key: r.key, label: r.config.title }));

  return (
    <div className="page">
      <PageHeader
        title="Registers"
        subtitle="One list per kind of record, for the whole home. Click a row to read it, or a name to open that person's page."
      />

      {byOwner("residents").length > 0 && (
        <div className="register-row">
          <span className="register-row-label">Residents</span>
          <Segmented label="Resident registers" options={byOwner("residents")} value={active.key} onChange={choose} />
        </div>
      )}
      {byOwner("employees").length > 0 && (
        <div className="register-row">
          <span className="register-row-label">Staff</span>
          <Segmented label="Staff registers" options={byOwner("employees")} value={active.key} onChange={choose} />
        </div>
      )}

      <div className="list-toolbar">
        <p className="text-muted register-hint">{active.hint}</p>
        <SearchInput value={query} onChange={setQuery} placeholder="Filter by name" />
      </div>

      <ErrorBanner error={error} />
      {loading ? (
        <Skeleton rows={6} />
      ) : (
        <>
          <ResourceTable
            resource={active.config}
            items={rows}
            canWrite={false}
            leadingColumns={[personColumn]}
            onOpen={setViewing}
          />
          <Pager skip={skip} limit={PAGE} count={(data || []).length} onChange={setSkip} />
        </>
      )}

      {viewing && (
        <Modal
          title={`${active.config.label || active.config.title} — ${nameOf(viewing)}`}
          onClose={() => setViewing(null)}
          footer={
            <Button
              onClick={() => navigate(`/admin/${active.owner}/${viewing[ownerField]}/${active.config.slug}`)}
            >
              Open {nameOf(viewing)}&rsquo;s page
            </Button>
          }
        >
          <RecordDetail resource={active.config} record={viewing} />
        </Modal>
      )}
    </div>
  );
}
