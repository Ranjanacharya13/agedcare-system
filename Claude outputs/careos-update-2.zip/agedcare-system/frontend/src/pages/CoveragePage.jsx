import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useAsync } from "../hooks/useAsync.js";
import { useAuth } from "../context/AuthContext.jsx";
import { getCoverageReport } from "../api/assignments.js";
import StatusBadge from "../components/common/StatusBadge.jsx";
import Skeleton from "../components/common/Skeleton.jsx";
import ErrorBanner from "../components/common/ErrorBanner.jsx";
import Button from "../components/common/Button.jsx";
import PageHeader from "../components/common/PageHeader.jsx";
import HowItWorks from "../components/common/HowItWorks.jsx";
import AllocationPlan, {
  ALGORITHM_NOTE,
  ApplyResult,
  KEY_WORKER_STEPS,
} from "../components/coverage/AllocationPlan.jsx";

/**
 * Care teams: who looks after whom, on one screen.
 *
 * Every resident should have two named people — a key worker (their main
 * carer and the family's contact) and a backup who covers when the key
 * worker is off. The page answers three questions, top to bottom:
 *
 *   1. Is anything missing?   (only shown when it is, with one button to fix it)
 *   2. Who holds whom?        (one card per carer)
 *   3. Someone is leaving?    ("Hand over" on their card)
 *
 * The matching algorithm runs behind the buttons in 1 and 3. It suggests;
 * a person confirms.
 */
export default function CoveragePage() {
  const { can } = useAuth();
  const canWrite = can("assignments", "write");
  const [params, setParams] = useSearchParams();
  const [version, setVersion] = useState(0);
  const [applied, setApplied] = useState(null);
  const planRef = useRef(null);

  // The open plan lives in the URL, so the dashboard can link straight to
  // "hand over Asmita's residents" and the back button closes it.
  const handOverId = params.get("handover");
  const suggestKind = params.get("suggest");

  const load = useCallback(
    (signal) => getCoverageReport({ signal }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [version]
  );
  const { data, loading, error } = useAsync(load, [load]);

  const leaving = handOverId && data?.teams.find((t) => t.employee_id === handOverId);
  const mode = leaving
    ? { handOverFrom: { id: leaving.employee_id, name: `${leaving.first_name} ${leaving.last_name}` } }
    : suggestKind
      ? { kind: suggestKind }
      : null;

  const openPlan = (next) => {
    setApplied(null);
    setParams(next, { replace: false });
  };
  const closePlan = () => setParams({}, { replace: false });

  useEffect(() => {
    if (mode && planRef.current) planRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [handOverId, suggestKind, Boolean(data)]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading && !data) return <Skeleton rows={6} />;
  if (error) return <ErrorBanner error={error} />;
  if (!data) return null;

  const maxLoad = Math.max(1, ...data.teams.map((t) => t.risk_load));
  const noKeyWorker = data.unassigned.length;
  const noBackup = data.without_backup.length;

  return (
    <div className="page">
      <PageHeader
        title="Care teams"
        subtitle="Every resident has two named people: a key worker (their main carer and the family's contact) and a backup who covers when the key worker is off."
      />

      <div className="team-summary">
        <SummaryTile
          label="Have a key worker"
          value={`${data.residents_with_primary}/${data.total_residents}`}
          ok={noKeyWorker === 0}
        />
        <SummaryTile
          label="Have a backup"
          value={`${data.residents_with_backup}/${data.total_residents}`}
          ok={noBackup === 0}
        />
        <SummaryTile
          label="Carers sharing the work"
          value={data.teams.length}
          hint={`about ${data.average_caseload} residents each`}
        />
      </div>

      {applied && <ApplyResult {...applied} />}

      {(noKeyWorker > 0 || noBackup > 0) && (
        <section className="gap-list" aria-label="Needs doing">
          {noKeyWorker > 0 && (
            <GapCard
              title={`${noKeyWorker} resident${noKeyWorker === 1 ? " needs" : "s need"} a key worker`}
              residents={data.unassigned}
              urgent
              action={
                canWrite && (
                  <Button onClick={() => openPlan({ suggest: "Primary" })}>Suggest key workers</Button>
                )
              }
            />
          )}
          {noBackup > 0 && (
            <GapCard
              title={`${noBackup} resident${noBackup === 1 ? " needs" : "s need"} a backup carer`}
              residents={data.without_backup}
              action={
                canWrite && (
                  <Button variant="secondary" onClick={() => openPlan({ suggest: "Secondary" })}>
                    Suggest backups
                  </Button>
                )
              }
            />
          )}
        </section>
      )}

      <div ref={planRef}>
        {mode && canWrite && (
          <AllocationPlan
            key={handOverId || suggestKind}
            mode={mode}
            onClose={closePlan}
            onApplied={(result, info) => {
              setApplied({ result, ...info });
              closePlan();
              setVersion((v) => v + 1);
            }}
          />
        )}
      </div>

      <div className="team-board-heading">
        <h2 className="section-title">Who looks after whom</h2>
        <span className="team-legend">
          <span className="team-role team-role-primary">Key worker</span>
          <span className="team-role team-role-secondary">Backup</span>
          <span className="team-pick">CareOS pick</span> = chosen from a suggestion
        </span>
      </div>

      <div className="team-board">
        {data.teams.map((team) => (
          <TeamCard
            key={team.employee_id}
            team={team}
            maxLoad={maxLoad}
            canWrite={canWrite}
            onHandOver={() => openPlan({ handover: team.employee_id })}
          />
        ))}
      </div>

      {data.staff_without_caseload.length > 0 && (
        <p className="text-muted team-idle">
          Not looking after residents:{" "}
          {data.staff_without_caseload.map((e, index) => (
            <span key={e.employee_id}>
              {index > 0 && ", "}
              <Link to={`/admin/employees/${e.employee_id}`}>
                {e.first_name} {e.last_name}
              </Link>
              {e.role && <span className="text-muted"> ({e.role})</span>}
            </span>
          ))}
          . Managers, office, kitchen and laundry staff normally don&rsquo;t hold residents.
        </p>
      )}

      <HowItWorks title="How does CareOS choose carers?" steps={KEY_WORKER_STEPS} />
    </div>
  );
}

function SummaryTile({ label, value, ok, hint }) {
  return (
    <div className={`team-summary-tile${ok === false ? " is-warning" : ok ? " is-ok" : ""}`}>
      <span className="team-summary-value">
        {value}
        {ok && <span className="team-summary-check" aria-label="complete"> ✓</span>}
      </span>
      <span className="team-summary-label">{label}</span>
      {hint && <span className="team-summary-hint">{hint}</span>}
    </div>
  );
}

function GapCard({ title, residents, action, urgent }) {
  return (
    <div className={`gap-card${urgent ? " is-urgent" : ""}`}>
      <div className="gap-card-text">
        <strong>{title}</strong>
        <span className="gap-card-names">
          {residents.map((r, index) => (
            <span key={r.resident_id}>
              {index > 0 && ", "}
              <Link to={`/admin/residents/${r.resident_id}/care-team`}>
                {r.first_name} {r.last_name}
              </Link>
              {r.risk_band && ` (${r.risk_band})`}
            </span>
          ))}
        </span>
      </div>
      {action}
    </div>
  );
}

function TeamCard({ team, maxLoad, canWrite, onHandOver }) {
  const width = Math.round((team.risk_load / maxLoad) * 100);
  return (
    <article className="team-card">
      <header className="team-card-header">
        <div>
          <Link to={`/admin/employees/${team.employee_id}`} className="team-card-name">
            {team.first_name} {team.last_name}
          </Link>
          <span className="team-card-role">{team.role}</span>
        </div>
        {canWrite && (
          <button type="button" className="team-card-action" onClick={onHandOver}>
            Hand over…
          </button>
        )}
      </header>

      <p className="team-card-counts">
        Key worker for <strong>{team.key_worker_for}</strong> · backup for{" "}
        <strong>{team.backup_for}</strong>
      </p>
      <div className="team-load" title={`Risk load ${team.risk_load} (their residents' risk scores added up)`}>
        <span className="team-load-fill" style={{ width: `${width}%` }} />
      </div>
      <span className="team-load-label">Risk load {team.risk_load}</span>

      <ul className="team-residents">
        {team.residents.map((r) => (
          <li key={r.assignment_id}>
            <span className={`team-role team-role-${r.assignment_type.toLowerCase()}`}>
              {r.assignment_type === "Primary" ? "Key" : r.assignment_type === "Secondary" ? "Backup" : "Relief"}
            </span>
            <Link className="team-residents-name" to={`/admin/residents/${r.resident_id}/care-team`}>
              {r.first_name} {r.last_name}
            </Link>
            {r.notes?.startsWith(ALGORITHM_NOTE.slice(0, 20)) && (
              <span className="team-pick" title={r.notes}>
                CareOS pick
              </span>
            )}
            <span className="team-residents-risk">
              {r.risk_band && <StatusBadge value={r.risk_band} badgeKind="riskBand" />}
            </span>
          </li>
        ))}
      </ul>
    </article>
  );
}
