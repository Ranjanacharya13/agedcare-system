import { get, post } from "./client.js";

/** Who cares for this resident, and which of them is on shift right now. */
export const getCareTeam = (residentId, options) =>
  get(`/residents/${residentId}/care-team`, options);

/** Which residents this employee is responsible for, riskiest first. */
export const getCaseload = (employeeId, options) =>
  get(`/employees/${employeeId}/caseload`, options);

/** Every care team on one screen: gaps, backups, and each carer's residents. */
export const getCoverageReport = (options) => get("/coverage", options);

/** Confirm several assignments at once — where a reviewed plan becomes real.
 *  Resolves even when some lines were rejected: the body names which. */
export const createAssignmentsInBulk = (assignments, options) =>
  post("/coverage/assignments", { assignments }, options);

/** Add one carer to one resident. */
export const createAssignment = (residentId, body, options) =>
  post(`/residents/${residentId}/assignments`, body, options);

/** Move a departing carer's residents to the people chosen for them. Each
 *  line closes the old assignment (kept as history) and starts the new one. */
export const handOver = (fromEmployeeId, assignments, options) =>
  post("/coverage/hand-over", { from_employee_id: fromEmployeeId, assignments }, options);
