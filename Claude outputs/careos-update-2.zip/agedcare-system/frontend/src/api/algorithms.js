import { get, post } from "./client.js";

/**
 * The algorithms are not a screen of their own — they run inside the
 * workflows they serve. These are the endpoints those workflows call.
 * (Roster optimisation lives in api/roster.js, beside the roster it fills.)
 */

/** Ranked carers for one resident, while adding a single assignment. */
export const getSuggestedCarers = (residentId, options) =>
  get(`/residents/${residentId}/suggested-carers?limit=5`, options);

/**
 * One optimal allocation (Hungarian algorithm) for a set of care-team places.
 *   {kind: "Primary"}    — a key worker for everyone without one
 *   {kind: "Secondary"}  — a backup carer for everyone without one
 *   {handOverFrom: id}   — who takes over each resident this person holds
 * Suggests only; nothing is written.
 */
export const suggestAssignments = ({ kind = "Primary", handOverFrom } = {}, options) => {
  const query = new URLSearchParams({ kind });
  if (handOverFrom) query.set("hand_over_from", handOverFrom);
  return post(`/coverage/suggest-assignments?${query}`, undefined, options);
};

/** How the risk weights were derived — shown inside the risk score card. */
export const getRiskWeightModel = (options) => get("/risk-weights", options);
