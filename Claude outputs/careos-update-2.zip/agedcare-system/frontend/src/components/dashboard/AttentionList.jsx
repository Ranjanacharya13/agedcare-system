import { Link } from "react-router-dom";

const KIND_LABEL = {
  coverage: "Care team",
  handover: "Hand-over",
  incident: "Incident",
  roster: "Roster",
  credential: "Credential",
  supplies: "Supplies",
  leave: "Leave",
  complaint: "Complaint",
  appointment: "Enquiry",
};

/**
 * The dashboard's to-do list: things someone should act on, most urgent
 * first, each one a link to the screen where it gets done. Built by the
 * server from the same data the pages show, and trimmed to what this user's
 * role may see.
 */
export default function AttentionList({ items }) {
  if (!items.length) {
    return <p className="text-muted">Nothing needs attention right now.</p>;
  }
  return (
    <ul className="attention-list">
      {items.map((item, index) => (
        <li key={`${item.kind}-${index}`} className={`attention-item attention-${item.severity}`}>
          <Link to={item.link}>
            <span className="attention-dot" aria-hidden="true" />
            <span className="attention-text">
              <span className="attention-kind">{KIND_LABEL[item.kind] || item.kind}</span>
              <strong>{item.title}</strong>
              {item.detail && <small>{item.detail}</small>}
            </span>
            <span className="attention-go" aria-hidden="true">→</span>
          </Link>
        </li>
      ))}
    </ul>
  );
}
