import { useEffect, useMemo, useState } from "react";
import { suggestAssignments } from "../../api/algorithms.js";
import { createAssignmentsInBulk, handOver } from "../../api/assignments.js";
import { isAborted } from "../../api/client.js";
import Button from "../common/Button.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";

/** Written on each assignment confirmed from a suggestion. The care-teams
 *  board shows a small "CareOS pick" tag on these. Same text the seed uses. */
export const ALGORITHM_NOTE = "Suggested by CareOS matching (Hungarian algorithm) and confirmed.";

/** The plain-language explanation shown under "How does CareOS choose?". */
export const KEY_WORKER_STEPS = [
  {
    title: "Every empty place is compared with every carer.",
    text: "Each pairing gets a score. A lower score means a better fit.",
  },
  {
    title: "A good fit is someone who already knows the resident…",
    text:
      "If a carer has written chart entries for this resident in the last 30 days (sleep, behaviour, falls…), they already know them, so the score drops. A resident with dementia who settles with one carer keeps that carer.",
  },
  {
    title: "…who is not already overloaded…",
    text:
      "Each carer's load is the risk scores of the residents they already look after added together. Three critical residents are heavier than six stable ones.",
  },
  {
    title: "…and who has the right skills.",
    text:
      "The sicker the resident (the higher their risk score), the more it matters that the carer is a nurse. For a stable resident it hardly matters.",
  },
  {
    title: "All places are decided together.",
    text:
      "Instead of giving the first resident their favourite carer and the rest whoever is left, the Hungarian algorithm finds the combination with the best total. When it chose differently from one-at-a-time, the row tells you.",
  },
  {
    title: "You decide.",
    text: "Nothing is saved until you press Confirm. You can change any carer or untick any row first.",
  },
];

const PLACE = { Primary: "key worker", Secondary: "backup carer" };

/**
 * Propose, edit, confirm — for one of three jobs:
 *   mode = { kind: "Primary" }            a key worker for everyone without one
 *   mode = { kind: "Secondary" }          a backup for everyone without one
 *   mode = { handOverFrom: {id, name} }   who takes over a leaving carer's residents
 *
 * It asks for the plan as soon as it opens (the user has just pressed the
 * button that means "suggest"), nothing is written until Confirm, and the
 * result is handed up so the page can show it after this panel closes.
 */
export default function AllocationPlan({ mode, onApplied, onClose }) {
  const handingOver = Boolean(mode.handOverFrom);
  const [plan, setPlan] = useState(null);
  const [choices, setChoices] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const kind = mode.kind || "Primary";
  const fromId = mode.handOverFrom?.id;

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    suggestAssignments({ kind, handOverFrom: fromId }, { signal: controller.signal })
      .then((next) => {
        setPlan(next);
        // The proposal seeds the form; from here the user's edits are the truth.
        setChoices(
          Object.fromEntries(
            next.suggestions.map((row) => [
              row.resident_id,
              { employeeId: row.employee_id || "", include: Boolean(row.employee_id) },
            ])
          )
        );
      })
      .catch((err) => {
        if (!isAborted(err)) setError(err);
      })
      .finally(() => setLoading(false));
    return () => controller.abort();
  }, [kind, fromId]);

  const confirmed = useMemo(() => {
    if (!plan) return [];
    return plan.suggestions
      .filter((row) => choices[row.resident_id]?.include && choices[row.resident_id]?.employeeId)
      .map((row) => {
        const employeeId = choices[row.resident_id].employeeId;
        return {
          resident_id: row.resident_id,
          employee_id: employeeId,
          assignment_type: row.assignment_type,
          notes: employeeId === row.employee_id ? ALGORITHM_NOTE : "Chosen by hand in place of a CareOS suggestion.",
        };
      });
  }, [plan, choices]);

  const changedCount = plan
    ? plan.suggestions.filter(
        (row) => row.one_at_a_time_employee_id && row.one_at_a_time_employee_id !== row.employee_id
      ).length
    : 0;

  const confirm = async () => {
    setSaving(true);
    setError(null);
    try {
      const outcome = handingOver
        ? await handOver(
            fromId,
            confirmed.map(({ resident_id, employee_id }) => ({ resident_id, employee_id }))
          )
        : await createAssignmentsInBulk(confirmed);
      onApplied?.(outcome, { handingOver, name: mode.handOverFrom?.name });
    } catch (err) {
      if (!isAborted(err)) setError(err);
      setSaving(false);
    }
  };

  const title = handingOver
    ? `Hand over ${mode.handOverFrom.name}'s residents`
    : `Suggested ${PLACE[kind]}s`;
  const intro = handingOver
    ? `CareOS suggests who should take over each resident ${mode.handOverFrom.name} looks after, in the same role. Their current assignments are closed (and kept as history) only when you confirm.`
    : `One ${PLACE[kind]} for each resident who has none, chosen to fit the resident and to share the work fairly.`;

  return (
    <section className="plan-panel fade-slide-in" aria-label={title}>
      <div className="plan-panel-header">
        <div>
          <h2 className="section-title">{title}</h2>
          <p className="text-muted">{intro}</p>
        </div>
        <Button variant="secondary" size="sm" onClick={onClose} disabled={saving}>
          Close
        </Button>
      </div>

      <ErrorBanner error={error} />
      {loading && <Skeleton rows={4} />}

      {plan && !loading && plan.suggestions.length === 0 && (
        <p className="algo-note">
          {handingOver
            ? `${mode.handOverFrom.name} is not looking after anyone — nothing to hand over.`
            : `Nothing to do — every resident already has a ${PLACE[kind]}.`}
        </p>
      )}

      {plan && !loading && plan.suggestions.length > 0 && (
        <>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th className="plan-include-cell">Use</th>
                  <th>Resident</th>
                  {handingOver && <th>Role</th>}
                  <th>Suggested carer</th>
                  <th>Why this carer</th>
                </tr>
              </thead>
              <tbody>
                {plan.suggestions.map((row) => (
                  <PlanRow
                    key={row.resident_id}
                    row={row}
                    showRole={handingOver}
                    choice={choices[row.resident_id]}
                    onChange={(patch) =>
                      setChoices((current) => ({
                        ...current,
                        [row.resident_id]: { ...current[row.resident_id], ...patch },
                      }))
                    }
                  />
                ))}
              </tbody>
            </table>
          </div>

          <div className="plan-actions">
            <Button onClick={confirm} disabled={saving || confirmed.length === 0}>
              {saving ? "Saving…" : `Confirm ${confirmed.length} ${confirmed.length === 1 ? "change" : "changes"}`}
            </Button>
            <span className="text-muted">Nothing is saved until you confirm.</span>
          </div>

          <p className="algo-meta">
            Worked out in {plan.solve_ms} ms, comparing {plan.residents_needing_a_carer} resident
            {plan.residents_needing_a_carer === 1 ? "" : "s"} with {plan.candidates_considered} staff.{" "}
            {plan.max_new_per_carer > 1 &&
              `There are more places than carers, so one carer may take up to ${plan.max_new_per_carer}. `}
            {plan.unmatched_greedy > plan.unmatched_optimal
              ? `Filling one at a time would have left ${plan.unmatched_greedy - plan.unmatched_optimal} resident(s) with nobody; deciding together leaves ${plan.unmatched_optimal || "none"}.`
              : changedCount > 0
                ? `Deciding everyone together changed ${changedCount} choice${changedCount === 1 ? "" : "s"} compared with filling one at a time (total score ${plan.optimal_total_cost} instead of ${plan.greedy_total_cost}).`
                : "Here, filling one at a time would have given the same answer."}
          </p>
        </>
      )}
    </section>
  );
}

/** One editable line of the plan. */
function PlanRow({ row, choice, onChange, showRole }) {
  const options = row.alternatives || [];
  const selected = options.find((c) => c.employee_id === choice?.employeeId);
  const changed = Boolean(row.employee_id) && choice?.employeeId !== row.employee_id;

  return (
    <tr className={choice?.include ? "" : "plan-row-skipped"}>
      <td className="plan-include-cell">
        <input
          type="checkbox"
          checked={Boolean(choice?.include)}
          disabled={options.length === 0}
          onChange={(event) => onChange({ include: event.target.checked })}
          aria-label={`Use the suggestion for ${row.first_name} ${row.last_name}`}
        />
      </td>
      <td>
        <span className="cell-stack">
          <strong>
            {row.first_name} {row.last_name}
          </strong>
          <span className="cell-inline">
            {row.room_number && <span className="room-tag">{row.room_number}</span>}
            {row.risk_band && <StatusBadge value={row.risk_band} badgeKind="riskBand" />}
          </span>
        </span>
      </td>
      {showRole && (
        <td>
          <span className={`team-role team-role-${row.assignment_type.toLowerCase()}`}>
            {row.assignment_type === "Primary" ? "Key worker" : "Backup"}
          </span>
        </td>
      )}
      <td>
        {options.length === 0 ? (
          <span className="coverage-critical">Nobody available</span>
        ) : (
          <>
            <select
              className="plan-carer-select"
              value={choice?.employeeId || ""}
              onChange={(event) => onChange({ employeeId: event.target.value })}
              aria-label={`Carer for ${row.first_name} ${row.last_name}`}
            >
              {options.map((candidate) => (
                <option key={candidate.employee_id} value={candidate.employee_id}>
                  {candidate.first_name} {candidate.last_name}
                  {candidate.role ? ` · ${candidate.role}` : ""}
                </option>
              ))}
            </select>
            {changed && <small className="algo-subtle">your choice</small>}
          </>
        )}
      </td>
      <td>
        <span className="suggestion-reason">{selected?.reason || row.reason}</span>
        {row.one_at_a_time_employee_id && row.one_at_a_time_employee_id !== row.employee_id && (
          <small className="one-at-a-time">
            One at a time, {row.first_name} would have got {row.one_at_a_time_employee_name}.
          </small>
        )}
      </td>
    </tr>
  );
}

/** What happened when a plan was confirmed. Rendered by the page, so it
 *  stays visible after the plan panel closes. */
export function ApplyResult({ result, handingOver, name }) {
  const done = result.created.length;
  const tone = result.failed.length > 0 ? "plan-result has-failures" : "plan-result";
  return (
    <div className={tone} role="status">
      <p>
        <strong>
          {handingOver
            ? `${done} resident${done === 1 ? "" : "s"} handed over from ${name}.`
            : `${done} carer${done === 1 ? "" : "s"} assigned.`}
        </strong>{" "}
        {done > 0 && result.failed.length === 0 && "The care teams below are up to date."}
      </p>
      {result.failed.length > 0 && (
        <>
          <p className="coverage-critical">{result.failed.length} could not be saved:</p>
          <ul className="plan-failures">
            {result.failed.map((failure) => (
              <li key={`${failure.resident_id}-${failure.employee_id}`}>{failure.reason}</li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
