import { NavLink, useNavigate } from "react-router-dom";
import Logo from "./Logo.jsx";
import {
  IconDashboard,
  IconResidents,
  IconEmployees,
  IconComplaints,
  IconCalendar,
  IconPulse,
  IconAlert,
  IconClock,
  IconLogout,
  IconClipboard,
} from "./Icons.jsx";
import { useAsync } from "../../hooks/useAsync.js";
import { getHealth } from "../../api/health.js";
import { useAuth } from "../../context/AuthContext.jsx";

// `group` is the permission group from config/permissions.js. A link with no
// group is visible to everyone who can sign in. Links the current role cannot
// use are hidden rather than shown-and-403'd — a menu that only offers what
// you can actually do is less confusing than one that punishes you for
// clicking.
//
// Grouped by the job being done rather than by table: the people you care
// for, the people who do the caring, the front desk, and administration. A
// heading with no visible links underneath it is dropped.
const sections = [
  {
    heading: null,
    links: [{ to: "/admin", label: "Dashboard", end: true, Icon: IconDashboard }],
  },
  {
    heading: "Care",
    links: [
      { to: "/admin/residents", label: "Residents", Icon: IconResidents, group: "residents" },
      { to: "/admin/coverage", label: "Care teams", Icon: IconAlert, group: "assignments" },
      { to: "/admin/registers", label: "Registers", Icon: IconClipboard, group: "residents" },
    ],
  },
  {
    heading: "Staff",
    links: [
      { to: "/admin/employees", label: "Staff", Icon: IconEmployees, group: "employees" },
      { to: "/admin/roster", label: "Roster", Icon: IconClock, group: "roster_planning" },
    ],
  },
  {
    heading: "Front desk",
    links: [
      { to: "/admin/appointments", label: "Appointments", Icon: IconCalendar, group: "appointments" },
      { to: "/admin/complaints", label: "Complaints", Icon: IconComplaints, group: "complaints" },
    ],
  },
  {
    heading: "Administration",
    links: [
      { to: "/admin/users", label: "Login accounts", Icon: IconLogout, group: "users" },
      { to: "/admin/audit-log", label: "Audit log", Icon: IconPulse, group: "audit" },
    ],
  },
];

export default function Nav() {
  const { data, error } = useAsync(() => getHealth(), []);
  const connected = Boolean(data?.status === "ok") && !error;
  const { displayName, role, logout, can } = useAuth();
  const navigate = useNavigate();

  const visibleSections = sections
    .map((section) => ({
      ...section,
      links: section.links.filter((link) => !link.group || can(link.group, "read")),
    }))
    .filter((section) => section.links.length > 0);

  const handleLogout = () => {
    logout();
    navigate("/login", { replace: true });
  };

  return (
    <aside className="app-sidebar">
      <div className="app-sidebar-brand">
        <Logo tone="dark" />
      </div>
      <nav className="app-nav-links">
        {visibleSections.map((section) => (
          <div key={section.heading || "home"} className="app-nav-section">
            {section.heading && <p className="app-nav-heading">{section.heading}</p>}
            {section.links.map(({ to, label, end, Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) => `app-nav-link ${isActive ? "app-nav-link-active" : ""}`}
              >
                <Icon size={19} />
                <span>{label}</span>
              </NavLink>
            ))}
          </div>
        ))}
      </nav>
      <div className="sidebar-user">
        <span className="sidebar-user-avatar">{(displayName || "?")[0].toUpperCase()}</span>
        <span className="sidebar-user-name">
          {displayName}
          {role && <small className="sidebar-user-role">{role}</small>}
        </span>
        <button
          type="button"
          className="sidebar-logout-btn"
          onClick={handleLogout}
          title="Sign out"
          aria-label="Sign out"
        >
          <IconLogout size={16} />
        </button>
      </div>
      <div className="app-sidebar-footer">
        <span className={`status-dot ${connected ? "status-dot-on" : "status-dot-off"}`} />
        <IconPulse size={16} />
        <span>{connected ? "Backend connected" : "Backend unreachable"}</span>
      </div>
    </aside>
  );
}
