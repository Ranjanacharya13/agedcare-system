import { useAuth } from "../../context/AuthContext.jsx";
import EmptyState from "../common/EmptyState.jsx";

/**
 * Route-level authorisation. Wrap a page whose whole purpose is off-limits to
 * some roles:
 *
 *   <RequireRole group="users"><UsersPage /></RequireRole>
 *
 * Renders an explanation rather than redirecting, because silently bouncing
 * someone to the dashboard reads as a bug. The backend enforces the same rule
 * regardless of what this component does.
 */
export default function RequireRole({ group, action = "read", children }) {
  const { can, role } = useAuth();

  if (!can(group, action)) {
    return (
      <EmptyState
        title="You don't have access to this page"
        message={`Your role (${role ?? "unknown"}) can't view ${group.replace(/_/g, " ")}. Ask an administrator if you think this is wrong.`}
      />
    );
  }
  return children;
}

/** Inline variant for hiding a single control — a delete button, a tab. */
export function IfAllowed({ group, action = "read", children, fallback = null }) {
  const { can } = useAuth();
  return can(group, action) ? children : fallback;
}
