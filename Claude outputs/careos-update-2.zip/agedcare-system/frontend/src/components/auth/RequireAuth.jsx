import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";

export default function RequireAuth({ children }) {
  const { isAuthenticated, isChecking } = useAuth();
  const location = useLocation();

  // While the stored token is being verified we are neither signed in nor
  // signed out. Redirecting here would kick the user to /login on every page
  // refresh and lose the URL they were on.
  if (isChecking) {
    return (
      <div className="public-page">
        <p className="text-muted">Checking your session…</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  return children;
}
