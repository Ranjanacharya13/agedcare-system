import { Component } from "react";

/**
 * Catches render-time exceptions so one broken component does not blank the
 * whole admin console. React has no hook equivalent — an error boundary must
 * still be a class.
 *
 * `resetKey` lets the boundary recover on navigation: when the route changes,
 * the key changes, and a previously-failed subtree gets another attempt
 * instead of staying broken until a full page reload.
 */
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidUpdate(prevProps) {
    if (prevProps.resetKey !== this.props.resetKey && this.state.error) {
      this.setState({ error: null });
    }
  }

  componentDidCatch(error, info) {
    // Nothing collects these yet; when an error reporter is added, this is the
    // one place to send them from.
    console.error("Unhandled UI error:", error, info?.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <div className="empty-state" role="alert">
        <p className="empty-state-title">Something went wrong on this screen</p>
        <p className="text-muted">
          The rest of the app is still working. Try again, or move to another page.
        </p>
        <button
          type="button"
          className="btn btn-primary btn-md"
          onClick={() => this.setState({ error: null })}
        >
          Try again
        </button>
      </div>
    );
  }
}
