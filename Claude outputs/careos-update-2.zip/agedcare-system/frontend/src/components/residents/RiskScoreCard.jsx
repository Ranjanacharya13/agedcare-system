import { useState } from "react";
import { useAsync } from "../../hooks/useAsync.js";
import { getResidentRiskScore } from "../../api/riskScores.js";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import RiskWeightExplainer from "./RiskWeightExplainer.jsx";

/**
 * The resident's risk score and what makes it up.
 *
 * Each row shows the observation, how much weight that signal carries, and
 * the points it contributed — because "82, Critical" on its own is a verdict
 * rather than information. The weights are the same for every resident, so
 * their derivation sits behind a disclosure rather than taking up room here.
 */
export default function RiskScoreCard({ residentId }) {
  const { data, loading, error } = useAsync(() => getResidentRiskScore(residentId), [residentId]);
  // The derivation is fetched only once someone opens it — most people
  // looking at a score never need to ask where the weights came from.
  const [explainerOpen, setExplainerOpen] = useState(false);

  if (loading) return <Skeleton rows={5} />;
  if (error) return <ErrorBanner error={error} />;
  if (!data) return null;

  const rows = Object.entries(data.breakdown);
  const hasWeights = rows.some(([, item]) => item.weight > 0);

  return (
    <div className="risk-score-card fade-slide-in">
      <div className="risk-score-summary">
        <div className="risk-score-ring">
          <span className="risk-score-number">{data.score}</span>
        </div>
        <div>
          <StatusBadge value={data.band} badgeKind="riskBand" />
          <p className="text-muted" style={{ margin: "var(--space-1) 0 0" }}>
            Out of a possible 100 points.
          </p>
        </div>
      </div>
      <table className="breakdown-table">
        <thead>
          <tr>
            <th>Signal</th>
            <th>Observed</th>
            {hasWeights && <th>Weight</th>}
            <th>Points</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(([key, item]) => (
            <tr key={key}>
              <td>{key.replaceAll("_", " ")}</td>
              <td>{item.value}</td>
              {hasWeights && <td>{Math.round(item.weight * 100)}%</td>}
              <td>{item.points}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {hasWeights && (
        <details
          className="weight-disclosure"
          onToggle={(event) => setExplainerOpen(event.currentTarget.open)}
        >
          <summary>How this score is calculated</summary>
          {explainerOpen && <RiskWeightExplainer />}
        </details>
      )}
    </div>
  );
}
