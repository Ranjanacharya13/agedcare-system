import { useCallback, useState } from "react";
import { useAsync } from "../../hooks/useAsync.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { getSuggestedCarers } from "../../api/algorithms.js";
import { createAssignment } from "../../api/assignments.js";
import { isAborted } from "../../api/client.js";
import { facilityDayKey } from "../../utils/time.js";
import Button from "../common/Button.jsx";
import Skeleton from "../common/Skeleton.jsx";
import ErrorBanner from "../common/ErrorBanner.jsx";

const SHOWN = 3;

/**
 * Who this resident should probably be assigned to, and a way to do it.
 *
 * Sits beside the "add assignment" form rather than on a separate screen:
 * the ranking is only useful at the moment someone is choosing. Each name
 * carries the reason it was ranked there, so the choice is an agreement
 * rather than a deferral — and any of them can be assigned in one click,
 * because making the user retype a name the system just recommended is how
 * a suggestion becomes an irritation.
 *
 * A failure to *load* is swallowed to nothing: a suggestion that cannot be
 * fetched must never stop anyone assigning a carer by hand. A failure to
 * *assign* is shown, because that one is the user's action.
 */
export default function SuggestedCarers({
  residentId,
  version = 0,
  hasPrimary = false,
  onAssigned,
}) {
  const { can } = useAuth();
  const [assigning, setAssigning] = useState(null);
  const [error, setError] = useState(null);

  const load = useCallback(
    (signal) => getSuggestedCarers(residentId, { signal }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [residentId, version]
  );
  const { data, loading, error: loadError } = useAsync(load, [load]);

  // The resident's first carer should be their named key worker; after that,
  // additional carers are support rather than the point of contact.
  const assignmentType = hasPrimary ? "Secondary" : "Primary";

  const assign = async (candidate) => {
    setAssigning(candidate.employee_id);
    setError(null);
    try {
      await createAssignment(residentId, {
        employee_id: candidate.employee_id,
        assignment_type: assignmentType,
        start_date: facilityDayKey(),
      });
      onAssigned?.();
    } catch (err) {
      if (!isAborted(err)) setError(err);
    } finally {
      setAssigning(null);
    }
  };

  // Shown only to whoever can act on it: a care worker reads the care team
  // but does not change it, so a ranking would be advice they cannot take.
  if (!can("assignments", "write")) return null;
  if (loading) return <Skeleton rows={2} />;
  if (loadError || !data?.length) return null;

  return (
    <div className="suggestion-box">
      <p className="suggestion-heading">
        Suggested {hasPrimary ? "backup carer" : "key worker"}
        {hasPrimary && <span className="text-muted"> &mdash; this resident already has a key worker</span>}
      </p>

      <ErrorBanner error={error} />

      <ul className="suggestion-list">
        {data.slice(0, SHOWN).map((candidate, index) => (
          <li key={candidate.employee_id}>
            <span className="suggestion-person">
              <strong>
                {candidate.first_name} {candidate.last_name}
              </strong>
              {candidate.role && <span className="text-muted"> · {candidate.role}</span>}
              <small className="suggestion-reason">{candidate.reason}</small>
            </span>
            <Button
              size="sm"
              variant={index === 0 ? "primary" : "secondary"}
              onClick={() => assign(candidate)}
              disabled={Boolean(assigning)}
            >
              {assigning === candidate.employee_id
                ? "Assigning…"
                : `Assign as ${hasPrimary ? "backup" : "key worker"}`}
            </Button>
          </li>
        ))}
      </ul>

      <p className="suggestion-footnote">
        Ranked by who already knows this resident (their chart entries this month), how much each
        carer is already carrying, and how well their role fits this resident&rsquo;s needs.
        Advisory only &mdash; use the form below to pick someone else.
      </p>
    </div>
  );
}
