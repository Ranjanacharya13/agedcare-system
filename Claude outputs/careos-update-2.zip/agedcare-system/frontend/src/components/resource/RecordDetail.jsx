import { useDirectory } from "../../hooks/useDirectory.js";
import { formatDateTime } from "../../utils/format.js";
import { renderValue } from "./ResourceTable.jsx";
import RecordHistory from "./RecordHistory.jsx";

/**
 * Every field of one record, read-only. The table shows a few columns so it
 * can be scanned; this is where the rest lives — the full incident
 * description, the interventions, the notes — without opening an edit form
 * just to read something.
 */
export default function RecordDetail({ resource, record }) {
  const directory = useDirectory();
  const fields = resource.fields.filter((f) => f.type !== "group");

  return (
    <>
    <dl className="record-detail">
      {fields.map((field) => (
        <div
          key={field.name}
          className={`record-detail-row${field.type === "textarea" ? " is-long" : ""}`}
        >
          <dt>{field.label}</dt>
          <dd>{renderValue(field, record, directory, { full: true, format: resource.formats?.[field.name] })}</dd>
        </div>
      ))}
      {resource.timestampField && (
        <div className="record-detail-row">
          <dt>Recorded</dt>
          <dd>{formatDateTime(record[resource.timestampField])}</dd>
        </div>
      )}
    </dl>
    <RecordHistory slug={resource.slug} recordId={record.id} />
    </>
  );
}
