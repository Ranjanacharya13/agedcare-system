import { useCallback } from "react";
import { useAuth } from "../../context/AuthContext.jsx";
import { useAsync } from "../../hooks/useAsync.js";
import { listAuditLogForRecord } from "../../api/auth.js";
import StatusBadge from "../common/StatusBadge.jsx";
import { Changes } from "../../pages/AuditLogPage.jsx";
import { formatDateTime } from "../../utils/format.js";

/** URL slug → database table, as the audit log names it. */
const TABLE_BY_SLUG = {
  medications: "resident_medications",
  "medical-history": "resident_medical_history",
  "medical-inventory": "resident_medical_inventory",
  "sleep-chart": "resident_sleep_chart",
  "bowel-chart": "resident_bowel_chart",
  behaviour: "resident_behaviour",
  assistance: "resident_assistance",
  "fall-risk": "resident_fall_risk",
  incidents: "resident_incidents",
  assignments: "resident_assignments",
  shifts: "employee_shifts",
  availability: "employee_availability",
  "time-entries": "employee_time_entries",
  contracts: "employee_contracts",
  payroll: "employee_payroll_records",
  leave: "employee_leave",
  performance: "employee_performance",
  supervision: "employee_supervision",
  registration: "employee_registration",
  qualifications: "employee_qualifications",
  complaints: "complaints_feedback",
  appointments: "appointments",
};

/**
 * Who changed this record, when, and what they changed — from the audit
 * log (GET /audit-log/{table}/{id}). Only for roles that may read the audit
 * log; everyone else simply does not see the section.
 */
export default function RecordHistory({ slug, recordId }) {
  const { can } = useAuth();
  const table = TABLE_BY_SLUG[slug];
  const allowed = can("audit", "read") && Boolean(table) && Boolean(recordId);

  const load = useCallback(
    (signal) => (allowed ? listAuditLogForRecord(table, recordId, { signal }) : Promise.resolve(null)),
    [allowed, table, recordId]
  );
  const { data, loading } = useAsync(load, [load]);

  if (!allowed) return null;

  return (
    <section className="record-history">
      <h4>Change history</h4>
      {loading ? (
        <p className="text-muted">Loading…</p>
      ) : !data?.length ? (
        <p className="text-muted">
          No changes recorded through CareOS yet (records loaded by the demo seed are not logged).
        </p>
      ) : (
        <ol className="record-history-list">
          {data.map((entry) => (
            <li key={entry.id}>
              <span className="record-history-head">
                <StatusBadge value={entry.action} badgeKind="auditAction" />
                <span>{entry.actor_email || "system"}</span>
                <span className="text-muted">{formatDateTime(entry.created_at)}</span>
              </span>
              <Changes changes={readable(entry.changes)} />
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

/** Bookkeeping columns (ids, timestamps) say nothing a person needs here. */
const HIDDEN = new Set(["id", "created_at", "updated_at", "resident_id", "employee_id"]);
function readable(changes) {
  if (!changes) return changes;
  return Object.fromEntries(Object.entries(changes).filter(([field]) => !HIDDEN.has(field)));
}
