import { Link } from "react-router-dom";
import { useCallback } from "react";
import { useAsync } from "../../hooks/useAsync.js";
import { useRecords } from "../../hooks/useRecords.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { getCaseload } from "../../api/assignments.js";
import {
  availability,
  contracts,
  leave,
  performance,
  qualifications,
  registration,
  shifts,
} from "../../config/employeeResourceConfigs.js";
import InfoCard from "../common/InfoCard.jsx";
import KeyValue from "../common/KeyValue.jsx";
import StatusBadge from "../common/StatusBadge.jsx";
import Skeleton from "../common/Skeleton.jsx";
import { daysUntil, formatDayLabel, formatNpr, formatShortDate, formatTimeRange } from "../../utils/format.js";
import { addDaysToKey, facilityInstant, mondayKey } from "../../utils/time.js";

const WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function CardBody({ state, empty, children }) {
  if (state.loading) return <Skeleton rows={2} />;
  if (state.error) return <p className="text-muted">Not available.</p>;
  if (!state.data || (Array.isArray(state.data) && state.data.length === 0)) {
    return <p className="text-muted">{empty}</p>;
  }
  return children(state.data);
}

function expiryNote(date) {
  const days = daysUntil(date);
  if (days === null) return <span className="text-muted">no expiry</span>;
  if (days < 0) return <span className="expiry expiry-past">expired {-days} days ago</span>;
  if (days <= 60) return <span className="expiry expiry-soon">expires in {days} days</span>;
  return <span className="text-muted">valid to {formatShortDate(date)}</span>;
}

/**
 * A staff member at a glance: their week, the residents they look after,
 * when they can work — and, for managers, the employment side: contract,
 * credentials that are about to lapse, leave waiting for a decision.
 */
export default function EmployeeOverview({ employeeId }) {
  const base = `/admin/employees/${employeeId}`;
  const { can } = useAuth();
  const hr = can("employee_hr", "read");

  const rota = useRecords(shifts, employeeId, { limit: 80 });
  const days = useRecords(availability, employeeId);
  const contract = useRecords(contracts, employeeId, { enabled: hr });
  const regs = useRecords(registration, employeeId, { enabled: hr });
  const quals = useRecords(qualifications, employeeId, { enabled: hr });
  const leaveState = useRecords(leave, employeeId, { enabled: hr });
  const reviews = useRecords(performance, employeeId, { limit: 1, enabled: hr });

  const loadCaseload = useCallback(
    (signal) => (can("assignments", "read") ? getCaseload(employeeId, { signal }) : Promise.resolve(null)),
    [employeeId, can]
  );
  const caseload = useAsync(loadCaseload, [loadCaseload]);

  // The facility's week, Monday to Sunday.
  const weekStart = facilityInstant(mondayKey());
  const weekEnd = facilityInstant(addDaysToKey(mondayKey(), 7));

  return (
    <div className="overview-grid">
      <InfoCard title="This week" to={`${base}/shifts`} linkLabel="All shifts">
        <CardBody state={rota} empty="Nothing rostered.">
          {(rows) => {
            const week = rows
              .filter((s) => new Date(s.shift_start) >= weekStart && new Date(s.shift_start) < weekEnd)
              .sort((a, b) => new Date(a.shift_start) - new Date(b.shift_start));
            const hours = week.reduce(
              (sum, s) => sum + (new Date(s.shift_end) - new Date(s.shift_start)) / 3600000,
              0
            );
            if (!week.length) return <p className="text-muted">No shifts this week.</p>;
            return (
              <>
                <ul className="overview-list overview-list-plain">
                  {week.map((s) => (
                    <li key={s.id}>
                      <span>
                        <strong>{formatDayLabel(s.shift_start)}</strong>{" "}
                        <span className="text-muted">{formatTimeRange(s.shift_start, s.shift_end)}</span>
                      </span>
                      <StatusBadge value={s.status} badgeKind="shiftStatus" />
                    </li>
                  ))}
                </ul>
                <p className="text-muted">{hours} hours rostered this week</p>
              </>
            );
          }}
        </CardBody>
      </InfoCard>

      {can("assignments", "read") && (
        <InfoCard title="Residents" to={`${base}/caseload`} linkLabel="All residents">
          <CardBody state={caseload} empty="Not assigned to any resident.">
            {(data) => {
              const active = data.residents.filter((r) => r.active);
              if (!active.length) return <p className="text-muted">Not assigned to any resident.</p>;
              return (
                <>
                  <ul className="overview-list">
                    {active.slice(0, 5).map((r) => (
                      <li key={r.assignment_id}>
                        <Link to={`/admin/residents/${r.resident_id}`}>
                          {r.first_name} {r.last_name}
                        </Link>
                        <StatusBadge value={r.assignment_type} badgeKind="assignmentType" />
                        {r.risk_band && <StatusBadge value={r.risk_band} badgeKind="riskBand" />}
                      </li>
                    ))}
                  </ul>
                  <p className="text-muted">
                    Key worker for {data.primary_count} · combined risk load {data.total_risk_load}
                  </p>
                  {can("assignments", "write") && (
                    <p>
                      <Link to={`/admin/coverage?handover=${employeeId}`}>
                        Leaving or changing wing? Hand over these residents →
                      </Link>
                    </p>
                  )}
                </>
              );
            }}
          </CardBody>
        </InfoCard>
      )}

      <InfoCard title="Usual availability" to={`${base}/availability`} linkLabel="Edit">
        <CardBody state={days} empty="No availability recorded.">
          {(rows) => {
            const byDay = Object.fromEntries(rows.map((r) => [r.weekday, r]));
            return (
              <div className="day-chips">
                {WEEK.map((day) => {
                  const entry = byDay[day];
                  const on = entry?.available;
                  return (
                    <span key={day} className={`day-chip${on ? " is-on" : ""}`} title={on ? `${entry.start_time?.slice(0, 5)}–${entry.end_time?.slice(0, 5)}` : "Not available"}>
                      {day.slice(0, 3)}
                      {on && <small>{entry.start_time?.slice(0, 5)}</small>}
                    </span>
                  );
                })}
              </div>
            );
          }}
        </CardBody>
      </InfoCard>

      {hr && (
        <>
          <InfoCard title="Contract" to={`${base}/contracts`} linkLabel="Contract">
            <CardBody state={contract} empty="No contract on file.">
              {(rows) => (
                <KeyValue
                  items={[
                    ["Type", rows[0].contract_type],
                    ["Hours", rows[0].contracted_hours ? `${rows[0].contracted_hours} h / week` : null],
                    ["Rate", rows[0].hourly_rate ? `${formatNpr(rows[0].hourly_rate)} / hour` : null],
                    ["Since", formatShortDate(rows[0].start_date)],
                    ["Ends", rows[0].end_date ? formatShortDate(rows[0].end_date) : null],
                  ]}
                />
              )}
            </CardBody>
          </InfoCard>

          <InfoCard title="Credentials" to={`${base}/credentials`} linkLabel="All credentials">
            {regs.loading || quals.loading ? (
              <Skeleton rows={3} />
            ) : (
              (() => {
                const items = [
                  ...(regs.data || []).map((r) => ({
                    id: r.id,
                    name: r.registration_type,
                    detail: [r.issuing_authority, r.registration_number].filter(Boolean).join(" · "),
                    expiry: r.expiry_date,
                    verified: r.verified,
                  })),
                  ...(quals.data || []).map((q) => ({
                    id: q.id,
                    name: q.qualification_name,
                    detail: q.institution,
                    expiry: q.expiry_date,
                  })),
                ].sort((a, b) => (daysUntil(a.expiry) ?? 9999) - (daysUntil(b.expiry) ?? 9999));
                if (!items.length) return <p className="text-muted">No credentials recorded.</p>;
                return (
                  <ul className="overview-list overview-list-plain">
                    {items.slice(0, 5).map((c) => (
                      <li key={c.id}>
                        <span>
                          <strong>{c.name}</strong>
                          {c.verified === false && <span className="badge badge-warning"> unverified</span>}
                        </span>
                        <span className="text-muted">
                          {c.detail} · {expiryNote(c.expiry)}
                        </span>
                      </li>
                    ))}
                  </ul>
                );
              })()
            )}
          </InfoCard>

          <InfoCard title="Leave" to={`${base}/leave`} linkLabel="All leave">
            <CardBody state={leaveState} empty="No leave requested.">
              {(rows) => {
                const upcoming = rows
                  .filter((l) => daysUntil(l.end_date) >= 0)
                  .sort((a, b) => new Date(a.start_date) - new Date(b.start_date));
                if (!upcoming.length) return <p className="text-muted">No upcoming leave.</p>;
                return (
                  <ul className="overview-list overview-list-plain">
                    {upcoming.map((l) => (
                      <li key={l.id}>
                        <span>
                          <strong>{l.leave_type}</strong>{" "}
                          <span className="text-muted">
                            {formatShortDate(l.start_date)} – {formatShortDate(l.end_date)}
                          </span>
                        </span>
                        <StatusBadge value={l.status} badgeKind="leaveStatus" />
                      </li>
                    ))}
                  </ul>
                );
              }}
            </CardBody>
          </InfoCard>

          <InfoCard title="Latest review" to={`${base}/performance`} linkLabel="Reviews">
            <CardBody state={reviews} empty="No review yet.">
              {(rows) => (
                <>
                  <p>
                    <span className="stars stars-lg" aria-label={`${rows[0].overall_rating} out of 5`}>
                      {"★".repeat(rows[0].overall_rating || 0)}
                      <span className="stars-empty">{"★".repeat(5 - (rows[0].overall_rating || 0))}</span>
                    </span>{" "}
                    <span className="text-muted">{formatShortDate(rows[0].review_date)}</span>
                  </p>
                  <KeyValue
                    items={[
                      ["Strengths", rows[0].strengths],
                      ["Goals", rows[0].goals],
                      ["Next review", formatShortDate(rows[0].next_review)],
                    ]}
                  />
                </>
              )}
            </CardBody>
          </InfoCard>
        </>
      )}
    </div>
  );
}
