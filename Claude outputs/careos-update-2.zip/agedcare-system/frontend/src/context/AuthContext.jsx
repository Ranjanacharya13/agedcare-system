import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import {
  UNAUTHORIZED_EVENT,
  authEvents,
  getToken,
  setToken,
} from "../api/client.js";
import { fetchCurrentUser, login as loginRequest } from "../api/auth.js";
import { can } from "../config/permissions.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  // Three states, not two: "no user yet" and "we haven't checked yet" must be
  // distinguishable, or a refresh on /admin bounces the user to the login
  // screen for a frame before the token check comes back.
  const [status, setStatus] = useState(getToken() ? "checking" : "anonymous");

  const signOut = useCallback(() => {
    setToken(null);
    setUser(null);
    setStatus("anonymous");
  }, []);

  // On boot, exchange any stored token for the current account. This is also
  // how a role change or a deactivation takes effect: the server decides, not
  // whatever was cached in the browser.
  useEffect(() => {
    if (!getToken()) return undefined;

    const controller = new AbortController();
    fetchCurrentUser({ signal: controller.signal })
      .then((me) => {
        setUser(me);
        setStatus("authenticated");
      })
      .catch(() => {
        // Expired, revoked, or the server is unreachable. Either way there is
        // nothing useful to show behind the login wall.
        setToken(null);
        setUser(null);
        setStatus("anonymous");
      });

    return () => controller.abort();
  }, []);

  // Any request anywhere in the app that comes back 401 ends the session, so
  // an expired token does not leave the user clicking into empty screens.
  useEffect(() => {
    const handler = () => signOut();
    authEvents.addEventListener(UNAUTHORIZED_EVENT, handler);
    return () => authEvents.removeEventListener(UNAUTHORIZED_EVENT, handler);
  }, [signOut]);

  const login = useCallback(async (email, password) => {
    const response = await loginRequest(email, password);
    setToken(response.access_token);
    setUser(response.user);
    setStatus("authenticated");
    return response.user;
  }, []);

  const value = useMemo(
    () => ({
      user,
      status,
      isAuthenticated: status === "authenticated",
      isChecking: status === "checking",
      role: user?.access_role ?? null,
      displayName: user?.full_name || user?.email || "Staff",
      login,
      logout: signOut,
      /** Ask before rendering: `can("employee_hr", "read")`. */
      can: (group, action = "read") => can(user?.access_role, group, action),
    }),
    [user, status, login, signOut]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
