// Mirror of backend/config/permissions.py.
//
// This copy exists to decide what to *render* — hiding a nav link a nurse
// cannot use is better than letting them click into a 403. It is not a
// security boundary: the backend re-checks every request, and a user who
// edits this file in devtools gains nothing but a menu item that 403s.
//
// If you change the backend matrix, change this one too. The two are kept in
// step by hand deliberately: generating one from the other would need a build
// step, and the frontend only needs the handful of groups the UI branches on.

export const ACCESS_ROLES = {
  ADMIN: "Admin",
  MANAGER: "Manager",
  NURSE: "Nurse",
  CARE_WORKER: "Care Worker",
  FAMILY: "Family",
};

const { ADMIN, MANAGER, NURSE, CARE_WORKER } = ACCESS_ROLES;

const ALL_STAFF = [ADMIN, MANAGER, NURSE, CARE_WORKER];
const CLINICAL_STAFF = [ADMIN, MANAGER, NURSE];
const LEADERSHIP = [ADMIN, MANAGER];
const ADMIN_ONLY = [ADMIN];

export const PERMISSIONS = {
  residents: { read: ALL_STAFF, write: CLINICAL_STAFF },
  resident_charts: { read: ALL_STAFF, write: ALL_STAFF },
  resident_clinical: { read: ALL_STAFF, write: CLINICAL_STAFF },
  employees: { read: ALL_STAFF, write: LEADERSHIP },
  // Who cares for whom. All staff read it; nurses and leadership decide it.
  assignments: { read: ALL_STAFF, write: CLINICAL_STAFF },
  employee_roster: { read: ALL_STAFF, write: LEADERSHIP },
  employee_hr: { read: LEADERSHIP, write: LEADERSHIP },
  complaints: { read: LEADERSHIP, write: LEADERSHIP },
  appointments: { read: ALL_STAFF, write: LEADERSHIP },
  analytics: { read: ALL_STAFF, write: [] },
  // Running the roster optimiser: anyone may view the page, leadership may
  // trigger a solve. Mirrors backend/config/permissions.py.
  roster_planning: { read: ALL_STAFF, write: LEADERSHIP },
  users: { read: ADMIN_ONLY, write: ADMIN_ONLY },
  audit: { read: LEADERSHIP, write: [] },
};

export function can(role, group, action = "read") {
  if (!role) return false;
  return (PERMISSIONS[group]?.[action] ?? []).includes(role);
}
