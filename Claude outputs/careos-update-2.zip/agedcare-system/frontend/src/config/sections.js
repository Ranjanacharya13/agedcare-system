import * as residentConfigs from "./residentResourceConfigs.js";
import * as employeeConfigs from "./employeeResourceConfigs.js";

// How each record type is *presented*: which permission group guards it,
// what it is called on screen, the handful of columns worth scanning, and a
// line saying what the record is for. The field lists in the resource
// configs stay the source of truth for forms; this only decides what a
// table shows before someone opens a row to see everything.
//
// `group` mirrors the backend router (backend/api/v1/router.py). The screen
// hides add/edit/delete from roles that cannot write the group, rather than
// letting them try and fail.

const WEEKDAY_ORDER = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const display = {
  // --- resident: health -----------------------------------------------------
  medications: {
    group: "resident_clinical",
    title: "Medications",
    columns: ["medication_name", "dosage", "frequency", "route", "active"],
    description:
      "Current and past prescriptions. A stopped medication stays on record — why it was stopped matters.",
  },
  "medical-history": {
    group: "resident_clinical",
    title: "Medical history",
    columns: ["diagnosis", "allergies", "doctor_name"],
    description: "Diagnoses, allergies and the treating doctor.",
  },
  "medical-inventory": {
    group: "resident_clinical",
    title: "Supplies",
    columns: ["item_name", "quantity", "unit", "expiry_date"],
    formats: { expiry_date: "expiry" },
    description: "Personal medical supplies kept for this resident, with expiry dates.",
  },
  // --- resident: daily care ---------------------------------------------------
  "sleep-chart": {
    group: "resident_charts",
    title: "Sleep",
    columns: ["sleep_date", "sleep_start", "wake_time", "total_hours", "disturbances", "recorded_by"],
    description: "One entry per night. Who records it also tells the system who knows this resident.",
  },
  "bowel-chart": {
    group: "resident_charts",
    title: "Bowel",
    columns: ["bowel_type", "consistency", "recorded_by"],
    description: "Bristol stool scale observations.",
  },
  behaviour: {
    group: "resident_charts",
    title: "Behaviour",
    columns: ["behaviour", "trigger", "outcome", "recorded_by"],
    description:
      "What happened, what set it off, what helped. Events in the last 30 days count towards the risk score.",
  },
  assistance: {
    group: "resident_charts",
    title: "Mobility",
    columns: ["assistance_level", "mobility", "transfer_notes", "updated_by"],
    description: "How much help this resident needs to move. The latest entry feeds the risk score.",
  },
  // --- resident: safety -------------------------------------------------------
  "fall-risk": {
    group: "resident_clinical",
    title: "Fall risk",
    columns: ["risk_level", "assessment_date", "assessed_by", "interventions"],
    description: "Assessments over time. The most recent one is what the risk score uses.",
  },
  incidents: {
    group: "resident_charts",
    title: "Incidents",
    columns: ["occurred_at", "incident_type", "severity", "status", "reported_by"],
    description: "Falls, errors and other events. Incidents in the last 90 days count towards the risk score.",
  },
  // --- employee: roster -------------------------------------------------------
  shifts: {
    group: "employee_roster",
    title: "Shifts",
    columns: ["shift_start", "shift_end", "role", "location", "status"],
    description: "This person's rostered shifts. The whole facility's week is on the Roster page.",
  },
  availability: {
    group: "employee_roster",
    title: "Availability",
    columns: ["weekday", "start_time", "end_time", "available"],
    sort: (a, b) => WEEKDAY_ORDER.indexOf(a.weekday) - WEEKDAY_ORDER.indexOf(b.weekday),
    description: "The days and hours this person is normally available.",
  },
  "time-entries": {
    group: "employee_roster",
    title: "Time sheet",
    columns: ["clock_in", "clock_out", "notes"],
    description: "Clock-in and clock-out against rostered shifts.",
  },
  // --- employee: HR -----------------------------------------------------------
  contracts: {
    group: "employee_hr",
    title: "Contract",
    columns: ["contract_type", "contracted_hours", "hourly_rate", "start_date", "end_date"],
    formats: { hourly_rate: "npr" },
    description: "Terms of employment. Rates are in Nepali rupees per hour.",
  },
  payroll: {
    group: "employee_hr",
    title: "Pay",
    columns: ["pay_period_start", "pay_period_end", "total_hours", "gross_pay", "net_pay", "status"],
    formats: { gross_pay: "npr", net_pay: "npr", deductions: "npr", hourly_rate: "npr" },
    description: "Monthly pay runs. Deductions include the employee's SSF contribution.",
  },
  leave: {
    group: "employee_hr",
    title: "Leave",
    columns: ["leave_type", "start_date", "end_date", "status", "approved_by"],
    description: "Leave requests and their approval.",
  },
  performance: {
    group: "employee_hr",
    title: "Reviews",
    columns: ["review_date", "overall_rating", "reviewer", "next_review"],
    formats: { overall_rating: "stars" },
    description: "Annual performance reviews.",
  },
  supervision: {
    group: "employee_hr",
    title: "Supervision",
    columns: ["supervision_date", "supervisor", "discussion", "follow_up_date"],
    description: "One-to-one supervision sessions and what was agreed.",
  },
  // --- employee: credentials ----------------------------------------------------
  registration: {
    group: "employee_hr",
    title: "Registrations",
    columns: ["registration_type", "registration_number", "issuing_authority", "expiry_date", "verified"],
    formats: { expiry_date: "expiry" },
    description:
      "Professional registrations — Nepal Nursing Council, Nepal Health Professional Council, skill tests.",
  },
  qualifications: {
    group: "employee_hr",
    title: "Qualifications",
    columns: ["qualification_name", "institution", "completion_date", "expiry_date"],
    formats: { expiry_date: "expiry" },
    description: "Degrees, certificates and renewable training such as Basic Life Support.",
  },
};

function withDisplay(config) {
  return { ...config, ...(display[config.slug] || {}) };
}

export const R = Object.fromEntries(
  residentConfigs.residentResourceConfigs.concat([residentConfigs.medicalHistory]).map((c) => [c.slug, withDisplay(c)])
);
export const E = Object.fromEntries(employeeConfigs.employeeResourceConfigs.map((c) => [c.slug, withDisplay(c)]));

// A "part" is either a record type (rendered as a table) or a named custom
// panel (rendered by the page). Sections group parts the way a care manager
// thinks about a person: their health, their day, their safety.
export const RESIDENT_SECTIONS = [
  { key: "overview", label: "Overview" },
  { key: "care-team", label: "Care team", group: "assignments" },
  {
    key: "health",
    label: "Health",
    parts: [R.medications, R["medical-history"], R["medical-inventory"]],
  },
  {
    key: "daily-care",
    label: "Daily care",
    parts: [R["sleep-chart"], R["bowel-chart"], R.behaviour, R.assistance],
  },
  {
    key: "safety",
    label: "Safety & risk",
    parts: [
      { slug: "risk-score", title: "Risk score", group: "analytics", custom: true },
      R["fall-risk"],
      R.incidents,
    ],
  },
];

export const EMPLOYEE_SECTIONS = [
  { key: "overview", label: "Overview" },
  { key: "caseload", label: "Residents", group: "assignments" },
  { key: "roster", label: "Roster", parts: [E.shifts, E.availability, E["time-entries"]] },
  {
    key: "hr",
    label: "Employment",
    parts: [E.contracts, E.payroll, E.leave, E.performance, E.supervision],
  },
  { key: "credentials", label: "Credentials", parts: [E.registration, E.qualifications] },
];

/** Resolve a URL segment (a section key or a part slug) to {section, part}. */
export function locate(sections, segment) {
  if (!segment) return { section: sections[0], part: null };
  const direct = sections.find((s) => s.key === segment);
  if (direct) return { section: direct, part: direct.parts?.[0] || null };
  for (const section of sections) {
    const part = section.parts?.find((p) => p.slug === segment);
    if (part) return { section, part };
  }
  return { section: sections[0], part: null };
}

/** The sections a role can see: a section shows if any of its parts can be read. */
export function visibleSections(sections, can) {
  return sections
    .map((section) => {
      if (!section.parts) return !section.group || can(section.group, "read") ? section : null;
      const parts = section.parts.filter((p) => !p.group || can(p.group, "read"));
      return parts.length ? { ...section, parts } : null;
    })
    .filter(Boolean);
}
