import { useEffect, useState } from "react";
import { isAborted } from "../api/client.js";

// Generic {data, loading, error} wrapper for one-off GETs (risk score,
// shift suggestions, health check) that don't need the full CRUD machinery
// of useApiResource.
//
// `asyncFn` receives an AbortSignal. Pass it through to the API call so an
// in-flight request is actually cancelled when the component unmounts or the
// deps change — the previous version only ignored the late response, which
// left the request running and, on a fast click through several residents,
// meant several redundant round-trips racing each other.
export function useAsync(asyncFn, deps) {
  const [state, setState] = useState({ data: null, loading: true, error: null });

  useEffect(() => {
    const controller = new AbortController();
    let active = true;

    setState({ data: null, loading: true, error: null });

    Promise.resolve(asyncFn(controller.signal))
      .then((data) => {
        if (active) setState({ data, loading: false, error: null });
      })
      .catch((error) => {
        // A cancelled request is not a failure and must never render as one.
        if (!active || isAborted(error)) return;
        setState({ data: null, loading: false, error });
      });

    return () => {
      active = false;
      controller.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return state;
}
