"""Sliding-window rate limiting for unauthenticated endpoints.

Same single-process caveat as `login_throttle`: counts live in memory and do
not survive a restart or span workers. That is the right trade for the one
endpoint this guards — a public enquiry form where the cost of an occasional
extra submission is a duplicate email, not a breach.
"""

import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request, status


class SlidingWindowLimiter:
    def __init__(self, max_requests: int, window_seconds: int):
        self._max = max_requests
        self._window = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def check(self, key: str) -> int | None:
        """Record a hit. Returns None if allowed, else seconds until the
        window frees up."""
        now = time.monotonic()
        hits = self._hits[key]
        while hits and now - hits[0] >= self._window:
            hits.popleft()
        if len(hits) >= self._max:
            return max(1, int(self._window - (now - hits[0])))
        hits.append(now)
        return None

    def reset(self) -> None:
        self._hits.clear()


def client_ip(request: Request) -> str:
    """Prefer the left-most X-Forwarded-For entry when behind a proxy, since
    `request.client.host` would otherwise be the proxy for every visitor.
    Only trust this header if the deployment actually sits behind a proxy that
    sets it — otherwise a caller can spoof their own key."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limit_dependency(limiter: SlidingWindowLimiter):
    async def _check(request: Request) -> None:
        retry_after = limiter.check(client_ip(request))
        if retry_after is not None:
            raise HTTPException(
                status.HTTP_429_TOO_MANY_REQUESTS,
                "Too many requests. Please try again later.",
                headers={"Retry-After": str(retry_after)},
            )

    return _check
