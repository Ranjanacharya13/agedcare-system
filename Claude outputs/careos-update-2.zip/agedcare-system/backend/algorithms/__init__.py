"""Standalone algorithm implementations.

Everything in this package is written from first principles with no numerical
or scientific library behind it (no numpy, no scipy) and has no knowledge of
FastAPI, Supabase or this project's models. That separation is deliberate:

* it keeps the algorithms unit-testable against textbook examples, which is
  how their correctness is actually established;
* it makes the complexity analysis honest — what you read here is what runs;
* and it keeps them reusable, since neither one is specific to aged care.

The services in `backend/services/` are responsible for turning domain
objects into the plain numbers these functions accept, and for turning the
results back into something a nurse would recognise.
"""
