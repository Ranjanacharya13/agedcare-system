"""The Hungarian algorithm (Kuhn--Munkres) for optimal assignment.

Problem
-------
Given n workers, m tasks and a cost c[i][j] for giving task j to worker i,
choose at most one task per worker and at most one worker per task so that
the total cost of the chosen pairs is as small as possible.

Why not just pick greedily
--------------------------
A greedy pass — repeatedly take the cheapest remaining pair — is locally
sensible and globally wrong. Consider:

        t0   t1
    w0   1    2
    w1   1    9

Greedy takes (w0, t0) at cost 1 because it is the cheapest cell anywhere,
which forces (w1, t1) at 9, for a total of 10. The optimum is (w0, t1) and
(w1, t0), total 3. Greedy cannot see that spending one extra unit on w0
saves seven on w1. The gap is unbounded: replace 9 with any number.

The algorithm
-------------
This is the O(n^3) shortest-augmenting-path formulation rather than the
original O(n^4) matrix-marking one. It maintains dual variables (potentials)
u[i] for rows and v[j] for columns, kept feasible so that

    u[i] + v[j] <= c[i][j]   for every pair

Each of the n outer iterations adds one row to the matching by finding a
shortest augmenting path in the reduced-cost graph, using a Dijkstra-like
scan. Because complementary slackness holds throughout, the matching is
optimal the moment it is complete — the algorithm does not find a solution
and then improve it, it maintains optimality and extends coverage.

Complexity
----------
Time  O(n^2 * m), i.e. O(n^3) on a square matrix: n augmentations, each
      scanning O(m) columns O(n) times.
Space O(n * m) for the cost matrix, O(n + m) working state.

Forbidden pairs
---------------
Pass `math.inf` for a pair that must never be chosen (a nurse who is already
working at that hour). Infinity is replaced internally by a finite sentinel
larger than any achievable real total — arithmetic on inf produces nan and
would destroy the potentials — and any pair that ends up on the sentinel is
reported as unassigned rather than as a real, absurdly expensive assignment.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class AssignmentResult:
    """rows_to_cols[i] is the column assigned to row i, or None if row i
    could not be assigned (more rows than columns, or only forbidden pairs
    were available to it)."""

    rows_to_cols: list[int | None]
    total_cost: float

    @property
    def pairs(self) -> list[tuple[int, int]]:
        return [(i, j) for i, j in enumerate(self.rows_to_cols) if j is not None]

    @property
    def assigned_count(self) -> int:
        return sum(1 for j in self.rows_to_cols if j is not None)


def _sentinel_for(cost: list[list[float]]) -> float:
    """A finite stand-in for infinity: strictly larger than the worst total
    any all-finite assignment could reach, so the optimiser will only ever
    choose a forbidden pair when it has no alternative at all."""
    finite = [c for row in cost for c in row if not math.isinf(c)]
    if not finite:
        return 1.0
    span = max(abs(min(finite)), abs(max(finite)))
    rows = len(cost)
    cols = len(cost[0])
    return (span + 1.0) * (rows * cols + 1)


def solve_assignment(cost: list[list[float]]) -> AssignmentResult:
    """Minimise total cost. Returns which column each row received."""
    if not cost or not cost[0]:
        return AssignmentResult(rows_to_cols=[], total_cost=0.0)

    n_rows = len(cost)
    n_cols = len(cost[0])
    if any(len(row) != n_cols for row in cost):
        raise ValueError("Cost matrix must be rectangular")

    # The core routine requires rows <= cols. When that does not hold, solve
    # the transposed problem and flip the answer back: assignment is
    # symmetric, so the optimal total is identical either way.
    if n_rows > n_cols:
        transposed = [[cost[i][j] for i in range(n_rows)] for j in range(n_cols)]
        flipped = solve_assignment(transposed)
        rows_to_cols: list[int | None] = [None] * n_rows
        for col_index, row_index in enumerate(flipped.rows_to_cols):
            if row_index is not None:
                rows_to_cols[row_index] = col_index
        return AssignmentResult(rows_to_cols, flipped.total_cost)

    sentinel = _sentinel_for(cost)
    working = [
        [sentinel if math.isinf(value) else float(value) for value in row] for row in cost
    ]

    matched_row_for_col = _kuhn_munkres(working, n_rows, n_cols)

    rows_to_cols = [None] * n_rows
    total = 0.0
    for col in range(n_cols):
        row = matched_row_for_col[col]
        if row is None:
            continue
        # A pair sitting on the sentinel was never a real option; report the
        # row as unassigned rather than inventing a huge cost for it.
        if math.isinf(cost[row][col]):
            continue
        rows_to_cols[row] = col
        total += float(cost[row][col])

    return AssignmentResult(rows_to_cols=rows_to_cols, total_cost=total)


def _kuhn_munkres(cost: list[list[float]], n_rows: int, n_cols: int) -> list[int | None]:
    """The augmenting-path core. Returns, for each column, the row matched to
    it (or None). Uses 1-based internal indexing with a virtual column 0 as
    the path start, which is what makes the potential updates uniform.
    """
    inf = math.inf

    # u[i], v[j]: the dual potentials. way[j]: the column we arrived from on
    # the current augmenting path. matched[j]: row currently holding column j.
    u = [0.0] * (n_rows + 1)
    v = [0.0] * (n_cols + 1)
    matched = [0] * (n_cols + 1)
    way = [0] * (n_cols + 1)

    for row in range(1, n_rows + 1):
        matched[0] = row
        col = 0
        min_slack = [inf] * (n_cols + 1)
        visited = [False] * (n_cols + 1)

        # Grow a shortest-path tree until it reaches a free column.
        while True:
            visited[col] = True
            current_row = matched[col]
            delta = inf
            next_col = -1

            for j in range(1, n_cols + 1):
                if visited[j]:
                    continue
                reduced = cost[current_row - 1][j - 1] - u[current_row] - v[j]
                if reduced < min_slack[j]:
                    min_slack[j] = reduced
                    way[j] = col
                if min_slack[j] < delta:
                    delta = min_slack[j]
                    next_col = j

            if next_col == -1:  # pragma: no cover - only if n_cols < n_rows
                break

            # Shift the potentials by delta. This keeps every visited pair
            # tight (u[i] + v[j] == c[i][j]) while making one new column
            # reachable — the step that guarantees termination in n rounds.
            for j in range(n_cols + 1):
                if visited[j]:
                    u[matched[j]] += delta
                    v[j] -= delta
                else:
                    min_slack[j] -= delta

            col = next_col
            if matched[col] == 0:
                break

        # Walk the path back to the root, flipping matched/unmatched edges.
        while col:
            previous = way[col]
            matched[col] = matched[previous]
            col = previous

    # Convert the internal 1-based row numbers back to 0-based, and drop the
    # virtual column 0 that was only ever the path root.
    return [matched[j] - 1 if matched[j] != 0 else None for j in range(1, n_cols + 1)]


def greedy_assignment(cost: list[list[float]]) -> AssignmentResult:
    """Baseline for comparison: repeatedly take the cheapest available pair.

    Kept alongside the optimal solver on purpose. It is what the roster
    suggestion used before, it is what most people reach for first, and
    having both lets the system report exactly how much the optimal
    assignment saves on real data rather than asserting that it does.

    Complexity O(n*m*log(n*m)) — sort every cell once, then one pass.
    """
    if not cost or not cost[0]:
        return AssignmentResult(rows_to_cols=[], total_cost=0.0)

    n_rows = len(cost)
    n_cols = len(cost[0])

    cells = sorted(
        (
            (cost[i][j], i, j)
            for i in range(n_rows)
            for j in range(n_cols)
            if not math.isinf(cost[i][j])
        ),
        key=lambda cell: cell[0],
    )

    rows_to_cols: list[int | None] = [None] * n_rows
    used_cols: set[int] = set()
    total = 0.0

    for value, row, col in cells:
        if rows_to_cols[row] is not None or col in used_cols:
            continue
        rows_to_cols[row] = col
        used_cols.add(col)
        total += value

    return AssignmentResult(rows_to_cols=rows_to_cols, total_cost=total)
