"""The Analytic Hierarchy Process (Saaty, 1980) — deriving weights from
pairwise judgements, and checking those judgements for self-consistency.

The problem it solves
---------------------
A weighted scoring model needs weights. Asking someone "how many points is
fall risk worth out of 100?" produces numbers nobody can defend. People are
poor at assigning absolute magnitudes but reliable at *relative* ones: asked
"is fall risk more important than behaviour frequency, and by how much?", a
nurse gives a stable and meaningful answer.

AHP collects exactly those pairwise answers and turns them into weights.

Method
------
1. Build an n x n matrix A where a[i][j] is how many times more important
   criterion i is than criterion j, on Saaty's 1-9 scale. The matrix is
   reciprocal by construction: a[j][i] = 1 / a[i][j], and a[i][i] = 1.

2. The weight vector is the principal eigenvector of A, normalised to sum
   to 1. Intuition: if the judgements were perfectly consistent then
   a[i][j] = w[i]/w[j] exactly, and A would have rank 1 with A.w = n.w —
   the weights *are* the eigenvector. Real judgements are not perfectly
   consistent, and Perron-Frobenius guarantees that a positive matrix still
   has a unique positive principal eigenvector, which is the best available
   estimate. Computed here by power iteration.

3. Check consistency. Someone who says A beats B, B beats C, and C beats A
   has produced weights that mean nothing. Inconsistency shows up as the
   principal eigenvalue lambda_max drifting above n:

       CI = (lambda_max - n) / (n - 1)
       CR = CI / RI(n)

   where RI(n) is the average CI of randomly generated reciprocal matrices
   of that size (Saaty's published table below). Saaty's rule: CR < 0.10 is
   acceptable, otherwise the judgements should be revisited rather than
   used.

Complexity
----------
Power iteration is O(n^2) per step and converges geometrically at a rate set
by the ratio of the two largest eigenvalues; for the small, strongly
dominant matrices AHP produces it is a few dozen steps. n here is the number
of criteria (5), so the whole computation is negligible and is done once at
import rather than per request.
"""

from __future__ import annotations

from dataclasses import dataclass

#: Saaty's Random Consistency Index: the average CI of a large sample of
#: randomly filled reciprocal matrices of each size. A matrix is judged
#: against how inconsistent pure noise of the same size would be, which is
#: why the threshold is a ratio rather than an absolute number.
RANDOM_CONSISTENCY_INDEX = {
    1: 0.00,
    2: 0.00,
    3: 0.58,
    4: 0.90,
    5: 1.12,
    6: 1.24,
    7: 1.32,
    8: 1.41,
    9: 1.45,
    10: 1.49,
}

#: Saaty's rule of thumb for acceptable inconsistency.
CONSISTENCY_THRESHOLD = 0.10

#: The 1-9 scale, for anyone reading the judgement table.
SAATY_SCALE = {
    1: "equally important",
    2: "slightly toward moderate",
    3: "moderately more important",
    4: "moderate toward strong",
    5: "strongly more important",
    6: "strong toward very strong",
    7: "very strongly more important",
    8: "very strong toward extreme",
    9: "extremely more important",
}


@dataclass(frozen=True)
class AHPResult:
    criteria: list[str]
    weights: dict[str, float]
    lambda_max: float
    consistency_index: float
    consistency_ratio: float

    @property
    def is_consistent(self) -> bool:
        return self.consistency_ratio < CONSISTENCY_THRESHOLD

    @property
    def verdict(self) -> str:
        if self.is_consistent:
            return (
                f"Consistent (CR = {self.consistency_ratio:.3f} < {CONSISTENCY_THRESHOLD}); "
                "the pairwise judgements support these weights."
            )
        return (
            f"Inconsistent (CR = {self.consistency_ratio:.3f} >= {CONSISTENCY_THRESHOLD}); "
            "the pairwise judgements contradict each other and should be revisited."
        )


def build_matrix(criteria: list[str], judgements: dict[tuple[str, str], float]) -> list[list[float]]:
    """Expand a sparse set of judgements into the full reciprocal matrix.

    Only the upper triangle needs supplying — `("fall_risk", "behaviour"): 4`
    means fall risk is 4x more important, and the reciprocal 1/4 is filled in
    automatically. This halves what a domain expert has to answer and makes
    it impossible to contradict yourself in the trivial way (saying A>B and
    also B>A); the interesting inconsistencies are the transitive ones, which
    the consistency ratio catches.
    """
    index = {name: i for i, name in enumerate(criteria)}
    n = len(criteria)
    matrix = [[1.0] * n for _ in range(n)]

    for (left, right), value in judgements.items():
        if left not in index or right not in index:
            raise ValueError(f"Judgement references unknown criterion: {left!r} vs {right!r}")
        if value <= 0:
            raise ValueError(f"Judgement for {left} vs {right} must be positive, got {value}")
        i, j = index[left], index[right]
        matrix[i][j] = float(value)
        matrix[j][i] = 1.0 / float(value)

    return matrix


def _normalise(vector: list[float]) -> list[float]:
    total = sum(vector)
    if total == 0:
        raise ValueError("Cannot normalise a zero vector")
    return [value / total for value in vector]


def principal_eigenvector(
    matrix: list[list[float]], *, max_iterations: int = 1000, tolerance: float = 1e-12
) -> list[float]:
    """Power iteration. Repeatedly multiplying any positive starting vector
    by A drives it toward the dominant eigenvector, because the contribution
    of every other eigenvector shrinks by the ratio of its eigenvalue to the
    dominant one on each pass. Normalising each step keeps it from
    overflowing and makes the convergence test scale-free."""
    n = len(matrix)
    vector = [1.0 / n] * n

    for _ in range(max_iterations):
        product = [sum(matrix[i][j] * vector[j] for j in range(n)) for i in range(n)]
        nxt = _normalise(product)
        if max(abs(a - b) for a, b in zip(nxt, vector)) < tolerance:
            return nxt
        vector = nxt

    return vector


def geometric_mean_weights(matrix: list[list[float]]) -> list[float]:
    """Saaty's row-geometric-mean approximation.

    Not used to produce the live weights — it exists as an independent
    cross-check. Two different derivations landing on the same weights is
    much stronger evidence that the implementation is right than either one
    agreeing with itself.
    """
    n = len(matrix)
    means = []
    for row in matrix:
        product = 1.0
        for value in row:
            product *= value
        means.append(product ** (1.0 / n))
    return _normalise(means)


def derive_weights(
    criteria: list[str], judgements: dict[tuple[str, str], float]
) -> AHPResult:
    """Full AHP pass: judgements in, weights plus a consistency verdict out."""
    if len(criteria) < 2:
        raise ValueError("AHP needs at least two criteria to compare")
    if len(set(criteria)) != len(criteria):
        raise ValueError("Criteria must be unique")

    matrix = build_matrix(criteria, judgements)
    n = len(criteria)
    weights = principal_eigenvector(matrix)

    # lambda_max from the Rayleigh-style average: for each row, how much the
    # matrix scaled the weight vector. All n values would be exactly n if the
    # judgements were perfectly consistent.
    weighted_sums = [sum(matrix[i][j] * weights[j] for j in range(n)) for i in range(n)]
    lambda_max = sum(ws / w for ws, w in zip(weighted_sums, weights)) / n

    consistency_index = (lambda_max - n) / (n - 1)
    random_index = RANDOM_CONSISTENCY_INDEX.get(n, 1.49)
    # n <= 2 cannot be inconsistent: there is only one judgement to make.
    consistency_ratio = 0.0 if random_index == 0 else consistency_index / random_index

    return AHPResult(
        criteria=list(criteria),
        weights={name: weight for name, weight in zip(criteria, weights)},
        lambda_max=lambda_max,
        consistency_index=consistency_index,
        consistency_ratio=consistency_ratio,
    )
