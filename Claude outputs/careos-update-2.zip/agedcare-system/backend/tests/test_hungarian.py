"""Correctness of the Hungarian algorithm.

The central test is `test_matches_brute_force_on_random_matrices`: for small
inputs, exhaustive search over every permutation gives the provably optimal
total, and the implementation must match it every time. That is a far
stronger statement than checking a handful of worked examples, because it
covers cases nobody thought to write down.
"""

import itertools
import math
import random

import pytest

from backend.algorithms.hungarian import (
    greedy_assignment,
    solve_assignment,
)


def brute_force_optimum(cost: list[list[float]]) -> float | None:
    """Exhaustive search — O(m! / (m-n)!). Only usable for tiny matrices,
    which is exactly why it is trustworthy as a reference."""
    n_rows, n_cols = len(cost), len(cost[0])
    best = None
    for permutation in itertools.permutations(range(n_cols), n_rows):
        if any(math.isinf(cost[i][permutation[i]]) for i in range(n_rows)):
            continue
        total = sum(cost[i][permutation[i]] for i in range(n_rows))
        if best is None or total < best:
            best = total
    return best


# --- known results -------------------------------------------------------


def test_classic_three_by_three():
    cost = [[4, 1, 3], [2, 0, 5], [3, 2, 2]]
    result = solve_assignment(cost)
    assert result.total_cost == 5
    assert result.rows_to_cols == [1, 0, 2]


def test_identity_matrix_picks_the_diagonal():
    cost = [[0 if i == j else 1 for j in range(5)] for i in range(5)]
    assert solve_assignment(cost).total_cost == 0


def test_single_cell():
    assert solve_assignment([[7]]).total_cost == 7


def test_empty_matrix():
    assert solve_assignment([]).rows_to_cols == []
    assert solve_assignment([[]]).total_cost == 0


def test_ragged_matrix_is_rejected():
    with pytest.raises(ValueError):
        solve_assignment([[1, 2], [3]])


def test_negative_costs_are_handled():
    """Nothing in the method requires non-negative costs; the potentials
    absorb any constant offset."""
    cost = [[-5, -1], [-2, -8]]
    assert solve_assignment(cost).total_cost == -13


# --- the property that justifies the whole exercise ----------------------


def test_greedy_is_suboptimal_on_the_documented_example():
    """The example from the module docstring. If this ever stops holding,
    the argument for implementing Hungarian at all has gone."""
    cost = [[1, 2], [1, 9]]
    optimal = solve_assignment(cost)
    greedy = greedy_assignment(cost)

    assert optimal.total_cost == 3
    assert greedy.total_cost == 10
    assert optimal.total_cost < greedy.total_cost


def test_optimal_is_never_worse_than_greedy():
    random.seed(20260920)
    for _ in range(200):
        size = random.randint(2, 6)
        cost = [[float(random.randint(0, 50)) for _ in range(size)] for _ in range(size)]
        optimal = solve_assignment(cost)
        greedy = greedy_assignment(cost)
        assert optimal.total_cost <= greedy.total_cost + 1e-9


def test_matches_brute_force_on_random_matrices():
    """400 random cases against exhaustive search, including forbidden
    pairs and non-square shapes."""
    random.seed(1234)
    checked = 0
    for _ in range(400):
        n_rows = random.randint(1, 5)
        n_cols = random.randint(n_rows, 6)
        cost = [
            [
                math.inf if random.random() < 0.12 else float(random.randint(0, 40))
                for _ in range(n_cols)
            ]
            for _ in range(n_rows)
        ]
        expected = brute_force_optimum(cost)
        if expected is None:
            continue  # no complete assignment exists; covered separately
        result = solve_assignment(cost)
        if result.assigned_count == n_rows:
            checked += 1
            assert result.total_cost == pytest.approx(expected)
    assert checked > 250, f"Only {checked} cases actually exercised the comparison"


def test_matches_brute_force_when_there_are_more_rows_than_columns():
    """Tall matrices — more shifts than staff. Some rows must go unassigned,
    and the solver must still choose the best subset."""
    random.seed(99)
    for _ in range(200):
        n_cols = random.randint(1, 4)
        n_rows = random.randint(n_cols, 6)
        cost = [[float(random.randint(0, 30)) for _ in range(n_cols)] for _ in range(n_rows)]

        best = None
        for rows in itertools.permutations(range(n_rows), n_cols):
            total = sum(cost[rows[j]][j] for j in range(n_cols))
            if best is None or total < best:
                best = total

        result = solve_assignment(cost)
        assert result.total_cost == pytest.approx(best)
        assert result.assigned_count == n_cols


# --- forbidden pairs -----------------------------------------------------


def test_forbidden_pairs_are_never_chosen():
    """A conflicting employee must not be assigned however cheap everything
    else is — infinity is a constraint, not a large preference."""
    cost = [[math.inf, 100.0], [1.0, 1.0]]
    result = solve_assignment(cost)
    assert result.rows_to_cols[0] == 1
    assert result.total_cost == 101.0


def test_a_row_with_no_legal_option_is_reported_unassigned():
    cost = [[math.inf, math.inf], [1.0, 2.0]]
    result = solve_assignment(cost)
    assert result.rows_to_cols[0] is None
    assert result.assigned_count == 1
    # The impossible row contributes nothing rather than a sentinel value.
    assert result.total_cost == 1.0


def test_all_forbidden_assigns_nobody():
    cost = [[math.inf, math.inf], [math.inf, math.inf]]
    result = solve_assignment(cost)
    assert result.assigned_count == 0
    assert result.total_cost == 0.0


# --- scale ---------------------------------------------------------------


def test_solves_a_realistic_roster_size_quickly():
    """60 shifts against 60 staff — far beyond anything this facility would
    schedule at once. Guards against an accidental exponential rewrite."""
    import time

    random.seed(5)
    size = 60
    cost = [[float(random.randint(0, 500)) for _ in range(size)] for _ in range(size)]

    started = time.perf_counter()
    result = solve_assignment(cost)
    elapsed = time.perf_counter() - started

    assert result.assigned_count == size
    assert elapsed < 2.0, f"Took {elapsed:.2f}s — expected well under a second"
