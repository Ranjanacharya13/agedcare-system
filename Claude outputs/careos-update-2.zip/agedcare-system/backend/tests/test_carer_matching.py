"""Suggesting who should care for whom.

Two shapes of the same question. `rank_candidates_for_resident` answers
"who could take this one resident", and is allowed to be greedy — there is
only one row. `suggest_assignments` answers "who takes each of these
residents", where greedy is wrong: the best carer for the first resident
considered is usually also the best for the second, and handing them to
whoever is asked about first is how one nurse ends up with every difficult
resident on the floor.

The tests that matter here are therefore about the *whole* allocation, not
about any single match looking sensible.
"""

from itertools import permutations
from uuid import uuid4

import pytest

from backend.models.employee import EmployeeRole
from backend.models.resident_assignment import AssignmentType, ResidentAssignment
from backend.services.carer_matching import CarerMatchingService
from backend.tests.test_assignments import (
    FakeAssignmentRepository,
    FakeRiskScoring,
    FakeSimpleRepository,
    _StubClient,
    make_employee,
    make_resident,
)


class _Score:
    """Minimal stand-in for RiskScoreOut — the matcher only reads two fields."""

    def __init__(self, resident_id, score, band="High"):
        self.resident_id = resident_id
        self.score = score
        self.band = band


class FakeFamiliarity:
    """Chart-entry counts per (resident, carer), as the real source reports
    them. Empty by default: nobody knows anybody, so continuity is a flat
    cost on every cell and the other terms decide."""

    def __init__(self, counts=None):
        self._counts = {(str(r), str(e)): n for (r, e), n in (counts or {}).items()}

    async def counts(self):
        return self._counts


def build_service(*, residents=(), employees=(), assignments=(), scores=None, familiar=None):
    service = CarerMatchingService(
        _StubClient(), risk_scoring_service=FakeRiskScoring(scores)
    )
    service._assignment_repository = FakeAssignmentRepository(list(assignments))
    service._resident_repository = FakeSimpleRepository(list(residents))
    service._employee_repository = FakeSimpleRepository(list(employees))
    service._familiarity = FakeFamiliarity(familiar)
    return service


def assign(resident, employee, kind=AssignmentType.PRIMARY, active=True):
    return ResidentAssignment(
        id=uuid4(),
        resident_id=resident.id,
        employee_id=employee.id,
        assignment_type=kind,
        active=active,
    )


def primary(resident, employee, active=True):
    return assign(resident, employee, AssignmentType.PRIMARY, active)


# --- ranking for a single resident ---------------------------------------


@pytest.mark.anyio
async def test_the_least_loaded_carer_is_suggested_first():
    needs_a_carer = make_resident("Gita")
    held = make_resident("Maya")
    busy = make_employee("Bikash")
    free = make_employee("Asha")

    service = build_service(
        residents=[needs_a_carer, held],
        employees=[busy, free],
        assignments=[primary(held, busy)],
        scores={str(held.id): _Score(held.id, 80)},
    )

    ranked = await service.rank_candidates_for_resident(str(needs_a_carer.id))

    assert [c.first_name for c in ranked] == ["Asha", "Bikash"]
    assert ranked[0].current_caseload == 0
    assert ranked[1].current_risk_load == 80


@pytest.mark.anyio
async def test_a_carer_who_knows_the_resident_beats_a_slightly_less_busy_stranger():
    """Continuity of care. Someone who has charted for this resident all
    month should win over a carer with a marginally lighter load who has
    never met them."""
    resident = make_resident("Tek")
    held = make_resident("Maya")
    familiar = make_employee("Deepa")
    stranger = make_employee("Nabin")

    service = build_service(
        residents=[resident, held],
        employees=[familiar, stranger],
        assignments=[primary(held, familiar)],
        scores={str(held.id): _Score(held.id, 40)},
        familiar={(resident.id, familiar.id): 8},
    )

    ranked = await service.rank_candidates_for_resident(str(resident.id))

    assert [c.first_name for c in ranked] == ["Deepa", "Nabin"]
    assert ranked[0].reason.startswith("knows this resident (8 chart entries")
    assert ranked[1].reason.startswith("has not cared for this resident recently")


@pytest.mark.anyio
async def test_continuity_is_what_makes_the_whole_set_allocation_matter():
    """The pattern greedy cannot see. Deepa is the only carer Tek knows and
    also the cheaper match for Gopal, who knows Kiran as well. One at a
    time, Gopal takes Deepa and Tek gets a stranger; together, Tek keeps
    Deepa and Gopal goes to Kiran."""
    tek, gopal = make_resident("Tek"), make_resident("Gopal")
    deepa = make_employee("Deepa", role=EmployeeRole.CARE_COORDINATOR)
    kiran = make_employee("Kiran", role=EmployeeRole.CARE_PLANNER)
    nabin = make_employee("Nabin", role=EmployeeRole.REGISTERED_NURSE)

    # Kiran is the busier of the two, which is what makes Deepa the cheaper
    # match for Gopal and sets the trap for a one-at-a-time allocation.
    krishna, laxmi = make_resident("Krishna"), make_resident("Laxmi")

    service = build_service(
        residents=[tek, gopal, krishna, laxmi],
        employees=[deepa, kiran, nabin],
        assignments=[primary(krishna, kiran), primary(laxmi, kiran)],
        scores={
            str(tek.id): _Score(tek.id, 77),
            str(gopal.id): _Score(gopal.id, 52),
            str(krishna.id): _Score(krishna.id, 70),
            str(laxmi.id): _Score(laxmi.id, 29),
        },
        familiar={(tek.id, deepa.id): 10, (gopal.id, deepa.id): 7, (gopal.id, kiran.id): 6},
    )

    plan = await service.suggest_assignments()
    chosen = {s.first_name: s.employee_id for s in plan.suggestions}

    assert chosen["Tek"] == deepa.id
    assert chosen["Gopal"] == kiran.id
    assert plan.improvement_over_greedy > 0


@pytest.mark.anyio
async def test_a_carer_already_on_the_team_is_not_suggested_again():
    resident = make_resident()
    already_there = make_employee("Asha")
    someone_else = make_employee("Deepa")

    service = build_service(
        residents=[resident],
        employees=[already_there, someone_else],
        assignments=[primary(resident, already_there)],
        scores={str(resident.id): _Score(resident.id, 50)},
    )

    ranked = await service.rank_candidates_for_resident(str(resident.id))

    assert [c.first_name for c in ranked] == ["Deepa"]


@pytest.mark.anyio
async def test_a_kitchen_hand_ranks_below_a_nurse_who_is_already_carrying_residents():
    """The role penalty has to outweigh a real caseload difference, or the
    emptiest diary in the building wins every time — and the emptiest diary
    belongs to whoever does not hold a caseload for a living."""
    resident = make_resident("Gita")
    held = make_resident("Maya")
    nurse = make_employee("Asha", role=EmployeeRole.REGISTERED_NURSE)
    kitchen = make_employee("Ramesh", role=EmployeeRole.KITCHEN_STAFF)

    service = build_service(
        residents=[resident, held],
        employees=[nurse, kitchen],
        assignments=[primary(held, nurse)],
        scores={str(held.id): _Score(held.id, 95)},
    )

    ranked = await service.rank_candidates_for_resident(str(resident.id))

    assert [c.first_name for c in ranked] == ["Asha", "Ramesh"]
    assert "not a clinical role" in ranked[1].reason


@pytest.mark.anyio
async def test_every_suggestion_carries_a_reason_a_manager_can_disagree_with():
    resident = make_resident("Gita")
    held = make_resident("Maya")
    carer = make_employee("Asha")

    service = build_service(
        residents=[resident, held],
        employees=[carer],
        assignments=[primary(held, carer)],
        scores={str(held.id): _Score(held.id, 64)},
    )

    (candidate,) = await service.rank_candidates_for_resident(str(resident.id))

    # Not a score out of context — the actual load being balanced.
    assert "1 resident(s)" in candidate.reason
    assert "64" in candidate.reason


@pytest.mark.anyio
async def test_an_inactive_employee_is_never_suggested():
    resident = make_resident()
    gone = make_employee("Former")
    gone = gone.model_copy(update={"active": False})

    service = build_service(residents=[resident], employees=[gone])

    assert await service.rank_candidates_for_resident(str(resident.id)) == []


# --- allocating across every gap at once ---------------------------------


@pytest.mark.anyio
async def test_only_residents_without_a_primary_carer_are_proposed_for():
    covered = make_resident("Maya")
    uncovered = make_resident("Gita")
    carer = make_employee("Asha")
    spare = make_employee("Deepa")

    service = build_service(
        residents=[covered, uncovered],
        employees=[carer, spare],
        assignments=[primary(covered, carer)],
        scores={
            str(covered.id): _Score(covered.id, 40),
            str(uncovered.id): _Score(uncovered.id, 70),
        },
    )

    plan = await service.suggest_assignments()

    assert plan.residents_needing_a_carer == 1
    assert [s.first_name for s in plan.suggestions] == ["Gita"]


@pytest.mark.anyio
async def test_a_resident_whose_only_primary_assignment_ended_counts_as_a_gap():
    """Ending an assignment is how a key worker is replaced. If an inactive
    row still counted as coverage, the resident would silently drop off this
    list at exactly the moment they needed to be on it."""
    resident = make_resident("Maya")
    departed = make_employee("Bikash")
    spare = make_employee("Asha")

    service = build_service(
        residents=[resident],
        employees=[departed, spare],
        assignments=[primary(resident, departed, active=False)],
        scores={str(resident.id): _Score(resident.id, 55)},
    )

    plan = await service.suggest_assignments()

    assert plan.residents_needing_a_carer == 1


@pytest.mark.anyio
async def test_nobody_is_given_two_residents_while_someone_else_is_given_none():
    """The property that separates this from ranking each resident on its
    own: an allocation is one carer per resident, so a second resident cannot
    be handed to the carer who already looked best."""
    residents = [make_resident(name) for name in ("Maya", "Gita", "Hari")]
    employees = [make_employee(name) for name in ("Asha", "Bikash", "Deepa")]

    service = build_service(
        residents=residents,
        employees=employees,
        scores={str(r.id): _Score(r.id, 30 + i * 20) for i, r in enumerate(residents)},
    )

    plan = await service.suggest_assignments()

    chosen = [s.employee_id for s in plan.suggestions]
    assert len(chosen) == 3
    assert all(c is not None for c in chosen)
    assert len(set(chosen)) == 3


@pytest.mark.anyio
async def test_the_most_urgent_resident_is_listed_first():
    low = make_resident("Calm")
    high = make_resident("Critical")
    employees = [make_employee("Asha"), make_employee("Deepa")]

    service = build_service(
        residents=[low, high],
        employees=employees,
        scores={str(low.id): _Score(low.id, 12, "Low"), str(high.id): _Score(high.id, 88, "Critical")},
    )

    plan = await service.suggest_assignments()

    assert [s.first_name for s in plan.suggestions] == ["Critical", "Calm"]
    assert plan.suggestions[0].risk_band == "Critical"


@pytest.mark.anyio
async def test_more_residents_than_staff_gives_one_carer_several_residents():
    """Carers hold caseloads. With three residents and one carer the plain
    assignment problem would leave two residents with nobody; offering the
    carer as several slots lets the plan say what a manager would say."""
    residents = [make_resident(name) for name in ("Maya", "Gita", "Hari")]
    (only_carer,) = employees = [make_employee("Asha")]

    service = build_service(
        residents=residents,
        employees=employees,
        scores={str(r.id): _Score(r.id, 40) for r in residents},
    )

    plan = await service.suggest_assignments()

    assert plan.max_new_per_carer == 3
    assert plan.unmatched_optimal == 0
    assert all(s.employee_id == only_carer.id for s in plan.suggestions)


@pytest.mark.anyio
async def test_residents_are_spread_evenly_when_carers_are_equal():
    residents = [make_resident(f"R{i}") for i in range(4)]
    employees = [make_employee("Asha"), make_employee("Bina")]

    service = build_service(
        residents=residents,
        employees=employees,
        scores={str(r.id): _Score(r.id, 40) for r in residents},
    )

    plan = await service.suggest_assignments()
    per_carer = {}
    for s in plan.suggestions:
        per_carer[s.employee_id] = per_carer.get(s.employee_id, 0) + 1
    assert sorted(per_carer.values()) == [2, 2]


@pytest.mark.anyio
async def test_a_backup_carer_can_step_up_to_key_worker():
    """Someone already on the team as backup is the most natural key worker,
    not a conflict — only the resident's existing key worker is ruled out."""
    maya = make_resident("Maya")
    backup = make_employee("Bikash", role=EmployeeRole.REGISTERED_NURSE)
    stranger = make_employee("Chandra", role=EmployeeRole.REGISTERED_NURSE)

    service = build_service(
        residents=[maya],
        employees=[backup, stranger],
        assignments=[assign(maya, backup, AssignmentType.SECONDARY)],
        scores={str(maya.id): _Score(maya.id, 50)},
        familiar={(str(maya.id), str(backup.id)): 6},
    )

    plan = await service.suggest_assignments()
    assert plan.suggestions[0].employee_id == backup.id


@pytest.mark.anyio
async def test_backups_are_suggested_for_residents_without_one():
    maya = make_resident("Maya")
    key_worker = make_employee("Asha", role=EmployeeRole.REGISTERED_NURSE)
    other = make_employee("Bina", role=EmployeeRole.CARE_COORDINATOR)

    service = build_service(
        residents=[maya],
        employees=[key_worker, other],
        assignments=[primary(maya, key_worker)],
        scores={str(maya.id): _Score(maya.id, 30)},
    )

    plan = await service.suggest_assignments(kind=AssignmentType.SECONDARY)
    assert plan.kind == AssignmentType.SECONDARY
    (row,) = plan.suggestions
    assert row.assignment_type == AssignmentType.SECONDARY
    # Her key worker cannot also be her backup.
    assert row.employee_id == other.id


@pytest.mark.anyio
async def test_hand_over_reallocates_everything_the_leaver_holds():
    maya, gita, hari = (make_resident(n) for n in ("Maya", "Gita", "Hari"))
    leaver = make_employee("Asha", role=EmployeeRole.REGISTERED_NURSE)
    nurse = make_employee("Bikash", role=EmployeeRole.REGISTERED_NURSE)
    coordinator = make_employee("Chandra", role=EmployeeRole.CARE_COORDINATOR)
    held = [
        primary(maya, leaver),
        assign(gita, leaver, AssignmentType.SECONDARY),
        primary(gita, nurse),
        primary(hari, coordinator),  # not the leaver's: untouched
    ]

    service = build_service(
        residents=[maya, gita, hari],
        employees=[leaver, nurse, coordinator],
        assignments=held,
        scores={str(r.id): _Score(r.id, 40) for r in (maya, gita, hari)},
    )

    plan = await service.suggest_assignments(hand_over_from=str(leaver.id))

    assert plan.hand_over_from_employee_id == leaver.id
    rows = {s.first_name: s for s in plan.suggestions}
    assert set(rows) == {"Maya", "Gita"}
    assert rows["Maya"].assignment_type == AssignmentType.PRIMARY
    assert rows["Maya"].replaces_assignment_id == held[0].id
    assert rows["Gita"].assignment_type == AssignmentType.SECONDARY
    # Nobody is handed their own resident back, and Gita's backup cannot be
    # her key worker Bikash.
    assert all(s.employee_id != leaver.id for s in plan.suggestions)
    assert rows["Gita"].employee_id == coordinator.id


@pytest.mark.anyio
async def test_no_gaps_means_no_work_and_no_division_by_zero():
    resident = make_resident()
    carer = make_employee()

    service = build_service(
        residents=[resident],
        employees=[carer],
        assignments=[primary(resident, carer)],
        scores={str(resident.id): _Score(resident.id, 40)},
    )

    plan = await service.suggest_assignments()

    assert plan.suggestions == []
    assert plan.optimal_total_cost == 0.0
    assert plan.improvement_over_greedy == 0.0


@pytest.mark.anyio
async def test_the_allocation_is_never_worse_than_taking_each_gap_in_turn():
    """The comparison the UI reports. Greedy can tie — with no contention it
    often does — but it must never win, or the claim on screen is false."""
    residents = [make_resident(name) for name in ("Maya", "Gita", "Hari")]
    nurse = make_employee("Asha", role=EmployeeRole.REGISTERED_NURSE)
    coordinator = make_employee("Chandra", role=EmployeeRole.CARE_COORDINATOR)
    kitchen = make_employee("Ramesh", role=EmployeeRole.KITCHEN_STAFF)
    held = make_resident("Sita")

    service = build_service(
        residents=residents + [held],
        employees=[nurse, coordinator, kitchen],
        assignments=[primary(held, nurse)],
        scores={
            str(held.id): _Score(held.id, 90),
            **{str(r.id): _Score(r.id, 30 + i * 25) for i, r in enumerate(residents)},
        },
    )

    plan = await service.suggest_assignments()

    assert plan.optimal_total_cost <= plan.greedy_total_cost
    assert plan.improvement_over_greedy >= 0


@pytest.mark.anyio
async def test_a_resident_with_one_eligible_carer_is_not_left_out_for_an_easier_match():
    """The failure that matters most, and the one greedy cannot avoid.

    Both residents need a backup carer. Bikash is already Maya's key worker,
    so he cannot also be her backup — Chandra is her only option. Chandra is
    also the cheaper match for Gita, who is stable. Taking the cheapest pair
    first gives Chandra to Gita and leaves Maya, the sicker of the two, with
    nobody.
    """
    maya = make_resident("Maya")
    gita = make_resident("Gita")
    chandra = make_employee("Chandra", role=EmployeeRole.CARE_COORDINATOR)
    bikash = make_employee("Bikash", role=EmployeeRole.REGISTERED_NURSE)
    gita_key = make_employee("Dawa", role=EmployeeRole.KITCHEN_STAFF)

    service = build_service(
        residents=[maya, gita],
        employees=[chandra, bikash],
        assignments=[primary(maya, bikash), primary(gita, gita_key)],
        scores={
            str(maya.id): _Score(maya.id, 90, "Critical"),
            str(gita.id): _Score(gita.id, 10, "Low"),
        },
    )

    plan = await service.suggest_assignments(kind=AssignmentType.SECONDARY)

    assert plan.unmatched_greedy == 1
    assert plan.unmatched_optimal == 0
    assert plan.improvement_over_greedy > 0
    by_resident = {s.first_name: s.employee_id for s in plan.suggestions}
    assert by_resident["Maya"] == chandra.id
    assert by_resident["Gita"] == bikash.id


@pytest.mark.anyio
async def test_a_high_acuity_resident_is_matched_to_the_clinical_role():
    """Load alone would send the critical resident to whoever is emptiest.
    The pairing term is what stops that: skill is weighed against how unwell
    the resident actually is, so the nurse takes the critical one even though
    she is already carrying more."""
    critical = make_resident("Critical")
    stable = make_resident("Stable")
    held = [make_resident(f"Held{i}") for i in range(3)]
    nurse = make_employee("Asha", role=EmployeeRole.REGISTERED_NURSE)
    coordinator = make_employee("Chandra", role=EmployeeRole.CARE_COORDINATOR)

    service = build_service(
        residents=[critical, stable, *held],
        employees=[nurse, coordinator],
        assignments=[primary(r, nurse) for r in held],
        scores={
            str(critical.id): _Score(critical.id, 95, "Critical"),
            str(stable.id): _Score(stable.id, 8, "Low"),
            **{str(r.id): _Score(r.id, 40) for r in held},
        },
    )

    plan = await service.suggest_assignments()
    by_resident = {s.first_name: s.employee_id for s in plan.suggestions}

    assert by_resident["Critical"] == nurse.id
    assert by_resident["Stable"] == coordinator.id
    critical_row = next(s for s in plan.suggestions if s.first_name == "Critical")
    assert "full clinical scope" in critical_row.reason


@pytest.mark.anyio
async def test_the_allocation_matches_an_exhaustive_search():
    """The claim is *optimal*, not *good*. Small enough here to check every
    possible allocation by hand and confirm nothing beats the one proposed."""
    residents = [make_resident(name) for name in ("Maya", "Gita", "Hari")]
    employees = [
        make_employee("Asha", role=EmployeeRole.REGISTERED_NURSE),
        make_employee("Bikash", role=EmployeeRole.CARE_COORDINATOR),
        make_employee("Ramesh", role=EmployeeRole.KITCHEN_STAFF),
        make_employee("Deepa", role=EmployeeRole.REGISTERED_NURSE),
    ]
    # Existing work, so the carers start from genuinely different loads.
    held = [make_resident("Sita"), make_resident("Kamala")]

    service = build_service(
        residents=residents + held,
        employees=employees,
        assignments=[primary(held[0], employees[0]), primary(held[1], employees[1])],
        scores={
            str(held[0].id): _Score(held[0].id, 70),
            str(held[1].id): _Score(held[1].id, 25),
            **{str(r.id): _Score(r.id, 20 + i * 30) for i, r in enumerate(residents)},
        },
    )

    plan = await service.suggest_assignments()
    _, state = await service._staff_state()

    # Rebuild the same cost matrix the service solved, then brute-force it.
    # The rows are taken from the plan, so they are in the order the service
    # used — the acuity of each row has to come from the same place.
    costs = [
        [
            service._cost(state[str(e.id)], str(row.resident_id), row.risk_score / 100, 0)[0]
            for e in employees
        ]
        for row in plan.suggestions
    ]
    rows = plan.suggestions
    best = min(
        sum(costs[row][col] for row, col in enumerate(choice))
        for choice in permutations(range(len(employees)), len(rows))
    )

    assert sum(s.cost for s in plan.suggestions) == pytest.approx(best, abs=1e-6)
