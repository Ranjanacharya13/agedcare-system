"""Roster optimisation end to end.

The cost matrix is built from stubbed staff profiles so the arithmetic is
fully determined, which lets these tests assert *which* allocation comes
out, not merely that one does.
"""

from datetime import datetime, timedelta, timezone
from uuid import uuid4

import pytest

from backend.models.employee import Employee, EmployeeRole
from backend.models.employee_shift import EmployeeShift
from backend.services import roster_optimisation as ro
from backend.services.roster_optimisation import RosterOptimisationService

MONDAY = datetime(2026, 3, 2, 7, 0, tzinfo=timezone.utc)


class _StubClient:
    def table(self, _name):
        return object()


def make_employee(first: str, role: EmployeeRole | None = None) -> Employee:
    return Employee(id=uuid4(), first_name=first, last_name="Staff", role=role, active=True)


def make_shift(hour_offset: int, hours: int = 8, role: str | None = None) -> EmployeeShift:
    start = MONDAY + timedelta(hours=hour_offset)
    return EmployeeShift(
        id=uuid4(), shift_start=start, shift_end=start + timedelta(hours=hours), role=role
    )


def build_service(shifts, profiles) -> RosterOptimisationService:
    """Wire a service whose data gathering is replaced by fixed values, so
    only the cost model and the algorithm are under test."""
    service = RosterOptimisationService(_StubClient(), risk_scoring_service=None)

    async def _load_shifts(*_args, **_kwargs):
        return shifts

    async def _employee_profile(employee, _week_key):
        return profiles[str(employee.id)]

    async def _list_all(_skip=0, _limit=100):
        return [p["employee"] for p in profiles.values()]

    service._load_shifts = _load_shifts
    service._employee_profile = _employee_profile
    service._employee_repository.list_all = _list_all
    return service


def profile(employee, *, care_load=0.0, week_hours=0.0, shifts=None):
    return {
        "employee": employee,
        "shifts": shifts or [],
        "care_load": care_load,
        "residents": 0,
        "week_hours": week_hours,
    }


# --- the cost model ------------------------------------------------------


def test_an_overlapping_shift_costs_infinity():
    """A clash is a constraint, not a preference — no fairness saving can
    justify double-booking someone."""
    service = RosterOptimisationService(_StubClient(), risk_scoring_service=None)
    target = make_shift(0)
    clashing = make_shift(4)  # starts inside the target's window
    cost, parts = service._cost(profile(make_employee("A"), shifts=[clashing]), target)
    assert cost == float("inf")
    assert parts["total"] == float("inf")


def test_a_shift_that_merely_touches_is_not_a_clash():
    """Finishing at 15:00 and starting at 15:00 is back-to-back, not
    overlapping. Strict inequalities in the overlap test are what make this
    work."""
    service = RosterOptimisationService(_StubClient(), risk_scoring_service=None)
    target = make_shift(8)
    adjacent = make_shift(0)  # 07:00-15:00, target is 15:00-23:00
    cost, _ = service._cost(profile(make_employee("A"), shifts=[adjacent]), target)
    assert cost != float("inf")


def test_the_shift_being_filled_is_not_its_own_conflict():
    service = RosterOptimisationService(_StubClient(), risk_scoring_service=None)
    target = make_shift(0)
    cost, _ = service._cost(profile(make_employee("A"), shifts=[target]), target)
    assert cost != float("inf")


def test_higher_care_load_costs_more():
    service = RosterOptimisationService(_StubClient(), risk_scoring_service=None)
    shift = make_shift(0)
    light, _ = service._cost(profile(make_employee("A"), care_load=0), shift)
    heavy, _ = service._cost(profile(make_employee("B"), care_load=400), shift)
    assert heavy > light


def test_care_load_outweighs_hours():
    """Spreading risk matters more than spreading time — a carer with four
    high-risk residents is under more pressure than one on more hours with
    easy ones."""
    assert ro.CARE_LOAD_WEIGHT > ro.HOURS_WEIGHT


def test_role_mismatch_is_penalised_but_not_forbidden():
    """A mismatched body still beats an unfilled shift."""
    service = RosterOptimisationService(_StubClient(), risk_scoring_service=None)
    shift = make_shift(0, role=EmployeeRole.REGISTERED_NURSE.value)
    nurse, _ = service._cost(profile(make_employee("A", EmployeeRole.REGISTERED_NURSE)), shift)
    kitchen, _ = service._cost(profile(make_employee("B", EmployeeRole.KITCHEN_STAFF)), shift)
    assert kitchen > nurse
    assert kitchen != float("inf")


# --- the algorithm on realistic input ------------------------------------


@pytest.mark.anyio
async def test_optimal_allocation_strictly_beats_greedy_when_availability_is_scarce():
    """The case that justifies the algorithm.

    Three nurse shifts on three days. Alice is the cheapest candidate and is
    free all week. Bob and Cara are more loaded and each already work on
    some of those days:

              Mon      Tue      Wed
      Alice   free     free     free      (cheapest)
      Bob     free     free     CLASH
      Cara    free     CLASH    CLASH

    Wednesday can only be covered by Alice. Greedy does not know that: it
    takes the cheapest cell anywhere, which is Alice on Monday, and by the
    time it reaches Wednesday nobody is left. The optimal allocation spends
    slightly more on Monday to keep Alice for Wednesday, and fills all
    three.
    """
    monday, tuesday, wednesday = make_shift(0), make_shift(24), make_shift(48)
    role = EmployeeRole.REGISTERED_NURSE

    alice = make_employee("Alice", role)
    bob = make_employee("Bob", role)
    cara = make_employee("Cara", role)

    profiles = {
        str(alice.id): profile(alice, care_load=20, week_hours=8),
        str(bob.id): profile(bob, care_load=310, week_hours=32, shifts=[make_shift(48)]),
        str(cara.id): profile(
            cara, care_load=95, week_hours=24, shifts=[make_shift(24), make_shift(48)]
        ),
    }

    service = build_service([monday, tuesday, wednesday], profiles)
    result = await service.optimise()

    # The headline claim: optimal covers every shift, greedy strands one.
    assert result.comparison.optimal_assigned == 3
    assert result.comparison.greedy_assigned == 2
    assert result.comparison.differing_shifts > 0

    # Alice must be held back for the only shift she alone can cover.
    wednesday_assignment = next(a for a in result.assignments if a.shift_id == wednesday.id)
    assert wednesday_assignment.employee_name == "Alice Staff"

    # Greedy spends her on Monday instead, and leaves Wednesday empty.
    greedy_wednesday = next(
        a for a in result.greedy_assignments if a.shift_id == wednesday.id
    )
    assert greedy_wednesday.employee_id is None

    # Greedy's raw assignment sum is actually *lower* — it simply filled
    # fewer shifts. Only once an unfilled shift carries a penalty does the
    # comparison become meaningful, and then optimal clearly wins.
    assert result.comparison.greedy_assignment_cost < result.comparison.optimal_assignment_cost
    assert result.comparison.unfilled_greedy == 1
    assert result.comparison.unfilled_optimal == 0
    assert result.comparison.greedy_total_cost > result.comparison.optimal_total_cost
    assert result.comparison.absolute_saving > 0
    assert result.comparison.percentage_saving > 0


@pytest.mark.anyio
async def test_nobody_is_double_booked():
    """The property that must hold whatever the costs say."""
    shifts = [make_shift(0), make_shift(4), make_shift(8)]
    staff = [make_employee(name) for name in ("A", "B", "C")]
    profiles = {str(e.id): profile(e, care_load=i * 50) for i, e in enumerate(staff)}

    result = await build_service(shifts, profiles).optimise()
    assigned = [a.employee_id for a in result.assignments if a.employee_id]
    assert len(assigned) == len(set(assigned))


@pytest.mark.anyio
async def test_more_shifts_than_staff_leaves_some_unassigned_with_a_reason():
    shifts = [make_shift(0), make_shift(24), make_shift(48)]
    only = make_employee("Solo")
    profiles = {str(only.id): profile(only)}

    result = await build_service(shifts, profiles).optimise()
    unassigned = [a for a in result.assignments if a.employee_id is None]
    assert len(unassigned) == 2
    assert all(a.unassigned_reason for a in unassigned)


@pytest.mark.anyio
async def test_everyone_conflicting_leaves_the_shift_unfilled():
    target = make_shift(0)
    clash = make_shift(2)
    busy = make_employee("Busy")
    profiles = {str(busy.id): profile(busy, shifts=[clash])}

    result = await build_service([target], profiles).optimise()
    assert result.assignments[0].employee_id is None
    assert "clashing" in result.assignments[0].unassigned_reason


@pytest.mark.anyio
async def test_result_reports_the_matrix_dimensions_and_timing():
    """These feed the report: the matrix size shows the problem scale, and
    the solve time shows the algorithm is not the bottleneck."""
    shifts = [make_shift(0), make_shift(24)]
    staff = [make_employee(n) for n in ("A", "B", "C", "D")]
    profiles = {str(e.id): profile(e) for e in staff}

    result = await build_service(shifts, profiles).optimise()
    assert (result.matrix_rows, result.matrix_cols) == (2, 4)
    assert result.shifts_considered == 2
    assert result.candidates_considered == 4
    assert result.solve_ms >= 0


@pytest.mark.anyio
async def test_no_shifts_returns_an_empty_result_rather_than_failing():
    result = await build_service([], {}).optimise()
    assert result.shifts_considered == 0
    assert result.assignments == []


@pytest.mark.anyio
async def test_greedy_and_optimal_are_both_reported():
    """The comparison is the deliverable — both allocations must come back
    so the difference can be shown side by side."""
    shifts = [make_shift(0), make_shift(24)]
    staff = [make_employee(n) for n in ("A", "B")]
    profiles = {
        str(staff[0].id): profile(staff[0], care_load=10),
        str(staff[1].id): profile(staff[1], care_load=300),
    }
    result = await build_service(shifts, profiles).optimise()

    assert len(result.assignments) == len(result.greedy_assignments) == 2
    assert result.comparison.absolute_saving >= 0
    assert result.cost_model["care_load_weight"] == ro.CARE_LOAD_WEIGHT
