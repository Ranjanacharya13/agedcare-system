"""The demo data does what its docstring says it does.

`backend/demo/dataset.py` is not random filler — each record is placed so
that the system's algorithms have something specific to show. These tests
run the *real* services over it (through an in-memory Supabase stand-in)
and fail if a change to either the data or the algorithms quietly breaks
the demonstration. The same data is what `seed_dummy_data` writes to
Supabase, so what passes here is what appears on screen.
"""

from datetime import datetime

import pytest

from backend.demo.dataset import (
    NPT,
    RESIDENTS,
    STAFF,
    TABLE_ORDER,
    TARGET_SCORES,
    UNALLOCATED,
    build,
)
from backend.demo.allocate import ALGORITHM_NOTE, allocate_care_teams
from backend.models.resident_assignment import AssignmentType
from backend.services.assignment_service import AssignmentService
from backend.services.carer_matching import CarerMatchingService
from backend.services.risk_scoring import RiskScoringService
from backend.services.roster_optimisation import RosterOptimisationService
from backend.tests.fake_supabase import FakeSupabase

# Built for today, not a fixed date: the scorers compare against the real
# clock, so data frozen at one date would drift out of the 30- and 90-day
# windows and these tests would start failing a month from now.
TODAY = datetime.now(NPT).date()


@pytest.fixture(scope="module")
def data():
    return build(TODAY)


@pytest.fixture
def client(data):
    return FakeSupabase.from_demo(data)


# --- shape ---------------------------------------------------------------


def test_every_table_is_written_in_foreign_key_order(data):
    assert set(data.tables) <= set(TABLE_ORDER)
    for table in TABLE_ORDER:
        assert data.rows(table), f"{table} has no demo rows — a screen would sit empty"


def test_ids_are_stable_so_seeding_twice_updates_instead_of_duplicating():
    first, second = build(TODAY), build(TODAY)
    for table in TABLE_ORDER:
        assert [r.id for r in first.rows(table)] == [r.id for r in second.rows(table)]


def test_ids_are_unique_within_each_table(data):
    for table in TABLE_ORDER:
        ids = [row.id for row in data.rows(table)]
        assert len(ids) == len(set(ids)), f"duplicate id in {table}"


def test_every_person_has_the_records_their_pages_show(data):
    """No resident or staff page should open onto an empty tab."""
    for table in ("resident_medications", "resident_medical_history", "resident_sleep_chart",
                  "resident_bowel_chart", "resident_fall_risk", "resident_assistance"):
        covered = {row.resident_id for row in data.rows(table)}
        assert covered == set(data.resident_ids.values()), f"a resident has no {table}"
    for table in ("employee_contracts", "employee_availability", "employee_shifts",
                  "employee_payroll_records", "employee_qualifications"):
        covered = {row.employee_id for row in data.rows(table)} - {None}  # open shifts
        assert covered == set(data.employee_ids.values()), f"an employee has no {table}"


def test_every_email_is_undeliverable_by_construction(data):
    emails = [row.email for row in data.rows("employees")] + [a.email for a in data.accounts]
    assert all(e.endswith("example.np") for e in emails)


def test_nobody_is_named_twice(data):
    full = [f"{r[1]} {r[2]}" for r in RESIDENTS] + [f"{s[1]} {s[2]}" for s in STAFF]
    assert len(full) == len(set(full))


# --- AHP risk scoring ----------------------------------------------------


@pytest.mark.anyio
async def test_every_resident_scores_exactly_as_designed(data, client):
    scorer = RiskScoringService(client)
    for key, resident_id in data.resident_ids.items():
        result = await scorer.get_resident_score(str(resident_id))
        assert result.score == TARGET_SCORES[key], (
            f"{key} scored {result.score}, designed for {TARGET_SCORES[key]}"
        )


@pytest.mark.anyio
async def test_the_residents_span_all_four_risk_bands(data, client):
    scorer = RiskScoringService(client)
    bands = {}
    for resident_id in data.resident_ids.values():
        result = await scorer.get_resident_score(str(resident_id))
        bands[result.band] = bands.get(result.band, 0) + 1
    assert set(bands) == {"Critical", "High", "Medium", "Low"}
    assert all(count >= 3 for count in bands.values())


@pytest.mark.anyio
async def test_an_incident_outside_the_window_does_not_count(data, client):
    """Dil Bahadur's only incident was 140 days ago: it is on his record and
    contributes nothing, which is the lookback window doing its job."""
    scorer = RiskScoringService(client)
    result = await scorer.get_resident_score(str(data.resident_ids["dil"]))
    assert result.breakdown["recent_incidents"].points == 0
    assert any(row.resident_id == data.resident_ids["dil"] for row in data.rows("resident_incidents"))


# --- Hungarian: primary carers --------------------------------------------


@pytest.mark.anyio
async def test_the_unallocated_residents_are_exactly_the_designed_gaps(data, client):
    matcher = CarerMatchingService(client, RiskScoringService(client))
    plan = await matcher.suggest_assignments()
    reverse = {v: k for k, v in data.resident_ids.items()}
    assert {reverse[s.resident_id] for s in plan.suggestions} == set(UNALLOCATED)


@pytest.mark.anyio
async def test_tek_bahadur_gets_the_carer_he_settles_with(data, client):
    """The story the data tells: Deepa is the only carer Tek knows, and she
    is also the cheaper match for Gopal. Allocated together, Tek keeps her
    and Gopal goes to Kiran, who also knows him."""
    matcher = CarerMatchingService(client, RiskScoringService(client))
    plan = await matcher.suggest_assignments()
    by_resident = {s.resident_id: s.employee_id for s in plan.suggestions}
    E, R = data.employee_ids, data.resident_ids
    assert by_resident[R["tek"]] == E["deepa"]
    assert by_resident[R["gopal"]] == E["kiran"]
    assert by_resident[R["bishnu"]] == E["pooja"]
    assert by_resident[R["hari"]] == E["bikash"]


@pytest.mark.anyio
async def test_taking_each_resident_in_turn_would_have_done_worse(data, client):
    matcher = CarerMatchingService(client, RiskScoringService(client))
    plan = await matcher.suggest_assignments()
    assert plan.improvement_over_greedy > 0.2
    assert plan.unmatched_optimal == 0


@pytest.mark.anyio
async def test_every_suggested_carer_already_knows_their_resident(data, client):
    matcher = CarerMatchingService(client, RiskScoringService(client))
    plan = await matcher.suggest_assignments()
    assert all(s.reason.startswith("knows this resident") for s in plan.suggestions)


# --- Hungarian: open shifts ------------------------------------------------


def _open_shift_ids(data):
    return [str(s.id) for s in data.rows("employee_shifts") if s.employee_id is None]


@pytest.mark.anyio
async def test_next_week_has_open_shifts_to_fill(data):
    open_shifts = [s for s in data.rows("employee_shifts") if s.employee_id is None]
    assert len(open_shifts) >= 4
    assert all(s.shift_start.date() > TODAY for s in open_shifts)


@pytest.mark.anyio
async def test_only_pooja_can_take_thursday_night_and_she_gets_it(data, client):
    optimiser = RosterOptimisationService(client, RiskScoringService(client))
    result = await optimiser.optimise(shift_ids=_open_shift_ids(data))
    # Shift times keep their Nepal offset, so the weekday is Nepal's.
    thursday = next(a for a in result.assignments
                    if a.shift_role == "Registered Nurse" and a.shift_start.isoweekday() == 4)
    assert thursday.employee_id == data.employee_ids["pooja"]


@pytest.mark.anyio
async def test_filling_shifts_in_date_order_puts_a_non_nurse_on_a_nurse_shift(data, client):
    optimiser = RosterOptimisationService(client, RiskScoringService(client))
    result = await optimiser.optimise(shift_ids=_open_shift_ids(data))
    assert result.comparison.greedy_total_cost > result.comparison.optimal_total_cost
    assert result.comparison.percentage_saving > 50
    greedy_mismatches = [
        g for g in result.greedy_assignments
        if g.shift_role == "Registered Nurse" and g.employee_id
        and g.employee_id not in {data.employee_ids[k] for k in ("anjali", "bikash", "pooja", "nabin")}
    ]
    assert greedy_mismatches, "greedy should have been forced onto a non-nurse"


# --- the seed's allocation step --------------------------------------------


@pytest.mark.anyio
async def test_after_seeding_every_resident_has_a_key_worker_and_a_backup(data, client):
    steps = await allocate_care_teams(client)
    assert all(not step.result.failed for step in steps)

    report = await AssignmentService(client, RiskScoringService(client)).get_coverage_report()
    assert report.residents_without_primary == 0
    assert report.residents_with_backup == report.total_residents
    assert not report.without_backup


@pytest.mark.anyio
async def test_the_seeded_key_workers_are_the_algorithms_choices(data, client):
    await allocate_care_teams(client)
    E, R = data.employee_ids, data.resident_ids
    primaries = {
        row["resident_id"]: row["employee_id"]
        for row in client.tables["resident_assignments"]
        if row["active"] and row["assignment_type"] == AssignmentType.PRIMARY.value
    }
    assert primaries[str(R["tek"])] == str(E["deepa"])
    assert primaries[str(R["gopal"])] == str(E["kiran"])
    chosen = [
        row for row in client.tables["resident_assignments"]
        if row.get("notes") == ALGORITHM_NOTE
    ]
    assert len(chosen) >= len(UNALLOCATED)


@pytest.mark.anyio
async def test_no_manager_kitchen_or_laundry_hand_is_given_a_resident(data, client):
    await allocate_care_teams(client)
    report = await AssignmentService(client, RiskScoringService(client)).get_coverage_report()
    roles = {str(t.role) for t in report.teams}
    assert not roles & {"Manager", "Kitchen Staff", "Laundry Staff", "Administrator"}


@pytest.mark.anyio
async def test_seeding_twice_adds_nothing_the_second_time(data, client):
    await allocate_care_teams(client)
    again = await allocate_care_teams(client)
    assert all(not step.plan.suggestions for step in again)


@pytest.mark.anyio
async def test_the_roster_story_still_holds_after_care_teams_are_filled(data, client):
    """Filling care teams changes each carer's load, which the roster
    optimiser reads — the Thursday-night story must survive it."""
    await allocate_care_teams(client)
    optimiser = RosterOptimisationService(client, RiskScoringService(client))
    result = await optimiser.optimise(shift_ids=_open_shift_ids(data))
    thursday = next(a for a in result.assignments
                    if a.shift_role == "Registered Nurse" and a.shift_start.isoweekday() == 4)
    assert thursday.employee_id == data.employee_ids["pooja"]
    assert result.comparison.greedy_total_cost > result.comparison.optimal_total_cost
