from supabase import AsyncClient

from backend.models.employee import Employee
from backend.repositories.audited import AuditedRepository

TABLE_NAME = "employees"


class EmployeeRepository(AuditedRepository):
    def __init__(self, client: AsyncClient):
        self._table = client.table(TABLE_NAME)
        self._audit_table = TABLE_NAME

    async def create(self, employee: Employee) -> Employee:
        doc = employee.model_dump(mode="json", exclude={"id"})
        response = await self._table.insert(doc).execute()
        created = Employee(**response.data[0])
        await self._audit_create(created)
        return created

    async def get_by_id(self, employee_id: str) -> Employee | None:
        response = await self._table.select("*").eq("id", employee_id).maybe_single().execute()
        return Employee(**response.data) if response and response.data else None

    async def list_all(self, skip: int = 0, limit: int = 100) -> list[Employee]:
        response = await self._table.select("*").range(skip, skip + limit - 1).execute()
        return [Employee(**row) for row in response.data]

    async def update(self, employee_id: str, updates: dict) -> Employee | None:
        # Prior state is read first so the audit entry records from -> to,
        # not merely that something changed.
        before = await self.get_by_id(employee_id)
        response = await self._table.update(updates).eq("id", employee_id).execute()
        if not response.data:
            return None
        updated = Employee(**response.data[0])
        await self._audit_update(employee_id, before, updated)
        return updated

    async def delete(self, employee_id: str) -> bool:
        before = await self.get_by_id(employee_id)
        response = await self._table.delete().eq("id", employee_id).execute()
        deleted = bool(response.data)
        if deleted:
            await self._audit_delete(employee_id, before)
        return deleted
