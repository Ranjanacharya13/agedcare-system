from supabase import AsyncClient

from backend.models.resident import Resident
from backend.repositories.audited import AuditedRepository

TABLE_NAME = "residents"


class ResidentRepository(AuditedRepository):
    def __init__(self, client: AsyncClient):
        self._table = client.table(TABLE_NAME)
        self._audit_table = TABLE_NAME

    async def create(self, resident: Resident) -> Resident:
        doc = resident.model_dump(mode="json", exclude={"id"})
        response = await self._table.insert(doc).execute()
        created = Resident(**response.data[0])
        await self._audit_create(created)
        return created

    async def get_by_id(self, resident_id: str) -> Resident | None:
        response = await self._table.select("*").eq("id", resident_id).maybe_single().execute()
        return Resident(**response.data) if response and response.data else None

    async def list_all(self, skip: int = 0, limit: int = 100) -> list[Resident]:
        response = (
            await self._table.select("*").range(skip, skip + limit - 1).execute()
        )
        return [Resident(**row) for row in response.data]

    async def update(self, resident_id: str, updates: dict) -> Resident | None:
        # Prior state is read first so the audit entry records from -> to,
        # not merely that something changed.
        before = await self.get_by_id(resident_id)
        response = await self._table.update(updates).eq("id", resident_id).execute()
        if not response.data:
            return None
        updated = Resident(**response.data[0])
        await self._audit_update(resident_id, before, updated)
        return updated

    async def delete(self, resident_id: str) -> bool:
        before = await self.get_by_id(resident_id)
        response = await self._table.delete().eq("id", resident_id).execute()
        deleted = bool(response.data)
        if deleted:
            await self._audit_delete(resident_id, before)
        return deleted
