from supabase import AsyncClient

from backend.models.appointment import Appointment
from backend.repositories.audited import AuditedRepository

TABLE_NAME = "appointments"


class AppointmentRepository(AuditedRepository):
    def __init__(self, client: AsyncClient):
        self._table = client.table(TABLE_NAME)
        self._audit_table = TABLE_NAME

    async def create(self, appointment: Appointment) -> Appointment:
        doc = appointment.model_dump(mode="json", exclude={"id"})
        response = await self._table.insert(doc).execute()
        created = Appointment(**response.data[0])
        await self._audit_create(created)
        return created

    async def get_by_id(self, appointment_id: str) -> Appointment | None:
        response = await self._table.select("*").eq("id", appointment_id).maybe_single().execute()
        return Appointment(**response.data) if response and response.data else None

    async def list_all(self, skip: int = 0, limit: int = 100) -> list[Appointment]:
        response = await self._table.select("*").range(skip, skip + limit - 1).execute()
        return [Appointment(**row) for row in response.data]

    async def update(self, appointment_id: str, updates: dict) -> Appointment | None:
        # Prior state is read first so the audit entry records from -> to,
        # not merely that something changed.
        before = await self.get_by_id(appointment_id)
        response = await self._table.update(updates).eq("id", appointment_id).execute()
        if not response.data:
            return None
        updated = Appointment(**response.data[0])
        await self._audit_update(appointment_id, before, updated)
        return updated

    async def delete(self, appointment_id: str) -> bool:
        before = await self.get_by_id(appointment_id)
        response = await self._table.delete().eq("id", appointment_id).execute()
        deleted = bool(response.data)
        if deleted:
            await self._audit_delete(appointment_id, before)
        return deleted
