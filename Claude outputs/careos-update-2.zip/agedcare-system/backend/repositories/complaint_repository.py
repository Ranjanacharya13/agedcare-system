from supabase import AsyncClient

from backend.models.complaint import ComplaintFeedback
from backend.repositories.audited import AuditedRepository

TABLE_NAME = "complaints_feedback"


class ComplaintRepository(AuditedRepository):
    def __init__(self, client: AsyncClient):
        self._table = client.table(TABLE_NAME)
        self._audit_table = TABLE_NAME

    async def create(self, complaint: ComplaintFeedback) -> ComplaintFeedback:
        doc = complaint.model_dump(mode="json", exclude={"id"})
        response = await self._table.insert(doc).execute()
        created = ComplaintFeedback(**response.data[0])
        await self._audit_create(created)
        return created

    async def get_by_id(self, complaint_id: str) -> ComplaintFeedback | None:
        response = await self._table.select("*").eq("id", complaint_id).maybe_single().execute()
        return ComplaintFeedback(**response.data) if response and response.data else None

    async def list_all(self, skip: int = 0, limit: int = 100) -> list[ComplaintFeedback]:
        response = await self._table.select("*").range(skip, skip + limit - 1).execute()
        return [ComplaintFeedback(**row) for row in response.data]

    async def update(self, complaint_id: str, updates: dict) -> ComplaintFeedback | None:
        # Prior state is read first so the audit entry records from -> to,
        # not merely that something changed.
        before = await self.get_by_id(complaint_id)
        response = await self._table.update(updates).eq("id", complaint_id).execute()
        if not response.data:
            return None
        updated = ComplaintFeedback(**response.data[0])
        await self._audit_update(complaint_id, before, updated)
        return updated

    async def delete(self, complaint_id: str) -> bool:
        before = await self.get_by_id(complaint_id)
        response = await self._table.delete().eq("id", complaint_id).execute()
        deleted = bool(response.data)
        if deleted:
            await self._audit_delete(complaint_id, before)
        return deleted
