"""A demonstration care home in Kathmandu: "Sahara Elder Care".

Every row here is invented. Names are common Nepali names, credentials are
styled on the real Nepali issuers (Nepal Nursing Council, CTEVT, Tribhuvan
University) but every number is fictional, and every email address sits
under `example.np` so nothing can ever be delivered.

The data is not random. It is *designed*, so that the two algorithms in the
system have something real to do:

1. **AHP risk scoring.** Each resident's five signals — latest fall-risk
   assessment, incidents in the last 90 days, assistance level, cognitive
   status, behaviour events in the last 30 days — are chosen to land them in
   a specific band, so the list spans Critical, High, Medium and Low with
   three or four residents in each. `TARGET_SCORES` records the intended
   score; `test_demo_dataset.py` fails if the real scorer disagrees. A few
   records sit deliberately *outside* the lookback windows (an incident 140
   days ago) to show that old events stop counting.

2. **Hungarian allocation of primary carers.** The dataset leaves four
   residents without a named key worker, and most without a backup; the seed
   then fills every one of those places with the system's own allocation
   (`backend/demo/allocate.py`), so after seeding every resident has both,
   chosen by the algorithm from this data. One of them, Tek Bahadur Basnet, has Lewy body dementia and
   settles only with Deepa Karki — she is the only carer who has charted for
   him this month. Deepa also knows Gopal Prasad Joshi, and she is the
   cheaper match for him. Taking each resident in turn hands Deepa to Gopal
   and leaves Tek with a stranger; allocating all four together gives Deepa
   to Tek and Gopal to Kiran Magar, who also knows him. That is the trade-off
   the algorithm exists to see.

3. **Hungarian roster optimisation.** Next week has open shifts. Only Pooja
   Adhikari is free for the Thursday night nurse shift — the others are
   already rostered or start early on Friday — and Pooja is also the
   cheapest nurse for Tuesday night. Filling shifts in turn gives her
   Tuesday and leaves Thursday to a care coordinator on a nurse's shift; the
   optimal roster puts her on Thursday and Nabin Rai on Tuesday.

Dates are relative to the day the dataset is built, so the lookback windows
always catch what they are meant to. Re-run the seed before a demonstration
if a few weeks have passed.

IDs are deterministic (uuid5 of a stable key), so re-seeding updates rows in
place instead of duplicating them, and `--reset` knows exactly what to
remove.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone
from uuid import UUID, uuid5

from pydantic import BaseModel

from backend.models.appointment import Appointment, AppointmentStatus
from backend.models.assistance import AssistanceLevel, ResidentAssistance
from backend.models.behaviour import ResidentBehaviour
from backend.models.bowel_chart import ResidentBowelChart
from backend.models.complaint import ComplaintFeedback, ComplaintStatus
from backend.models.employee import Employee, EmployeeRole, EmploymentStatus
from backend.models.employee_availability import EmployeeAvailability
from backend.models.employee_contract import EmployeeContract
from backend.models.employee_leave import EmployeeLeave, LeaveStatus
from backend.models.employee_payroll_record import EmployeePayrollRecord, PayrollStatus
from backend.models.employee_performance import EmployeePerformance
from backend.models.employee_qualification import EmployeeQualification
from backend.models.employee_registration import EmployeeRegistration
from backend.models.employee_shift import EmployeeShift, ShiftStatus
from backend.models.employee_supervision import EmployeeSupervision
from backend.models.employee_time_entry import EmployeeTimeEntry
from backend.models.fall_risk import ResidentFallRisk, RiskLevel
from backend.models.incident import IncidentSeverity, IncidentStatus, ResidentIncident
from backend.models.medical_history import ResidentMedicalHistory
from backend.models.medical_inventory import ResidentMedicalInventory
from backend.models.medication import ResidentMedication
from backend.models.resident import CognitiveStatus, EmergencyContact, Resident
from backend.models.resident_assignment import AssignmentType, ResidentAssignment
from backend.models.sleep_chart import ResidentSleepChart
from backend.models.user import AccessRole

#: Nepal Standard Time. A fixed offset rather than a zone name: Nepal has no
#: daylight saving, and `zoneinfo` needs the separate `tzdata` package on
#: Windows, which is where this project is developed.
NPT = timezone(timedelta(hours=5, minutes=45))

#: Stable namespace for every demo id. Changing it orphans previously seeded
#: rows, so it never changes.
_NAMESPACE = UUID("5a4a7a10-0c1e-4c0b-9d7e-3a1b5e2c9f01")

EMAIL_DOMAIN = "careos.example.np"

#: Shared password for the demo login accounts. Printed by the seed script.
#: Demo databases only — the seed refuses to run without an explicit flag.
DEMO_PASSWORD = "Namaste@CareOS2026"

FACILITY = "Sahara Elder Care, Budhanilkantha, Kathmandu"


def demo_id(kind: str, key: str) -> UUID:
    return uuid5(_NAMESPACE, f"{kind}:{key}")


# ---------------------------------------------------------------------------
# people
# ---------------------------------------------------------------------------

RN = EmployeeRole.REGISTERED_NURSE
PLANNER = EmployeeRole.CARE_PLANNER
COORD = EmployeeRole.CARE_COORDINATOR
KITCHEN = EmployeeRole.KITCHEN_STAFF
LAUNDRY = EmployeeRole.LAUNDRY_STAFF
ADMIN = EmployeeRole.ADMINISTRATOR
MANAGER = EmployeeRole.MANAGER

FT = EmploymentStatus.FULL_TIME
PT = EmploymentStatus.PART_TIME
CASUAL = EmploymentStatus.CASUAL
AGENCY = EmploymentStatus.AGENCY

# key, first, last, role, status, hire date, phone
STAFF = [
    ("sarita", "Sarita", "Koirala", MANAGER, FT, date(2019, 4, 14), "+977-9851023456"),
    ("rajesh", "Rajesh", "Shrestha", ADMIN, FT, date(2020, 1, 6), "+977-9841187654"),
    ("anjali", "Anjali", "Gurung", RN, FT, date(2020, 8, 17), "+977-9803345128"),
    ("bikash", "Bikash", "Thapa", RN, FT, date(2021, 3, 1), "+977-9818264530"),
    ("pooja", "Pooja", "Adhikari", RN, PT, date(2023, 6, 12), "+977-9860419273"),
    ("nabin", "Nabin", "Rai", RN, CASUAL, date(2024, 2, 19), "+977-9842056381"),
    ("sunita", "Sunita", "Tamang", PLANNER, FT, date(2021, 9, 5), "+977-9813378412"),
    ("kiran", "Kiran", "Magar", PLANNER, PT, date(2022, 11, 21), "+977-9861172035"),
    ("deepa", "Deepa", "Karki", COORD, FT, date(2021, 5, 30), "+977-9849903318"),
    ("suman", "Suman", "Bhattarai", COORD, FT, date(2022, 7, 11), "+977-9808812246"),
    ("asmita", "Asmita", "Lama", COORD, AGENCY, date(2025, 1, 13), "+977-9823367704"),
    ("harik", "Hari Bahadur", "Khadka", KITCHEN, FT, date(2019, 10, 2), "+977-9841650987"),
    ("nirmala", "Nirmala", "Pun", KITCHEN, PT, date(2023, 3, 27), "+977-9867724519"),
    ("mohan", "Mohan", "Chaudhary", LAUNDRY, FT, date(2020, 12, 8), "+977-9814436620"),
]

#: Login accounts. Several job titles map onto one access role, and not every
#: employee needs to sign in — kitchen and laundry staff have no account.
ACCOUNTS = [
    ("rajesh", AccessRole.ADMIN),
    ("sarita", AccessRole.MANAGER),
    ("anjali", AccessRole.NURSE),
    ("bikash", AccessRole.NURSE),
    ("sunita", AccessRole.CARE_WORKER),
    ("deepa", AccessRole.CARE_WORKER),
]

NON_COG = CognitiveStatus.NON_COGNITIVE
COG = CognitiveStatus.COGNITIVE
DIS_COG = CognitiveStatus.DISABLED_COGNITIVE
DIS_NON_COG = CognitiveStatus.DISABLED_NON_COGNITIVE

# key, first, last, gender, dob, room, admitted, cognitive status,
# emergency contact (name, relationship, phone)
RESIDENTS = [
    ("ram", "Ram Bahadur", "Thapa", "Male", date(1938, 3, 14), "A-101", date(2023, 2, 10),
     NON_COG, ("Sanjay Thapa", "Son", "+977-9851067742")),
    ("bishnu", "Bishnu Maya", "Tamang", "Female", date(1941, 7, 2), "A-102", date(2024, 5, 19),
     DIS_COG, ("Pemba Tamang", "Son", "+977-9841302296")),
    ("krishna", "Krishna Prasad", "Adhikari", "Male", date(1936, 11, 23), "A-103", date(2022, 9, 1),
     DIS_NON_COG, ("Sabita Adhikari", "Daughter", "+977-9803118854")),
    ("sita", "Sita Devi", "Shrestha", "Female", date(1944, 1, 30), "A-104", date(2024, 1, 12),
     NON_COG, ("Rabin Shrestha", "Son", "+977-9818845530")),
    ("hari", "Hari Prasad", "Sharma", "Male", date(1940, 6, 18), "A-105", date(2023, 6, 25),
     DIS_COG, ("Gita Sharma", "Daughter-in-law", "+977-9860093127")),
    ("gita", "Gita Kumari", "Gurung", "Female", date(1947, 9, 9), "B-201", date(2025, 3, 3),
     NON_COG, ("Bimala Gurung", "Daughter", "+977-9842571106")),
    ("laxmi", "Laxmi Devi", "Rai", "Female", date(1943, 4, 27), "B-202", date(2023, 11, 15),
     DIS_COG, ("Suresh Rai", "Son", "+977-9813609475")),
    ("shyam", "Shyam Kumar", "Magar", "Male", date(1949, 12, 5), "B-203", date(2025, 7, 8),
     COG, ("Kopila Magar", "Wife", "+977-9861448802")),
    ("parbati", "Parbati Kumari", "Karki", "Female", date(1951, 2, 14), "B-204", date(2025, 1, 20),
     NON_COG, ("Ramesh Karki", "Nephew", "+977-9849215563")),
    ("dil", "Dil Bahadur", "Lama", "Male", date(1945, 8, 11), "B-205", date(2022, 12, 2),
     COG, ("Tashi Lama", "Son", "+977-9808367714")),
    ("kamala", "Kamala Devi", "Poudel", "Female", date(1948, 5, 21), "C-301", date(2024, 8, 14),
     COG, ("Bishal Poudel", "Grandson", "+977-9823904417")),
    ("tek", "Tek Bahadur", "Basnet", "Male", date(1937, 10, 3), "C-302", date(2023, 3, 28),
     DIS_NON_COG, ("Sarala Basnet", "Daughter", "+977-9841776653")),
    ("mina", "Mina Kumari", "Bhandari", "Female", date(1950, 3, 17), "C-303", date(2025, 5, 30),
     NON_COG, ("Prakash Bhandari", "Son", "+977-9851330098")),
    ("gopal", "Gopal Prasad", "Joshi", "Male", date(1942, 7, 29), "C-304", date(2024, 10, 10),
     NON_COG, ("Anita Joshi", "Daughter", "+977-9818726641")),
]

#: The risk score each resident was designed to receive. Checked by
#: `test_demo_dataset.py` against the real AHP-weighted scorer.
TARGET_SCORES = {
    "ram": 86, "bishnu": 79, "tek": 77,                 # Critical
    "krishna": 70, "sita": 56, "hari": 54, "gopal": 52,  # High
    "gita": 35, "laxmi": 29, "shyam": 27,               # Medium
    "mina": 20, "kamala": 17, "parbati": 9, "dil": 9,   # Low
}

#: Residents the dataset leaves without a key worker. The seed hands them to
#: the matching algorithm (`allocate.py`), which is what fills them.
UNALLOCATED = ("bishnu", "tek", "hari", "gopal")

#: Asmita Lama's agency placement ends this many days from the seed date —
#: close enough that the dashboard asks for her residents to be handed over.
AGENCY_ENDS_IN_DAYS = 18


@dataclass
class DemoAccount:
    employee_key: str
    email: str
    full_name: str
    access_role: AccessRole
    id: UUID


@dataclass
class DemoData:
    """Everything, in foreign-key order: writing the tables in the order of
    `tables` never references a row that does not exist yet."""

    today: date
    tables: dict[str, list[BaseModel]] = field(default_factory=dict)
    accounts: list[DemoAccount] = field(default_factory=list)
    resident_ids: dict[str, UUID] = field(default_factory=dict)
    employee_ids: dict[str, UUID] = field(default_factory=dict)

    def add(self, table: str, row: BaseModel) -> BaseModel:
        self.tables.setdefault(table, []).append(row)
        return row

    def rows(self, table: str) -> list[BaseModel]:
        return self.tables.get(table, [])


# ---------------------------------------------------------------------------
# the builder
# ---------------------------------------------------------------------------


def build(today: date | None = None) -> DemoData:
    today = today or datetime.now(NPT).date()
    data = DemoData(today=today)
    b = _Builder(data)
    b.staff()
    b.residents()
    b.assignments()
    b.clinical_records()
    b.charts()
    b.safety_records()
    b.roster()
    b.hr_records()
    b.front_desk()
    return data


class _Builder:
    def __init__(self, data: DemoData):
        self.d = data
        self.today = data.today
        self.E = data.employee_ids
        self.R = data.resident_ids

    # --- helpers ---------------------------------------------------------

    def at(self, days_ago: int, hour: int = 9, minute: int = 0) -> datetime:
        day = self.today - timedelta(days=days_ago)
        return datetime.combine(day, time(hour, minute), tzinfo=NPT)

    def day(self, days_ago: int) -> date:
        return self.today - timedelta(days=days_ago)

    def rid(self, table: str, key: str) -> UUID:
        return demo_id(table, key)

    # --- people ----------------------------------------------------------

    def staff(self):
        for key, first, last, role, status, hired, phone in STAFF:
            eid = demo_id("employee", key)
            self.E[key] = eid
            self.d.add(
                "employees",
                Employee(
                    id=eid,
                    first_name=first,
                    last_name=last,
                    email=f"{first.split()[0].lower()}.{last.lower()}@{EMAIL_DOMAIN}",
                    phone=phone,
                    role=role,
                    employment_status=status,
                    hire_date=hired,
                    active=True,
                ),
            )
        by_key = {row[0]: row for row in STAFF}
        for key, access in ACCOUNTS:
            _, first, last, *_ = by_key[key]
            self.d.accounts.append(
                DemoAccount(
                    employee_key=key,
                    email=f"{first.split()[0].lower()}.{last.lower()}@{EMAIL_DOMAIN}",
                    full_name=f"{first} {last}",
                    access_role=access,
                    id=demo_id("user", key),
                )
            )

    def residents(self):
        for key, first, last, gender, dob, room, admitted, cog, contact in RESIDENTS:
            rid = demo_id("resident", key)
            self.R[key] = rid
            name, relationship, phone = contact
            self.d.add(
                "residents",
                Resident(
                    id=rid,
                    first_name=first,
                    last_name=last,
                    dob=dob,
                    gender=gender,
                    cognitive_status=cog,
                    room_number=room,
                    admission_date=admitted,
                    emergency_contact=EmergencyContact(
                        name=name,
                        relationship=relationship,
                        phone=phone,
                        email=f"{name.split()[0].lower()}.{name.split()[-1].lower()}@family.example.np",
                    ),
                    active=True,
                ),
            )

    # --- who cares for whom ---------------------------------------------

    def assignments(self):
        P, S, REL = AssignmentType.PRIMARY, AssignmentType.SECONDARY, AssignmentType.RELIEF
        plan = [
            # resident, employee, type, started (days ago)
            ("ram", "anjali", P, 420), ("ram", "sunita", S, 200),
            ("krishna", "bikash", P, 610), ("krishna", "kiran", S, 150),
            ("sita", "pooja", P, 240),
            ("gita", "sunita", P, 190),
            ("laxmi", "kiran", P, 300), ("laxmi", "deepa", S, 90),
            ("shyam", "suman", P, 60),
            ("parbati", "asmita", P, 230),
            ("dil", "suman", P, 500),
            ("kamala", "asmita", P, 380),
            ("mina", "asmita", P, 110),
            # The gaps: covered day to day, but nobody named as key worker.
            ("hari", "nabin", REL, 45),
        ]
        for resident, employee, kind, started in plan:
            self.d.add(
                "resident_assignments",
                ResidentAssignment(
                    id=demo_id("assignment", f"{resident}:{employee}"),
                    resident_id=self.R[resident],
                    employee_id=self.E[employee],
                    assignment_type=kind,
                    start_date=self.day(started),
                    active=True,
                    notes="Key worker — family's first point of contact." if kind == P else None,
                ),
            )
        # History: a primary carer who moved on, closed rather than deleted,
        # so "who was responsible for Hari in spring" stays answerable.
        self.d.add(
            "resident_assignments",
            ResidentAssignment(
                id=demo_id("assignment", "hari:anjali:ended"),
                resident_id=self.R["hari"],
                employee_id=self.E["anjali"],
                assignment_type=P,
                start_date=self.day(400),
                end_date=self.day(50),
                active=False,
                notes="Ended when Anjali took over as clinical lead for wing A.",
            ),
        )

    # --- health ------------------------------------------------------------

    def clinical_records(self):
        doctors = {
            "gp": "Dr. Ramesh Adhikari (NMC 8812)",
            "neuro": "Dr. Sujata Pradhan (NMC 6045), Neurologist",
            "psych": "Dr. Binod Khanal (NMC 9377), Psychiatrist",
            "ortho": "Dr. Manish Joshi (NMC 7120), Orthopaedics",
        }
        history = {
            "ram": ("Parkinson's disease", "None known", "Parkinson's disease; Hypertension",
                    "TURP (2015)", "neuro", "Tremor worse in the evening. Soft diet preferred."),
            "bishnu": ("Left neck-of-femur fracture after fall; Osteoporosis",
                       "Penicillin (rash)", "Osteoporosis; Type 2 diabetes",
                       "Hemiarthroplasty, left hip (this year)", "ortho",
                       "Partial weight-bearing with frame. Diabetic diet."),
            "krishna": ("Alzheimer's disease, advanced", "Sulfa drugs",
                        "Alzheimer's disease; Benign prostatic hyperplasia", "None",
                        "psych", "Speaks Nepali and some Newari. Responds to bhajan music."),
            "sita": ("Vascular dementia", "None known", "Atrial fibrillation; Hypertension",
                     "Cataract surgery, both eyes (2019)", "gp",
                     "On anticoagulant — monitor for bruising after any fall."),
            "hari": ("Ischaemic stroke with left hemiparesis", "Aspirin intolerance (gastritis)",
                     "Hypertension; Hyperlipidaemia", "None", "neuro",
                     "Left-side neglect. Approach from the right."),
            "gita": ("Mild cognitive impairment", "Dust / pollen",
                     "Osteoarthritis, both knees", "None", "gp",
                     "Enjoys the garden; walks with a stick."),
            "laxmi": ("Oropharyngeal dysphagia", "None known",
                      "Chronic obstructive pulmonary disease", "None", "gp",
                      "IDDSI level 5 minced & moist diet, mildly thick fluids."),
            "shyam": ("Major depressive disorder", "None known", "Hypertension", "Appendectomy (1982)",
                      "psych", "Former schoolteacher. Engages well with reading group."),
            "parbati": ("Early-stage dementia", "Shellfish", "Hypothyroidism", "None", "gp",
                        "Orientation board in room helps."),
            "dil": ("Chronic obstructive pulmonary disease", "None known",
                    "COPD; Bilateral cataract", "None", "gp",
                    "Uses inhaler independently. Ex-smoker (quit 2010)."),
            "kamala": ("Osteoarthritis", "Ibuprofen (asthma)", "Type 2 diabetes; Osteoarthritis",
                       "Right knee replacement (2018)", "ortho", "Independent, attends yoga."),
            "tek": ("Lewy body dementia with parkinsonism", "Haloperidol (severe sensitivity)",
                    "Orthostatic hypotension", "None", "neuro",
                    "Visual hallucinations in the evening. Settles with a familiar carer — "
                    "has done best with Deepa Karki."),
            "mina": ("Mild dementia", "None known", "Hypothyroidism", "Thyroidectomy (partial, 2004)",
                     "gp", "Likes to help fold laundry."),
            "gopal": ("Frontotemporal dementia (behavioural variant)", "None known",
                      "Hypertension", "None", "psych",
                      "Exit-seeking in the afternoon. Responds to walks with a familiar carer."),
        }
        for key, (diagnosis, allergies, chronic, surgeries, doctor, notes) in history.items():
            self.d.add(
                "resident_medical_history",
                ResidentMedicalHistory(
                    id=self.rid("history", key),
                    resident_id=self.R[key],
                    diagnosis=diagnosis,
                    allergies=allergies,
                    chronic_conditions=chronic,
                    surgeries=surgeries,
                    doctor_name=doctors[doctor],
                    notes=notes,
                    recorded_at=self.at(120, 11),
                ),
            )

        meds = {
            "ram": [("Levodopa/Carbidopa", "100/25 mg", "Three times daily", "Oral", "neuro"),
                    ("Amlodipine", "5 mg", "Once daily, morning", "Oral", "gp")],
            "bishnu": [("Metformin", "500 mg", "Twice daily with meals", "Oral", "gp"),
                       ("Calcium + Vitamin D3", "500 mg / 400 IU", "Once daily", "Oral", "ortho"),
                       ("Paracetamol", "500 mg", "When required, max 4 g/day", "Oral", "ortho")],
            "krishna": [("Donepezil", "10 mg", "Once daily, night", "Oral", "psych"),
                        ("Tamsulosin", "0.4 mg", "Once daily", "Oral", "gp")],
            "sita": [("Apixaban", "2.5 mg", "Twice daily", "Oral", "gp"),
                     ("Losartan", "50 mg", "Once daily", "Oral", "gp")],
            "hari": [("Clopidogrel", "75 mg", "Once daily", "Oral", "neuro"),
                     ("Atorvastatin", "40 mg", "Once daily, night", "Oral", "neuro"),
                     ("Telmisartan", "40 mg", "Once daily", "Oral", "gp")],
            "gita": [("Paracetamol", "1 g", "Twice daily", "Oral", "gp"),
                     ("Diclofenac gel", "1%", "Apply to knees three times daily", "Topical", "gp")],
            "laxmi": [("Tiotropium inhaler", "18 mcg", "Once daily", "Inhaled", "gp"),
                      ("Salbutamol inhaler", "100 mcg", "When required", "Inhaled", "gp")],
            "shyam": [("Sertraline", "50 mg", "Once daily, morning", "Oral", "psych"),
                      ("Amlodipine", "5 mg", "Once daily", "Oral", "gp")],
            "parbati": [("Levothyroxine", "50 mcg", "Once daily before breakfast", "Oral", "gp")],
            "dil": [("Budesonide/Formoterol inhaler", "200/6 mcg", "Twice daily", "Inhaled", "gp")],
            "kamala": [("Metformin", "1 g", "Twice daily", "Oral", "gp"),
                       ("Glimepiride", "1 mg", "Once daily with breakfast", "Oral", "gp")],
            "tek": [("Rivastigmine patch", "4.6 mg/24 h", "Once daily", "Transdermal", "neuro"),
                    ("Levodopa/Carbidopa", "100/25 mg", "Twice daily", "Oral", "neuro"),
                    ("Fludrocortisone", "0.1 mg", "Once daily", "Oral", "neuro")],
            "mina": [("Levothyroxine", "75 mcg", "Once daily before breakfast", "Oral", "gp")],
            "gopal": [("Trazodone", "50 mg", "Once daily, night", "Oral", "psych"),
                      ("Amlodipine", "10 mg", "Once daily", "Oral", "gp")],
        }
        for key, items in meds.items():
            for index, (name, dose, freq, route, doctor) in enumerate(items):
                self.d.add(
                    "resident_medications",
                    ResidentMedication(
                        id=self.rid("medication", f"{key}:{index}"),
                        resident_id=self.R[key],
                        medication_name=name,
                        dosage=dose,
                        frequency=freq,
                        route=route,
                        prescribed_by=doctors[doctor],
                        start_date=self.day(200 - index * 30),
                        active=True,
                    ),
                )
        # A stopped medication stays on record — why it stopped matters.
        self.d.add(
            "resident_medications",
            ResidentMedication(
                id=self.rid("medication", "tek:stopped"),
                resident_id=self.R["tek"],
                medication_name="Quetiapine",
                dosage="12.5 mg",
                frequency="Once daily, night",
                route="Oral",
                prescribed_by=doctors["psych"],
                start_date=self.day(150),
                end_date=self.day(95),
                active=False,
                notes="Stopped: increased rigidity. Avoid antipsychotics (Lewy body dementia).",
            ),
        )

        supplies = [
            # resident, item, qty, unit, expires in (days), notes, added by
            ("bishnu", "Blood glucose test strips", 35, "strips", 120, "Check twice daily", "pooja"),
            ("bishnu", "Hip protector pants", 3, "pairs", None, None, "sunita"),
            ("kamala", "Blood glucose test strips", 12, "strips", 18, "Reorder — running low", "asmita"),
            ("tek", "Rivastigmine patches", 9, "patches", 40, None, "anjali"),
            ("ram", "Incontinence pads (large)", 40, "pads", None, None, "sunita"),
            ("krishna", "Incontinence pads (medium)", 22, "pads", None, None, "kiran"),
            ("laxmi", "Thickening powder", 1, "tins", 25, "Mildly thick (level 2)", "kiran"),
            ("dil", "Spacer for inhaler", 1, "units", None, None, "suman"),
            ("hari", "Wound dressing (foam, 10 cm)", 6, "dressings", 210, "Sacral area check", "bikash"),
            ("sita", "Compression stockings", 2, "pairs", None, None, "pooja"),
            ("gopal", "GPS wristband (charger)", 1, "units", None, "Worn on afternoon walks", "deepa"),
        ]
        for index, (key, item, qty, unit, expires, notes, added) in enumerate(supplies):
            self.d.add(
                "resident_medical_inventory",
                ResidentMedicalInventory(
                    id=self.rid("inventory", f"{key}:{index}"),
                    resident_id=self.R[key],
                    item_name=item,
                    quantity=qty,
                    unit=unit,
                    expiry_date=(self.today + timedelta(days=expires)) if expires else None,
                    notes=notes,
                    added_by=self.E[added],
                    created_at=self.at(20 + index, 10),
                ),
            )

    # --- daily charts -------------------------------------------------------

    def charts(self):
        """Sleep and bowel charts for the last week, plus behaviour events.

        Who records each entry is deliberate: it is how the carer-matching
        algorithm knows which staff already know a resident. The four
        unallocated residents are charted by the carers the story needs —
        Deepa for Tek, Deepa and Kiran for Gopal, Pooja for Bishnu, Bikash
        for Hari. Asmita's residents are also charted by Suman and Sunita,
        so when her agency placement ends the hand-over plan has people who
        already know them — and Suman knows two of them, which only one
        allocation can honour.
        """
        charted_by = {
            "ram": ["anjali", "sunita"],
            "bishnu": ["pooja"],
            "krishna": ["bikash", "kiran"],
            "sita": ["pooja", "anjali"],
            "hari": ["bikash"],
            "gita": ["sunita"],
            "laxmi": ["kiran", "deepa"],
            "shyam": ["suman"],
            "parbati": ["asmita", "suman"],
            "dil": ["suman"],
            "kamala": ["asmita", "sunita"],
            "tek": ["deepa"],
            "mina": ["asmita", "suman"],
            "gopal": ["deepa", "kiran"],
        }
        poor_sleepers = {"krishna", "tek", "gopal", "ram", "sita"}
        bristol = ["Type 4 — smooth, soft", "Type 3 — cracked surface", "Type 5 — soft blobs",
                   "Type 2 — lumpy", "Type 4 — smooth, soft", "Type 6 — mushy"]
        for key, carers in charted_by.items():
            for n in range(1, 8):
                recorder = self.E[carers[n % len(carers)]]
                poor = key in poor_sleepers and n % 3 != 0
                hours = 5.5 if poor else 7.5
                self.d.add(
                    "resident_sleep_chart",
                    ResidentSleepChart(
                        id=self.rid("sleep", f"{key}:{n}"),
                        resident_id=self.R[key],
                        sleep_date=self.day(n),
                        sleep_start=time(21, 30) if not poor else time(22, 45),
                        wake_time=time(5, 0) if not poor else time(4, 15),
                        total_hours=hours,
                        disturbances=("Woke twice, restless; resettled with reassurance"
                                      if poor else None),
                        recorded_by=recorder,
                    ),
                )
            for n in range(1, 6):
                self.d.add(
                    "resident_bowel_chart",
                    ResidentBowelChart(
                        id=self.rid("bowel", f"{key}:{n}"),
                        resident_id=self.R[key],
                        recorded_at=self.at(n, 8, 30),
                        bowel_type=bristol[(n + len(key)) % len(bristol)],
                        consistency="Normal" if n % 4 else "Soft",
                        notes=None if n % 3 else "Independent toileting with prompt",
                        recorded_by=self.E[carers[(n + 1) % len(carers)]],
                    ),
                )

        # Behaviour events. The count inside the last 30 days is one of the
        # five risk signals, so these numbers are part of each resident's
        # designed score; the older ones show that the window moves.
        behaviour = {
            "ram": [(3, "Refused evening medication, agitated", "Pain in hands",
                     "Offered paracetamol, slowed pace", "Took medication 20 min later"),
                    (9, "Called out repeatedly at night", "Needed toilet", "Toileted, repositioned", "Settled"),
                    (22, "Pushed carer's hand away during wash", "Cold water", "Warmed water, explained each step", "Calm")],
            "bishnu": [(6, "Tried to stand without frame", "Wanted to reach wardrobe",
                        "Moved items within reach", "Sat back down"),
                       (18, "Tearful, asking for son", "Missed video call", "Arranged call with Pemba", "Settled after call")],
            "krishna": [(1, "Verbal aggression at lunch", "Noise in dining room",
                         "Moved to quiet table", "Ate most of meal"),
                        (5, "Wandering into other rooms", "Looking for 'the office'",
                         "Walked with him, redirected", "Returned to lounge"),
                        (12, "Hitting out during shower", "Fear of water",
                         "Switched to bed bath", "Tolerated"),
                        (26, "Shouting at night", "Unclear", "Played bhajan music", "Fell asleep")],
            "sita": [(14, "Accused staff of taking her bangles", "Misplaced jewellery",
                      "Searched room together, found in drawer", "Reassured")],
            "hari": [(7, "Frustration, threw spoon", "Difficulty with left hand",
                      "Provided adapted cutlery", "Finished meal"),
                     (20, "Refused physiotherapy", "Fatigue", "Rescheduled to morning", "Attended next day")],
            "gita": [(10, "Anxious about money", "Visit from bank reminder letter",
                      "Called daughter", "Calmer")],
            "shyam": [(4, "Stayed in room all day, not eating", "Low mood",
                       "One-to-one conversation, brought tea", "Ate dinner"),
                      (11, "Tearful at prayer time", "Anniversary of brother's death",
                       "Listened, offered to light a diyo", "Comforted"),
                      (25, "Declined group activity", "Low mood", "Invited to reading group", "Joined late"),
                      (48, "Refused breakfast", "Low mood", "Offered alternatives", "Ate later")],
            "parbati": [(16, "Asked repeatedly what day it is", "Disorientation",
                         "Updated orientation board", "Settled")],
            "tek": [(2, "Visual hallucinations — 'children in the room'", "Evening, low light",
                     "Turned lights on, stayed with him (Deepa)", "Settled after 15 min"),
                    (40, "Resisted transfer", "Rigidity", "Two-person assist, slower pace", "Transferred safely")],
            "mina": [(8, "Packing bags to 'go home'", "Late afternoon",
                      "Offered to help fold laundry", "Engaged, forgot about leaving"),
                     (19, "Refused shower", "Felt cold", "Warmed bathroom first", "Showered")],
            "gopal": [(5, "Attempted to leave through front gate", "Afternoon restlessness",
                       "Accompanied on a walk in the garden (Deepa)", "Returned calmly")],
        }
        for key, events in behaviour.items():
            carers = charted_by[key]
            for index, (days_ago, what, trigger, action, outcome) in enumerate(events):
                self.d.add(
                    "resident_behaviour",
                    ResidentBehaviour(
                        id=self.rid("behaviour", f"{key}:{index}"),
                        resident_id=self.R[key],
                        behaviour=what,
                        trigger=trigger,
                        intervention=action,
                        outcome=outcome,
                        recorded_by=self.E[carers[index % len(carers)]],
                        recorded_at=self.at(days_ago, 17, 20),
                    ),
                )

    # --- safety: fall risk, assistance, incidents ---------------------------

    def safety_records(self):
        H, M, L = RiskLevel.HIGH, RiskLevel.MEDIUM, RiskLevel.LOW
        # Latest assessment is what counts; earlier ones are history.
        fall_risk = {
            "ram": [(10, H, "anjali"), (130, M, "anjali")],
            "bishnu": [(19, H, "pooja"), (160, M, "pooja")],
            "krishna": [(30, M, "bikash")],
            "sita": [(15, H, "pooja")],
            "hari": [(28, M, "bikash")],
            "gita": [(45, M, "sunita")],
            "laxmi": [(60, L, "kiran")],
            "shyam": [(35, M, "suman")],
            "parbati": [(70, L, "asmita")],
            "dil": [(90, L, "suman")],
            "kamala": [(50, M, "asmita")],
            "tek": [(12, H, "deepa"), (100, H, "anjali")],
            "mina": [(40, L, "asmita")],
            "gopal": [(21, M, "deepa")],
        }
        interventions = {
            H: "Low-low bed, sensor mat, hip protectors, hourly checks, supervised mobility",
            M: "Non-slip footwear, call bell within reach, night light, toileting schedule",
            L: "Standard precautions, annual review",
        }
        for key, assessments in fall_risk.items():
            for index, (days_ago, level, assessor) in enumerate(assessments):
                self.d.add(
                    "resident_fall_risk",
                    ResidentFallRisk(
                        id=self.rid("fallrisk", f"{key}:{index}"),
                        resident_id=self.R[key],
                        risk_level=level,
                        assessment_date=self.day(days_ago),
                        assessed_by=self.E[assessor],
                        interventions=interventions[level],
                        notes="Reassessed after incident." if index == 0 and level == H else None,
                    ),
                )

        I, S2, D2 = AssistanceLevel.INDEPENDENT, AssistanceLevel.SINGLE_ASSIST, AssistanceLevel.DOUBLE_ASSIST
        assistance = {
            "ram": (D2, "Wheelchair; standing hoist for transfers", "Two staff for all transfers", "anjali"),
            "bishnu": (S2, "Walking frame, partial weight-bearing", "One staff, gait belt", "pooja"),
            "krishna": (D2, "Hoist; unable to follow transfer prompts", "Two staff, full hoist", "bikash"),
            "sita": (S2, "Walking stick, unsteady on turns", "Stand-by assist", "pooja"),
            "hari": (S2, "Quad stick, left-side weakness", "Assist from the left", "bikash"),
            "gita": (S2, "Walking stick", "Stand-by assist on stairs", "sunita"),
            "laxmi": (S2, "Walking frame", "One staff for shower", "kiran"),
            "shyam": (I, "Independent", None, "suman"),
            "parbati": (I, "Independent", None, "asmita"),
            "dil": (S2, "Walks short distances; breathless on exertion", "Rest stops", "suman"),
            "kamala": (I, "Independent", None, "asmita"),
            "tek": (D2, "Wheelchair; marked rigidity", "Two staff, slide sheet", "deepa"),
            "mina": (S2, "Walking frame outdoors", "Stand-by assist", "asmita"),
            "gopal": (S2, "Walks independently but unsafe outdoors", "Accompany outside", "deepa"),
        }
        for key, (level, mobility, notes, by) in assistance.items():
            self.d.add(
                "resident_assistance",
                ResidentAssistance(
                    id=self.rid("assistance", key),
                    resident_id=self.R[key],
                    assistance_level=level,
                    mobility=mobility,
                    transfer_notes=notes,
                    updated_by=self.E[by],
                    updated_at=self.at(14, 12),
                ),
            )

        C, Hi, Me, Lo = (IncidentSeverity.CRITICAL, IncidentSeverity.HIGH,
                         IncidentSeverity.MEDIUM, IncidentSeverity.LOW)
        OPEN, REVIEW, REPORTED, CLOSED = (IncidentStatus.OPEN, IncidentStatus.UNDER_REVIEW,
                                          IncidentStatus.REPORTED, IncidentStatus.CLOSED)
        incidents = [
            # resident, days ago, type, severity, status, location, reporter,
            # description, immediate action, reportable
            ("ram", 12, "Fall", Hi, REVIEW, "Bathroom, room A-101", "anjali",
             "Found on bathroom floor at 02:10. Laceration to left eyebrow.",
             "First aid, neuro obs every 30 min, GP informed, son notified", False),
            ("ram", 40, "Skin tear", Me, CLOSED, "Lounge", "sunita",
             "3 cm skin tear on right forearm during transfer.",
             "Cleaned and dressed, transfer plan reviewed", False),
            ("bishnu", 20, "Fall with injury", C, REPORTED, "Corridor near room A-102", "pooja",
             "Unwitnessed fall. X-ray confirmed left neck-of-femur fracture; transferred to hospital.",
             "Ambulance called, family informed, incident escalated", True),
            ("krishna", 25, "Physical aggression", Me, CLOSED, "Dining room", "bikash",
             "Struck another resident on the arm during lunch. No injury.",
             "Residents separated, behaviour support plan updated", False),
            ("krishna", 60, "Near miss", Lo, CLOSED, "Bedroom", "kiran",
             "Found sitting on edge of bed with bed rail lowered.",
             "Bed lowered, sensor mat added", False),
            ("sita", 50, "Near miss", Lo, CLOSED, "Garden path", "pooja",
             "Stumbled on uneven paving, caught by staff.",
             "Maintenance request raised for the path", False),
            ("hari", 8, "Medication error", Hi, OPEN, "Medication room", "bikash",
             "Evening clopidogrel given twice (double dose).",
             "GP contacted, observations for bleeding, pharmacist review requested", False),
            ("laxmi", 33, "Choking", Me, CLOSED, "Dining room", "kiran",
             "Coughing episode with mince; cleared with back blows.",
             "Speech therapy referral, texture re-checked", False),
            ("shyam", 70, "Verbal complaint", Lo, CLOSED, "Lounge", "suman",
             "Argument with another resident over television.",
             "Mediated; TV schedule agreed", False),
            ("dil", 140, "Near miss", Lo, CLOSED, "Bathroom", "suman",
             "Slipped on wet floor, no fall.",
             "Wet-floor signage reinforced", False),
            ("tek", 15, "Fall", Me, REVIEW, "Bedroom, room C-302", "deepa",
             "Slid from wheelchair to floor during hallucination. No injury.",
             "Two-person lift, obs, lap belt reviewed with physio", False),
            ("gopal", 18, "Absconding", Me, CLOSED, "Front gate", "deepa",
             "Left through front gate behind a visitor; found 200 m down the road.",
             "Accompanied back, gate code changed, GPS band fitted", True),
            ("gopal", 45, "Absconding", Me, CLOSED, "Garden", "kiran",
             "Climbed low garden wall, found in neighbour's yard.",
             "Wall height raised, afternoon walks scheduled", False),
        ]
        for index, (key, days_ago, kind, severity, status, where, reporter,
                    description, action, reportable) in enumerate(incidents):
            occurred = self.at(days_ago, 14 if index % 2 else 2, 10)
            self.d.add(
                "resident_incidents",
                ResidentIncident(
                    id=self.rid("incident", f"{key}:{index}"),
                    resident_id=self.R[key],
                    incident_type=kind,
                    severity=severity,
                    description=description,
                    occurred_at=occurred,
                    location=where,
                    reported_by=self.E[reporter],
                    witnesses=None if "Unwitnessed" in description else "Staff on duty",
                    immediate_action=action,
                    is_sirs_reportable=reportable,
                    sirs_notified_at=occurred + timedelta(hours=20) if reportable else None,
                    sirs_reference_number=(f"SEC-{self.today.year}-{410 + index:04d}"
                                           if reportable else None),
                    status=status,
                    outcome=("Closed after review; care plan updated." if status == CLOSED else None),
                    created_at=occurred,
                    updated_at=occurred,
                ),
            )

    # --- roster ------------------------------------------------------------

    def roster(self):
        """Four weeks of shifts: two past (completed, with time sheets),
        the current week, and next week — which has open shifts to fill.

        Shift times are Nepal time: morning 07-15, evening 15-23, night 23-07.
        """
        monday = self.today - timedelta(days=self.today.weekday())
        next_monday = monday + timedelta(days=7)
        now = datetime.now(NPT)

        M, E, N = (7, 8), (15, 8), (23, 8)
        # employee -> list of (weekday 0=Mon, (start hour, length)).
        # Saturday is the weekly day off in Nepal, so most patterns skip it.
        pattern = {
            "anjali": [(0, M), (1, M), (2, M), (3, M), (4, M)],
            "bikash": [(0, E), (1, E), (2, E), (3, N), (6, E)],
            "pooja": [(0, M), (2, E)],
            "nabin": [(3, N), (4, N), (6, N)],
            "sunita": [(0, M), (1, M), (2, M), (3, M), (4, M), (6, M)],
            "kiran": [(1, E), (3, E), (4, E)],
            "deepa": [(0, E), (1, E), (2, E), (4, E), (6, E)],
            "suman": [(0, M), (1, M), (3, M), (4, M), (6, M)],
            "asmita": [(1, N), (2, N), (4, N)],
            "harik": [(0, (6, 8)), (1, (6, 8)), (2, (6, 8)), (3, (6, 8)), (4, (6, 8)), (6, (6, 8))],
            "nirmala": [(0, (12, 8)), (2, (12, 8)), (4, (12, 8))],
            "mohan": [(0, (8, 8)), (1, (8, 8)), (2, (8, 8)), (3, (8, 8)), (4, (8, 8))],
            "sarita": [(0, (9, 8)), (1, (9, 8)), (2, (9, 8)), (3, (9, 8)), (4, (9, 8))],
            "rajesh": [(0, (9, 8)), (1, (9, 8)), (2, (9, 8)), (3, (9, 8)), (4, (9, 8))],
        }
        roles = {key: role for key, _, _, role, *_ in STAFF}

        def when(week_start: date, weekday: int, start_hour: int, length: int):
            start = datetime.combine(week_start + timedelta(days=weekday), time(start_hour), tzinfo=NPT)
            return start, start + timedelta(hours=length)

        for week_offset in (-14, -7, 0, 7):
            week_start = monday + timedelta(days=week_offset)
            for key, slots in pattern.items():
                for weekday, (start_hour, length) in slots:
                    start, end = when(week_start, weekday, start_hour, length)
                    # Next week: Anjali starts early on Friday (06:00), which
                    # is what makes her unavailable for Thursday's night shift.
                    if week_offset == 7 and key == "anjali" and weekday == 4:
                        start, end = when(week_start, 4, 6, 8)
                    shift_id = self.rid("shift", f"{key}:{week_start.isoformat()}:{weekday}:{start_hour}")
                    past = end < now
                    status = (ShiftStatus.COMPLETED if past
                              else ShiftStatus.CONFIRMED if week_offset == 0
                              else ShiftStatus.SCHEDULED)
                    self.d.add(
                        "employee_shifts",
                        EmployeeShift(
                            id=shift_id,
                            employee_id=self.E[key],
                            shift_start=start,
                            shift_end=end,
                            role=str(roles[key]),
                            location=_location_for(roles[key]),
                            status=status,
                        ),
                    )
                    if past:
                        late = (int(shift_id.hex[:4], 16) % 11) - 3  # a few minutes either way, stable
                        self.d.add(
                            "employee_time_entries",
                            EmployeeTimeEntry(
                                id=self.rid("timeentry", shift_id.hex),
                                employee_id=self.E[key],
                                shift_id=shift_id,
                                clock_in=start + timedelta(minutes=late),
                                clock_out=end + timedelta(minutes=5 + abs(late)),
                                notes="Stayed for handover" if abs(late) > 5 else None,
                            ),
                        )

        # Open shifts: rostered demand with nobody on it yet. These are what
        # the Roster page's "Fill open shifts" runs the optimiser over.
        open_shifts = [
            # key, weekday, start hour, length, role, note
            ("tue-night-rn", 1, 23, 8, RN, "Extra RN — palliative care, room C-302"),
            ("thu-night-rn", 3, 23, 8, RN, "Second RN on nights — two residents on hourly obs"),
            ("sat-morning-coord", 5, 7, 8, COORD, "Weekend cover — outing to Budhanilkantha temple"),
            ("sat-evening-planner", 5, 15, 8, PLANNER, "Care plan reviews before family meetings"),
            ("sun-morning-kitchen", 6, 6, 8, KITCHEN, "Dashain preparation — extra cook"),
        ]
        for key, weekday, start_hour, length, role, note in open_shifts:
            start, end = when(next_monday, weekday, start_hour, length)
            self.d.add(
                "employee_shifts",
                EmployeeShift(
                    id=self.rid("shift", f"open:{next_monday.isoformat()}:{key}"),
                    employee_id=None,
                    shift_start=start,
                    shift_end=end,
                    role=str(role),
                    location=_location_for(role),
                    status=ShiftStatus.SCHEDULED,
                    notes=note,
                ),
            )

        weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        for key, slots in pattern.items():
            working = {weekday for weekday, _ in slots}
            first_start, length = slots[0][1]
            for index, name in enumerate(weekdays):
                self.d.add(
                    "employee_availability",
                    EmployeeAvailability(
                        id=self.rid("availability", f"{key}:{name}"),
                        employee_id=self.E[key],
                        weekday=name,
                        start_time=time(first_start % 24) if index in working else None,
                        end_time=time((first_start + length) % 24) if index in working else None,
                        available=index in working,
                    ),
                )

    # --- HR ------------------------------------------------------------------

    def hr_records(self):
        rates = {MANAGER: 420, ADMIN: 300, RN: 265, PLANNER: 215, COORD: 205, KITCHEN: 160, LAUNDRY: 150}
        hours = {FT: 48, PT: 24, CASUAL: 16, AGENCY: 32}
        for key, first, last, role, status, hired, _ in STAFF:
            rate = rates[role]
            weekly = hours[status]
            self.d.add(
                "employee_contracts",
                EmployeeContract(
                    id=self.rid("contract", key),
                    employee_id=self.E[key],
                    contract_type={FT: "Permanent, full-time", PT: "Permanent, part-time",
                                   CASUAL: "Casual (on call)", AGENCY: "Agency placement"}[status],
                    contracted_hours=weekly,
                    hourly_rate=rate,
                    start_date=hired,
                    # The agency placement ends soon: the dashboard asks for
                    # a hand-over of her residents, which is the Care teams
                    # screen's hand-over plan with something real to do.
                    end_date=(self.today + timedelta(days=AGENCY_ENDS_IN_DAYS)) if status == AGENCY else None,
                    annual_leave_hours=144 if status in (FT, PT) else 0,
                    sick_leave_hours=96 if status in (FT, PT) else 0,
                    notes="Rates in NPR per hour. Entitlements under the Labour Act, 2074 (2017); "
                          "SSF contribution 11% employee / 20% employer.",
                ),
            )

            # Two monthly pay runs: last month paid, this month in draft.
            for months_back, state in ((1, PayrollStatus.PAID), (0, PayrollStatus.DRAFT)):
                period_start = (self.today.replace(day=1) - timedelta(days=1)).replace(day=1) \
                    if months_back else self.today.replace(day=1)
                period_end = (period_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
                worked = round(weekly * 4.2 * (1 if months_back else 0.6), 1)
                gross = round(worked * rate, 2)
                deductions = round(gross * 0.12, 2)  # SSF 11% + 1% social security tax
                self.d.add(
                    "employee_payroll_records",
                    EmployeePayrollRecord(
                        id=self.rid("payroll", f"{key}:{period_start.isoformat()}"),
                        employee_id=self.E[key],
                        pay_period_start=period_start,
                        pay_period_end=period_end,
                        total_hours=worked,
                        hourly_rate=rate,
                        gross_pay=gross,
                        deductions=deductions,
                        net_pay=round(gross - deductions, 2),
                        status=state,
                        notes="Paid by bank transfer (NPR)." if state == PayrollStatus.PAID
                        else "Month in progress — hours to date.",
                    ),
                )

        # Qualifications and registrations: the credentials that matter for a
        # care role in Nepal. Every number is fictional.
        quals = {
            "sarita": [("Master of Nursing (Adult Health)", "Tribhuvan University, Institute of Medicine", 2016, None),
                       ("Basic Life Support (BLS)", "Nepal Red Cross Society", -300, 430)],
            "anjali": [("Bachelor of Nursing Science (BNS)", "Tribhuvan University, Institute of Medicine", 2018, None),
                       ("Basic Life Support (BLS)", "Nepal Red Cross Society", -400, 330),
                       ("Palliative Care Nursing Certificate", "B.P. Koirala Institute of Health Sciences", 2022, None)],
            "bikash": [("Bachelor of Nursing Science (BNS)", "Kathmandu University School of Medical Sciences", 2019, None),
                       ("Basic Life Support (BLS)", "Nepal Red Cross Society", -700, 25)],
            "pooja": [("PCL Nursing (Staff Nurse)", "CTEVT — Council for Technical Education and Vocational Training", 2021, None),
                      ("Basic Life Support (BLS)", "Nepal Red Cross Society", -200, 530)],
            "nabin": [("PCL Nursing (Staff Nurse)", "CTEVT — Council for Technical Education and Vocational Training", 2022, None)],
            "sunita": [("Caregiver Level 2 (440 hours)", "CTEVT", 2020, None),
                       ("Dementia Care Training (40 hours)", "Nepal Red Cross Society", 2023, None)],
            "kiran": [("Caregiver Level 2 (440 hours)", "CTEVT", 2021, None),
                      ("Diploma in Health Science (Health Assistant)", "CTEVT", 2019, None)],
            "deepa": [("Caregiver Level 2 (440 hours)", "CTEVT", 2020, None),
                      ("Dementia Care Training (40 hours)", "Nepal Red Cross Society", 2024, None),
                      ("First Aid Certificate", "Nepal Red Cross Society", -500, -10)],
            "suman": [("Caregiver Level 1 (390 hours)", "CTEVT", 2021, None),
                      ("First Aid Certificate", "Nepal Red Cross Society", -100, 630)],
            "asmita": [("Caregiver Level 2 (440 hours)", "CTEVT", 2023, None)],
            "harik": [("Food Hygiene and Safety", "Department of Food Technology and Quality Control", -150, 580)],
            "nirmala": [("Cook (Level 1)", "CTEVT", 2022, None),
                        ("Food Hygiene and Safety", "Department of Food Technology and Quality Control", -600, 40)],
            "mohan": [("Infection Prevention and Control — Laundry", "Nepal Red Cross Society", 2024, None)],
            "rajesh": [("Bachelor of Business Studies (BBS)", "Tribhuvan University", 2014, None)],
        }
        for key, items in quals.items():
            for index, (name, institution, completed, expires) in enumerate(items):
                # A year for degrees; days-ago for renewable certificates.
                if completed > 1900:
                    completion = date(completed, 6, 30)
                else:
                    completion = self.today + timedelta(days=completed)
                self.d.add(
                    "employee_qualifications",
                    EmployeeQualification(
                        id=self.rid("qualification", f"{key}:{index}"),
                        employee_id=self.E[key],
                        qualification_name=name,
                        institution=institution,
                        completion_date=completion,
                        expiry_date=(self.today + timedelta(days=expires)) if expires is not None else None,
                    ),
                )

        registrations = [
            # employee, type, number, authority, issued (days ago), expires in (days), verified
            ("sarita", "Nurse Registration (Bachelor/Master level)", "NNC-B-04417",
             "Nepal Nursing Council", 2400, 520, True),
            ("anjali", "Nurse Registration (Bachelor level)", "NNC-B-11862",
             "Nepal Nursing Council", 2100, 310, True),
            ("bikash", "Nurse Registration (Bachelor level)", "NNC-B-13950",
             "Nepal Nursing Council", 1800, 21, True),
            ("pooja", "Nurse Registration (PCL level)", "NNC-P-29305",
             "Nepal Nursing Council", 1000, 400, True),
            ("nabin", "Nurse Registration (PCL level)", "NNC-P-31477",
             "Nepal Nursing Council", 600, 700, False),
            ("kiran", "Health Assistant Registration", "NHPC-HA-08821",
             "Nepal Health Professional Council", 1500, 180, True),
            ("sunita", "Skill Test Certificate — Caregiver Level 2", "NSTB-CG2-55210",
             "National Skill Testing Board", 1700, None, True),
            ("deepa", "Skill Test Certificate — Caregiver Level 2", "NSTB-CG2-57734",
             "National Skill Testing Board", 1600, None, True),
            ("asmita", "Skill Test Certificate — Caregiver Level 2", "NSTB-CG2-60192",
             "National Skill Testing Board", 700, None, False),
        ]
        for key, kind, number, authority, issued, expires, verified in registrations:
            self.d.add(
                "employee_registration",
                EmployeeRegistration(
                    id=self.rid("registration", key),
                    employee_id=self.E[key],
                    registration_type=kind,
                    registration_number=number,
                    issuing_authority=authority,
                    issue_date=self.day(issued),
                    expiry_date=(self.today + timedelta(days=expires)) if expires is not None else None,
                    verified=verified,
                ),
            )

        reviews = [
            # employee, reviewer, days ago, rating, strengths, improvements, goals
            ("anjali", "sarita", 60, 5, "Clinical leadership on wing A; calm in emergencies",
             "Delegate more documentation", "Complete palliative care audit"),
            ("bikash", "sarita", 75, 4, "Thorough medication rounds; good with families",
             "Double-check high-alert medications (see recent incident)",
             "Renew NNC registration and BLS before expiry"),
            ("pooja", "anjali", 40, 4, "Excellent rapport with Bishnu Maya after her fracture",
             "Confidence leading handover", "Lead two handovers a week"),
            ("sunita", "anjali", 90, 5, "Person-centred care plans; residents ask for her",
             "None significant", "Mentor new caregivers"),
            ("kiran", "anjali", 120, 3, "Reliable on evenings", "Timeliness of chart entries",
             "Complete charts before end of shift"),
            ("deepa", "sarita", 30, 5, "Outstanding dementia care — Tek Bahadur and Gopal settle with her",
             "Renew first aid certificate (expired)", "Share de-escalation techniques at staff meeting"),
            ("suman", "sarita", 110, 4, "Good activity planning", "Incident report detail",
             "Attend incident-writing workshop"),
            ("harik", "rajesh", 200, 4, "Consistent diabetic and texture-modified meals",
             "Stock rotation", "Introduce weekly menu with residents' favourites (dal bhat, sel roti)"),
            ("mohan", "rajesh", 180, 4, "Infection control in laundry", "Labelling residents' clothes",
             "New labelling system by next quarter"),
        ]
        for key, reviewer, days_ago, rating, strengths, improve, goals in reviews:
            self.d.add(
                "employee_performance",
                EmployeePerformance(
                    id=self.rid("performance", key),
                    employee_id=self.E[key],
                    reviewer=self.E[reviewer],
                    review_date=self.day(days_ago),
                    overall_rating=rating,
                    strengths=strengths,
                    improvements=improve,
                    goals=goals,
                    next_review=self.day(days_ago) + timedelta(days=365),
                ),
            )

        supervision = [
            ("bikash", "anjali", 8, "Medication error debrief (Hari Prasad, double dose)",
             "Two-person check for all anticoagulants/antiplatelets for 4 weeks", 20),
            ("pooja", "anjali", 16, "Post-fracture care plan for Bishnu Maya",
             "Update mobility plan with physio", 30),
            ("deepa", "sarita", 12, "Evening routine for Tek Bahadur — what is working",
             "Write settling plan into care notes so others can follow it", 14),
            ("kiran", "anjali", 22, "Chart timeliness", "Complete charts before leaving shift", 30),
            ("nabin", "anjali", 35, "Orientation to night routine", "Shadow Bikash for two nights", -5),
            ("asmita", "sarita", 28, "Agency induction review", "Complete fire-safety module", 10),
        ]
        for key, supervisor, days_ago, discussion, actions, follow_up in supervision:
            self.d.add(
                "employee_supervision",
                EmployeeSupervision(
                    id=self.rid("supervision", key),
                    employee_id=self.E[key],
                    supervisor=self.E[supervisor],
                    supervision_date=self.day(days_ago),
                    discussion=discussion,
                    action_items=actions,
                    follow_up_date=self.today + timedelta(days=follow_up),
                ),
            )

        leave = [
            # employee, type, starts in (days), length, status, approver, notes
            ("pooja", "Dashain festival leave", 22, 5, LeaveStatus.PENDING, None, "Travelling to Pokhara"),
            ("suman", "Dashain festival leave", 24, 4, LeaveStatus.APPROVED, "sarita", None),
            ("harik", "Annual leave (ghar bida)", 40, 7, LeaveStatus.PENDING, None, "Home visit to Dhading"),
            ("kiran", "Sick leave (birami bida)", -12, 2, LeaveStatus.APPROVED, "anjali", "Viral fever"),
            ("anjali", "Tihar festival leave", 45, 3, LeaveStatus.APPROVED, "sarita", None),
            ("mohan", "Annual leave (ghar bida)", -30, 5, LeaveStatus.APPROVED, "rajesh", None),
            ("nabin", "Study leave", 10, 2, LeaveStatus.REJECTED, "sarita", "Clashes with night roster; please re-apply"),
        ]
        for index, (key, kind, starts, length, status, approver, notes) in enumerate(leave):
            start = self.today + timedelta(days=starts)
            self.d.add(
                "employee_leave",
                EmployeeLeave(
                    id=self.rid("leave", f"{key}:{index}"),
                    employee_id=self.E[key],
                    leave_type=kind,
                    start_date=start,
                    end_date=start + timedelta(days=length - 1),
                    status=status,
                    approved_by=self.E[approver] if approver else None,
                    notes=notes,
                ),
            )

    # --- front desk ------------------------------------------------------------

    def front_desk(self):
        complaints = [
            # resident, employee, category, description, by, relationship, contact, status, days ago
            ("bishnu", None, "Care quality",
             "My mother fell and broke her hip. I want to know why nobody was with her.",
             "Pemba Tamang", "Son", "+977-9841302296", ComplaintStatus.INVESTIGATING, 18),
            ("krishna", "bikash", "Communication",
             "I was not told about the incident at lunch until two days later.",
             "Sabita Adhikari", "Daughter", "+977-9803118854", ComplaintStatus.RESOLVED, 23),
            ("gita", None, "Food",
             "Could Gita have dal bhat at lunch more often? She is not eating the pasta.",
             "Bimala Gurung", "Daughter", "+977-9842571106", ComplaintStatus.CLOSED, 60),
            ("hari", None, "Medication",
             "Concerned about the medication mistake. What is being done so it does not happen again?",
             "Gita Sharma", "Daughter-in-law", "+977-9860093127", ComplaintStatus.OPEN, 6),
            (None, None, "Facilities", "The visitor car park gate was locked at 5 pm on Saturday.",
             "Anonymous", None, None, ComplaintStatus.OPEN, 3),
            ("tek", "deepa", "Compliment",
             "Thank you to Deepa — my father is calmer than he has been in months.",
             "Sarala Basnet", "Daughter", "+977-9841776653", ComplaintStatus.CLOSED, 9),
        ]
        for index, (res, emp, category, text, by, relationship, contact, status, days_ago) in enumerate(complaints):
            created = self.at(days_ago, 10, 15)
            resolved = status in (ComplaintStatus.RESOLVED, ComplaintStatus.CLOSED)
            self.d.add(
                "complaints_feedback",
                ComplaintFeedback(
                    id=self.rid("complaint", str(index)),
                    resident_id=self.R[res] if res else None,
                    employee_id=self.E[emp] if emp else None,
                    category=category,
                    description=text,
                    submitted_by_name=by,
                    submitted_by_relationship=relationship,
                    submitted_by_contact=contact,
                    is_anonymous=by == "Anonymous",
                    status=status,
                    assigned_to=self.E["sarita"],
                    resolution_notes=("Met with family; apology given and care plan shared."
                                      if resolved else None),
                    resolved_at=created + timedelta(days=4) if resolved else None,
                    created_at=created,
                    updated_at=created,
                ),
            )

        appointments = [
            ("Suresh Neupane", "Facility tour", 2, time(11, 0), AppointmentStatus.PENDING,
             "Looking for a place for my father (82) after a stroke. Does he need to be mobile?"),
            ("Kalpana Maharjan", "Respite care enquiry", 5, time(14, 0), AppointmentStatus.CONFIRMED,
             "Two weeks of respite for my mother during Dashain while we travel."),
            ("Prabin Subedi", "Admission consultation", 1, time(10, 30), AppointmentStatus.PENDING,
             "My grandmother has dementia and wanders at night. Is there a secure wing?"),
            ("Srijana Oli", "Facility tour", -6, time(15, 0), AppointmentStatus.COMPLETED,
             "Toured with my brother. Considering admission next month."),
            ("Rohit Dahal", "Family meeting", 3, time(16, 0), AppointmentStatus.CONFIRMED,
             "Care plan meeting for Shyam Kumar Magar."),
            ("Manju Bista", "Facility tour", -2, time(11, 30), AppointmentStatus.CANCELLED,
             "Need to reschedule — will call back after Tihar."),
        ]
        for index, (name, kind, in_days, at_time, status, message) in enumerate(appointments):
            first, last = name.split()[0], name.split()[-1]
            preferred = self.today + timedelta(days=in_days)
            self.d.add(
                "appointments",
                Appointment(
                    id=self.rid("appointment", str(index)),
                    full_name=name,
                    email=f"{first.lower()}.{last.lower()}@family.example.np",
                    phone=f"+977-98{41000000 + index * 13377:08d}",
                    appointment_type=kind,
                    preferred_date=preferred,
                    preferred_time=at_time,
                    message=message,
                    status=status,
                    scheduled_at=(datetime.combine(preferred, at_time, tzinfo=NPT)
                                  if status in (AppointmentStatus.CONFIRMED, AppointmentStatus.COMPLETED)
                                  else None),
                    handled_by=self.E["rajesh"] if status != AppointmentStatus.PENDING else None,
                    created_at=self.at(max(3, -in_days + 5), 9),
                    updated_at=self.at(1, 9),
                ),
            )


def _location_for(role) -> str:
    return {
        RN: "Wing A & C — nursing station",
        PLANNER: "Wing B",
        COORD: "Wing B & C",
        KITCHEN: "Kitchen",
        LAUNDRY: "Laundry",
        ADMIN: "Front office",
        MANAGER: "Front office",
    }.get(role, "Main building")


#: The order tables must be written in so foreign keys always resolve.
TABLE_ORDER = [
    "employees",
    "residents",
    "resident_assignments",
    "resident_medical_history",
    "resident_medications",
    "resident_medical_inventory",
    "resident_sleep_chart",
    "resident_bowel_chart",
    "resident_behaviour",
    "resident_fall_risk",
    "resident_assistance",
    "resident_incidents",
    "employee_shifts",
    "employee_time_entries",
    "employee_availability",
    "employee_contracts",
    "employee_payroll_records",
    "employee_qualifications",
    "employee_registration",
    "employee_performance",
    "employee_supervision",
    "employee_leave",
    "complaints_feedback",
    "appointments",
]
