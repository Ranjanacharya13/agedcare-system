"""Give every demo resident a key worker and a backup — using the system's
own allocation, not a hand-written list.

The dataset (`dataset.py`) deliberately leaves some care-team places empty:
four residents have no key worker, and most have no backup. Those gaps are
what the matching algorithm is for, so the seed fills them the same way a
manager would on the Care teams screen:

1. ask `CarerMatchingService` for the optimal key-worker plan (Hungarian);
2. confirm it through `AssignmentService.create_many`, with every rule the
   screen applies (one key worker each, nobody twice on one team);
3. do the same again for backup carers.

Running the real services means what appears on screen after seeding is
exactly what the algorithm chose from this data — and the script can print
*why*, including where taking residents one at a time would have chosen
differently.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from backend.models.resident_assignment import AssignmentType
from backend.schemas.carer_suggestion import SuggestAssignmentsOut
from backend.schemas.resident_assignment import BulkAssignmentItem, BulkAssignmentOut
from backend.services.assignment_service import AssignmentService
from backend.services.carer_matching import CarerMatchingService
from backend.services.risk_scoring import RiskScoringService

#: Written on each assignment the algorithm chose, so the care-teams board
#: can say which places were filled by a suggestion.
ALGORITHM_NOTE = "Suggested by CareOS matching (Hungarian algorithm) and confirmed."


@dataclass
class AllocationStep:
    kind: AssignmentType
    plan: SuggestAssignmentsOut
    result: BulkAssignmentOut


async def allocate_care_teams(client, today: date | None = None) -> list[AllocationStep]:
    scorer = RiskScoringService(client)
    matcher = CarerMatchingService(client, scorer)
    assigner = AssignmentService(client, scorer)

    steps = []
    # Key workers first: a backup is chosen knowing who the key worker is.
    for kind in (AssignmentType.PRIMARY, AssignmentType.SECONDARY):
        plan = await matcher.suggest_assignments(kind=kind)
        items = [
            BulkAssignmentItem(
                resident_id=row.resident_id,
                employee_id=row.employee_id,
                assignment_type=kind,
                start_date=today,
                notes=ALGORITHM_NOTE,
            )
            for row in plan.suggestions
            if row.employee_id is not None
        ]
        result = await assigner.create_many(items)
        steps.append(AllocationStep(kind=kind, plan=plan, result=result))
    return steps


def describe(steps: list[AllocationStep]) -> str:
    """The terminal report the seed prints: who got whom, and why."""
    lines = []
    for step in steps:
        label = "Key workers" if step.kind == AssignmentType.PRIMARY else "Backup carers"
        plan = step.plan
        if not plan.suggestions:
            lines.append(f"  {label}: every resident already has one.")
            continue
        lines.append(
            f"  {label}: {len(plan.suggestions)} place(s), {plan.candidates_considered} staff "
            f"considered, solved in {plan.solve_ms:.1f} ms"
        )
        for row in plan.suggestions:
            who = row.employee_name or "nobody available"
            name = f"{row.first_name} {row.last_name}"
            lines.append(f"    {name:<24} → {who}")
            if (
                row.one_at_a_time_employee_name
                and row.one_at_a_time_employee_id != row.employee_id
            ):
                lines.append(
                    f"      (one at a time would have given {row.one_at_a_time_employee_name})"
                )
        if plan.improvement_over_greedy > 0:
            lines.append(
                f"    Whole-set plan cost {plan.optimal_total_cost:.2f} vs "
                f"{plan.greedy_total_cost:.2f} one at a time."
            )
        for failure in step.result.failed:
            lines.append(f"    ! not saved: {failure.reason}")
    return "\n".join(lines)
