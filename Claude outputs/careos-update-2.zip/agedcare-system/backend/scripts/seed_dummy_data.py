"""Load the demonstration care home into Supabase.

    uv run python -m backend.scripts.seed_dummy_data            # asks first
    uv run python -m backend.scripts.seed_dummy_data --yes      # no prompt
    uv run python -m backend.scripts.seed_dummy_data --reset    # remove it again
    uv run python -m backend.scripts.seed_dummy_data --remove-old-sample --yes
        # also delete the English-named sample rows an older version of this
        # script created (Margaret Thompson, Emily Carter, …) before seeding

What goes in is described in `backend/demo/dataset.py`: 14 residents, 14
staff, six login accounts and about 900 linked records — medications,
charts, incidents, rosters, pay, credentials — all dated relative to today.

Then every resident is given a key worker and a backup carer by the
system's own matching algorithm (`backend/demo/allocate.py`), and the
script prints who went to whom and why.

Safe to run more than once. Every demo row has a fixed id, so a second run
*updates* the same rows (refreshing the dates, which matters: the risk
scores look at the last 30 and 90 days) instead of adding duplicates. Rows
you created yourself are never touched, by seeding or by --reset.

Needs `backend/.env` pointing at your Supabase project, and the schema from
`backend/sql/000_schema.sql` already applied.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
import time

from backend.config.security import hash_password
from backend.db.supabase_client import (
    close_supabase_connection,
    connect_to_supabase,
    get_supabase,
)
from backend.demo.allocate import allocate_care_teams, describe
from backend.demo.dataset import DEMO_PASSWORD, FACILITY, TABLE_ORDER, build

#: PostgREST handles large bodies fine, but a failure then names a smaller
#: batch — easier to find the one bad row.
BATCH = 100


def _rows_for(models) -> list[dict]:
    # mode="json" turns dates, UUIDs and enums into the strings PostgREST
    # expects; nested models (a resident's emergency contact) become JSON.
    return [m.model_dump(mode="json") for m in models]


async def _upsert(client, table: str, rows: list[dict]) -> None:
    for start in range(0, len(rows), BATCH):
        chunk = rows[start : start + BATCH]
        await client.table(table).upsert(chunk, on_conflict="id").execute()


async def seed(client, data) -> None:
    started = time.perf_counter()
    for table in TABLE_ORDER:
        models = data.rows(table)
        if not models:
            continue
        try:
            await _upsert(client, table, _rows_for(models))
        except Exception as exc:  # noqa: BLE001 — name the table, then stop
            print(f"\n  ✗ {table}: {exc}")
            print(
                "\n  Stopped. Nothing after this table was written. The usual cause is a\n"
                "  schema that is older than the models — re-run backend/sql/000_schema.sql\n"
                "  in the Supabase SQL editor (it is safe to run again) and try once more."
            )
            raise SystemExit(1) from exc
        print(f"  ✓ {table:28s} {len(models):4d}")

    # Login accounts. Hashed here rather than stored in the dataset, so the
    # dataset module never holds anything resembling a credential.
    password_hash = hash_password(DEMO_PASSWORD)
    users = [
        {
            "id": str(account.id),
            "email": account.email,
            "password_hash": password_hash,
            "access_role": account.access_role.value,
            "employee_id": str(data.employee_ids[account.employee_key]),
            "full_name": account.full_name,
            "active": True,
        }
        for account in data.accounts
    ]
    try:
        await _upsert(client, "users", users)
        print(f"  ✓ {'users':28s} {len(users):4d}")
    except Exception as exc:  # noqa: BLE001
        # Most likely an account you created yourself already uses one of
        # these email addresses. The rest of the data is still usable.
        print(f"  ! users: {exc}\n    (login accounts skipped; everything else was loaded)")

    # Care teams: filled by the Hungarian allocation, exactly as the Care
    # teams screen would, so the result is what the algorithm chose from
    # the data above rather than a hand-written list.
    print("\nAllocating care teams with the matching algorithm…")
    steps = await allocate_care_teams(client, today=data.today)
    print(describe(steps))

    print(f"\nDone in {time.perf_counter() - started:.1f}s.")


async def reset(client, data) -> None:
    ids = [str(a.id) for a in data.accounts]
    await client.table("users").delete().in_("id", ids).execute()
    print(f"  ✓ {'users':28s} removed")
    # Care-team rows made by the allocation step have ordinary random ids,
    # so they are found by the demo residents they belong to.
    resident_ids = [str(m.id) for m in data.rows("residents")]
    await client.table("resident_assignments").delete().in_("resident_id", resident_ids).execute()
    # Reverse order: children before the rows they point at.
    for table in reversed(TABLE_ORDER):
        ids = [str(m.id) for m in data.rows(table)]
        for start in range(0, len(ids), BATCH):
            await client.table(table).delete().in_("id", ids[start : start + BATCH]).execute()
        print(f"  ✓ {table:28s} removed")


#: What the previous version of this script inserted, with random ids. It is
#: identified by name and by its email domain, never by anything a real
#: record would plausibly share.
OLD_SAMPLE_RESIDENTS = [
    ("Margaret", "Thompson"), ("Harold", "Nguyen"), ("Beryl", "O'Connor"), ("Frank", "Kowalski"),
    ("Doris", "Patel"), ("Walter", "Higgins"), ("Shirley", "Wallace"), ("Raymond", "Singh"),
    ("Audrey", "Fitzgerald"), ("Bruce", "MacKenzie"),
]
OLD_SAMPLE_EMPLOYEE_DOMAIN = "@agedcare.example.com"
OLD_SAMPLE_APPOINTMENT_DOMAIN = "@example.com"


async def remove_old_sample(client) -> None:
    """Delete the old sample residents and staff. Their charts, shifts, pay
    and so on go with them (the schema cascades); complaints that name them
    are removed first, and the old sample enquiries by their email domain."""
    residents = (await client.table("residents").select("id,first_name,last_name").execute()).data
    old_residents = [
        r["id"] for r in residents if (r["first_name"], r["last_name"]) in OLD_SAMPLE_RESIDENTS
    ]
    employees = (await client.table("employees").select("id,email").execute()).data
    old_employees = [
        e["id"] for e in employees if (e.get("email") or "").endswith(OLD_SAMPLE_EMPLOYEE_DOMAIN)
    ]
    if old_residents:
        await client.table("complaints_feedback").delete().in_("resident_id", old_residents).execute()
        await client.table("residents").delete().in_("id", old_residents).execute()
    if old_employees:
        await client.table("complaints_feedback").delete().in_("employee_id", old_employees).execute()
        await client.table("employees").delete().in_("id", old_employees).execute()
    appointments = (await client.table("appointments").select("id,email").execute()).data
    old_appointments = [
        a["id"] for a in appointments if (a.get("email") or "").endswith(OLD_SAMPLE_APPOINTMENT_DOMAIN)
    ]
    if old_appointments:
        await client.table("appointments").delete().in_("id", old_appointments).execute()
    print(
        f"  ✓ old sample removed: {len(old_residents)} residents, {len(old_employees)} staff, "
        f"{len(old_appointments)} enquiries (and everything attached to them)\n"
    )


def _print_logins(data) -> None:
    print("\nLogin accounts (demo only — change or remove before real use):\n")
    width = max(len(a.email) for a in data.accounts)
    for account in data.accounts:
        print(f"  {account.email:{width}s}   {account.access_role.value:12s} {account.full_name}")
    print(f"\n  Password for all of them: {DEMO_PASSWORD}\n")


async def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[1].strip())
    parser.add_argument("--reset", action="store_true", help="remove the demo data")
    parser.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    parser.add_argument(
        "--remove-old-sample",
        action="store_true",
        help="first delete the English-named sample rows made by the older seed script",
    )
    args = parser.parse_args()

    data = build()
    total = sum(len(data.rows(t)) for t in TABLE_ORDER)
    action = "REMOVE" if args.reset else "write"
    print(f"\n{FACILITY} — demo data for {data.today:%d %B %Y}")
    print(f"About to {action} {total} records and {len(data.accounts)} login accounts.")
    print("Your own rows are not touched.\n")

    if not args.yes:
        answer = input("Continue? Only do this on a development database. [y/N] ")
        if answer.strip().lower() not in ("y", "yes"):
            print("Nothing changed.")
            return 0

    await connect_to_supabase()
    try:
        client = get_supabase()
        if args.reset:
            await reset(client, data)
            print("\nDemo data removed.")
        else:
            if args.remove_old_sample:
                await remove_old_sample(client)
            await seed(client, data)
            _print_logins(data)
    finally:
        await close_supabase_connection()
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
