from datetime import datetime, timezone
from enum import StrEnum
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field


class AccessRole(StrEnum):
    """Authorisation role — deliberately separate from `EmployeeRole`.

    `EmployeeRole` describes what someone does for a living (Kitchen Staff,
    Care Coordinator...). `AccessRole` describes what they may see and change
    in this system. Several job titles map onto one access role, and some
    accounts (a family member) have no employee record at all, so collapsing
    the two would force awkward compromises in both directions.
    """

    ADMIN = "Admin"
    MANAGER = "Manager"
    NURSE = "Nurse"
    CARE_WORKER = "Care Worker"
    FAMILY = "Family"


#: Roles that belong to staff working inside the facility. Used as the default
#: audience for anything clinical.
STAFF_ROLES = frozenset(
    {AccessRole.ADMIN, AccessRole.MANAGER, AccessRole.NURSE, AccessRole.CARE_WORKER}
)

#: Roles allowed to change organisation-wide configuration and other accounts.
PRIVILEGED_ROLES = frozenset({AccessRole.ADMIN, AccessRole.MANAGER})


class User(BaseModel):
    """A login account. `password_hash` never leaves this layer — the API
    speaks in `UserOut`, which has no such field."""

    id: UUID | None = None
    email: EmailStr
    password_hash: str
    access_role: AccessRole
    employee_id: UUID | None = None
    full_name: str | None = None
    active: bool = True
    last_login_at: datetime | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
