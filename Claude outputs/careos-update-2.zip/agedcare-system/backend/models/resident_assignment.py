from datetime import date, datetime, timezone
from enum import StrEnum
from uuid import UUID

from pydantic import BaseModel, Field


class AssignmentType(StrEnum):
    """Who this staff member is to this resident.

    The key-worker model used in Australian residential aged care: one named
    primary carer who knows the resident well and is the family's point of
    contact, one or more secondaries who cover routinely, and relief staff
    who step in for leave and sickness.
    """

    PRIMARY = "Primary"
    SECONDARY = "Secondary"
    RELIEF = "Relief"


class ResidentAssignment(BaseModel):
    """A standing care relationship between one employee and one resident.

    This is the table the system was missing. Before it existed,
    `employee_care_load.py` had to infer "who cares for whom" from which
    staff member last wrote a chart entry — a proxy that only worked when
    those optional author columns happened to be filled in.

    Assignments are kept rather than deleted when they end: `end_date` plus
    `active` closes one off, so the history of who was responsible for a
    resident on any past date stays answerable. That matters in a regulated
    setting, where "who was their carer in March" is a question that gets
    asked after something goes wrong.
    """

    id: UUID | None = None
    resident_id: UUID | None = None
    employee_id: UUID | None = None
    assignment_type: AssignmentType = AssignmentType.SECONDARY
    start_date: date | None = None
    end_date: date | None = None
    active: bool = True
    notes: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
