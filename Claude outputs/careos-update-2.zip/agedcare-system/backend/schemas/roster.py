from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class RosterOptimiseRequest(BaseModel):
    """Which shifts to fill. Omit `shift_ids` to optimise every unassigned
    shift in the window instead."""

    shift_ids: list[UUID] | None = None
    from_date: datetime | None = None
    to_date: datetime | None = None
    #: Cap on candidates considered, to keep an accidental request against a
    #: very large employee table from building a huge matrix.
    max_candidates: int = Field(default=200, ge=1, le=1000)


class RosterCandidateOut(BaseModel):
    """Someone who could take the shift, with why they rank where they do."""

    employee_id: UUID
    employee_name: str
    employee_role: str | None = None
    cost: float
    reason: str


class RosterAssignmentOut(BaseModel):
    shift_id: UUID
    shift_start: datetime
    shift_end: datetime
    shift_role: str | None = None
    employee_id: UUID | None = None
    employee_name: str | None = None
    employee_role: str | None = None
    cost: float | None = None
    #: Plain-language justification for the choice, in the same style as
    #: the carer suggestions: hours already rostered, care load, role fit.
    reason: str | None = None
    #: Present when no employee could be assigned — every candidate either
    #: had a clashing shift or the wrong role.
    unassigned_reason: str | None = None
    #: Everyone who could take this shift without a clash, cheapest first,
    #: so the plan can be edited on screen without another request.
    alternatives: list[RosterCandidateOut] = []


class RosterComparisonOut(BaseModel):
    """The headline result: what the optimal assignment costs versus what a
    greedy pass costs on the identical cost matrix.

    Comparing the raw assignment sums alone would be misleading, because a
    method that simply fills fewer shifts scores a lower sum. An unfilled
    shift is the worst outcome in a care setting — it means the floor is
    short-staffed — so it carries a fixed penalty, and the totals that
    matter are the ones including it.
    """

    #: Sum of the chosen cells only.
    optimal_assignment_cost: float
    greedy_assignment_cost: float
    #: What one unfilled shift costs in the comparison.
    unfilled_shift_penalty: float
    unfilled_optimal: int
    unfilled_greedy: int
    #: Assignment cost plus penalties. These are what the saving is based on.
    optimal_total_cost: float
    greedy_total_cost: float
    absolute_saving: float
    percentage_saving: float
    optimal_assigned: int
    greedy_assigned: int
    differing_shifts: int


class RosterOptimiseOut(BaseModel):
    shifts_considered: int
    candidates_considered: int
    matrix_rows: int
    matrix_cols: int
    assignments: list[RosterAssignmentOut]
    greedy_assignments: list[RosterAssignmentOut]
    comparison: RosterComparisonOut
    #: Wall-clock milliseconds spent inside the algorithm itself, excluding
    #: the database reads that built the matrix.
    solve_ms: float
    cost_model: dict[str, float]


# --- the week view and filling open shifts ---------------------------------


class RosterShiftOut(BaseModel):
    """A shift as the roster screen shows it: with the person's name
    resolved, and open shifts marked as such rather than left as a blank
    employee id the browser would have to interpret."""

    id: UUID
    employee_id: UUID | None = None
    employee_name: str | None = None
    employee_role: str | None = None
    shift_start: datetime
    shift_end: datetime
    role: str | None = None
    location: str | None = None
    status: str
    notes: str | None = None
    is_open: bool


class OpenShiftCreate(BaseModel):
    """Demand without a person yet: 'we need a second nurse on Thursday
    night'. Filled later, by hand or by the optimiser."""

    shift_start: datetime
    shift_end: datetime
    role: str | None = None
    location: str | None = None
    notes: str | None = None


class ShiftAssignmentItem(BaseModel):
    shift_id: UUID
    employee_id: UUID


class ShiftAssignmentIn(BaseModel):
    assignments: list[ShiftAssignmentItem]


class ShiftAssignmentFailure(BaseModel):
    shift_id: UUID
    employee_id: UUID
    reason: str


class ShiftAssignmentOut(BaseModel):
    """Not all-or-nothing, for the same reason as confirming carers: a shift
    someone else filled in the meantime should not cost the user the rest of
    the roster they just approved."""

    assigned: list[RosterShiftOut]
    failed: list[ShiftAssignmentFailure]
