from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel

from backend.models.employee import EmployeeRole
from backend.models.resident_assignment import AssignmentType


class AssignmentCreate(BaseModel):
    employee_id: UUID
    assignment_type: AssignmentType = AssignmentType.SECONDARY
    start_date: date | None = None
    end_date: date | None = None
    active: bool = True
    notes: str | None = None


class AssignmentUpdate(BaseModel):
    employee_id: UUID | None = None
    assignment_type: AssignmentType | None = None
    start_date: date | None = None
    end_date: date | None = None
    active: bool | None = None
    notes: str | None = None


class AssignmentOut(BaseModel):
    id: UUID
    resident_id: UUID
    employee_id: UUID | None = None
    assignment_type: AssignmentType
    start_date: date | None = None
    end_date: date | None = None
    active: bool
    notes: str | None = None
    created_at: datetime
    updated_at: datetime


class BulkAssignmentItem(BaseModel):
    """One confirmed line of a proposed allocation.

    Carries the resident explicitly, unlike `AssignmentCreate`, because this
    is not scoped to a single resident's URL — the whole point is to confirm
    several residents' carers in one action.
    """

    resident_id: UUID
    employee_id: UUID
    assignment_type: AssignmentType = AssignmentType.PRIMARY
    start_date: date | None = None
    notes: str | None = None


class BulkAssignmentIn(BaseModel):
    assignments: list[BulkAssignmentItem]


class BulkAssignmentFailure(BaseModel):
    resident_id: UUID
    employee_id: UUID
    #: The same message the single-assignment endpoint would have returned,
    #: so the user reads a real explanation rather than "3 failed".
    reason: str


class BulkAssignmentOut(BaseModel):
    """Deliberately not all-or-nothing.

    Between proposing a plan and confirming it, someone else may have named a
    primary carer for one of these residents. Rejecting the whole batch over
    that would throw away nine good assignments to punish one stale row, and
    the user would have to redo work they already approved. Each line is
    applied on its own and the failures are named.
    """

    created: list[AssignmentOut]
    failed: list[BulkAssignmentFailure]
    #: Hand-overs only: the assignments that were closed because someone
    #: else took them over.
    ended: list[UUID] = []


class HandOverItem(BaseModel):
    """One resident moving from the departing carer to someone else. The
    place (key worker or backup) is whatever the departing carer held."""

    resident_id: UUID
    employee_id: UUID


class HandOverIn(BaseModel):
    from_employee_id: UUID
    assignments: list[HandOverItem]


# --- enriched views ------------------------------------------------------
# The raw assignment rows carry only ids. These add the names, roles and
# live shift state a person actually needs to read the screen, resolved on
# the server so the browser does not have to fan out a request per row.


class CareTeamMemberOut(BaseModel):
    assignment_id: UUID
    employee_id: UUID
    first_name: str
    last_name: str
    role: EmployeeRole | None = None
    assignment_type: AssignmentType
    start_date: date | None = None
    end_date: date | None = None
    active: bool
    #: True when this carer is inside a rostered shift right now.
    on_shift_now: bool = False
    #: Their next rostered shift, if any is scheduled.
    next_shift_start: datetime | None = None
    next_shift_end: datetime | None = None


class CareTeamOut(BaseModel):
    resident_id: UUID
    resident_name: str
    members: list[CareTeamMemberOut]
    #: Denormalised for the UI banner: a resident with no primary carer is
    #: the thing a manager needs to see immediately.
    has_primary: bool
    on_shift_count: int


class CaseloadResidentOut(BaseModel):
    assignment_id: UUID
    resident_id: UUID
    first_name: str
    last_name: str
    room_number: str | None = None
    assignment_type: AssignmentType
    start_date: date | None = None
    active: bool
    risk_score: int | None = None
    risk_band: str | None = None


class CaseloadOut(BaseModel):
    employee_id: UUID
    employee_name: str
    residents: list[CaseloadResidentOut]
    primary_count: int
    #: Sum of the risk scores of the residents they are responsible for —
    #: the same quantity the roster optimiser calls "care load", but here
    #: derived from real assignments rather than inferred.
    total_risk_load: int
    hours_this_week: float


class UnassignedResidentOut(BaseModel):
    resident_id: UUID
    first_name: str
    last_name: str
    room_number: str | None = None
    risk_score: int | None = None
    risk_band: str | None = None
    #: Distinguishes "nobody at all" from "covered, but no named key worker".
    has_any_carer: bool


class TeamResidentOut(BaseModel):
    """One resident on a carer's list, for the care-teams board."""

    assignment_id: UUID
    resident_id: UUID
    first_name: str
    last_name: str
    room_number: str | None = None
    assignment_type: AssignmentType
    start_date: date | None = None
    risk_score: int | None = None
    risk_band: str | None = None
    notes: str | None = None


class CarerTeamOut(BaseModel):
    """Everyone one carer looks after — one card on the care-teams board."""

    employee_id: UUID
    first_name: str
    last_name: str
    role: EmployeeRole | None = None
    key_worker_for: int
    backup_for: int
    #: Sum of the risk scores of every resident they hold, the quantity the
    #: allocation tries to keep even.
    risk_load: int
    residents: list[TeamResidentOut]


class UnloadedEmployeeOut(BaseModel):
    employee_id: UUID
    first_name: str
    last_name: str
    role: EmployeeRole | None = None


class CoverageReportOut(BaseModel):
    total_residents: int
    total_active_staff: int
    residents_with_primary: int
    residents_without_primary: int
    residents_with_no_carer: int
    residents_with_backup: int = 0
    average_caseload: float
    #: Highest-risk first — an unassigned Critical resident is the single
    #: most actionable row on this screen.
    unassigned: list[UnassignedResidentOut]
    #: Residents who have a key worker but nobody to cover for them.
    without_backup: list[UnassignedResidentOut] = []
    #: One entry per carer holding anyone, heaviest load first.
    teams: list[CarerTeamOut] = []
    staff_without_caseload: list[UnloadedEmployeeOut]
