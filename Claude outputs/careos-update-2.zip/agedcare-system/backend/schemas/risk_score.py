from uuid import UUID

from pydantic import BaseModel


class RiskScoreBreakdownItem(BaseModel):
    value: str
    #: Contribution to the final score: 100 * weight * normalised, rounded.
    #: The five items sum to the score exactly — nothing is clipped away.
    points: int
    #: The AHP-derived importance of this criterion, in [0, 1]. Constant
    #: across residents; surfaced so the UI can explain *why* a signal
    #: contributed what it did.
    weight: float = 0.0
    #: How bad this signal is for this resident, in [0, 1]. Varies per
    #: resident; this is the half of the product that is about them.
    normalised: float = 0.0


class RiskScoreOut(BaseModel):
    resident_id: UUID
    first_name: str
    last_name: str
    score: int
    band: str
    breakdown: dict[str, RiskScoreBreakdownItem]


class AHPCriterionOut(BaseModel):
    criterion: str
    weight: float
    percentage: float


class RiskWeightModelOut(BaseModel):
    """The derivation itself, exposed so the weighting can be inspected and
    defended rather than taken on trust."""

    method: str
    criteria: list[AHPCriterionOut]
    comparison_matrix: list[list[float]]
    lambda_max: float
    consistency_index: float
    consistency_ratio: float
    consistency_threshold: float
    is_consistent: bool
    verdict: str
