from uuid import UUID

from pydantic import BaseModel

from backend.models.employee import EmployeeRole
from backend.models.resident_assignment import AssignmentType


class CarerCandidateOut(BaseModel):
    """One option while assigning a single resident, with the reasoning."""

    employee_id: UUID
    first_name: str
    last_name: str
    role: EmployeeRole | None = None
    current_caseload: int
    current_risk_load: int
    cost: float
    reason: str


class CarerSuggestionOut(BaseModel):
    """One row of a proposed allocation: this resident, that carer."""

    resident_id: UUID
    first_name: str
    last_name: str
    room_number: str | None = None
    risk_score: int | None = None
    risk_band: str | None = None
    #: The place being filled: key worker (Primary) or backup (Secondary).
    assignment_type: AssignmentType = AssignmentType.PRIMARY
    #: During a hand-over, the assignment this row takes over. Confirming
    #: ends that one and starts the new one.
    replaces_assignment_id: UUID | None = None
    employee_id: UUID | None = None
    employee_name: str | None = None
    employee_role: EmployeeRole | None = None
    cost: float | None = None
    reason: str
    #: Everyone else eligible for this resident, best first, including the
    #: one chosen above. Returned with the plan rather than fetched when a
    #: row is opened: the user is about to review every line, and a request
    #: per dropdown would make editing the plan slower than ignoring it.
    #: Changing a row is a local edit, not a re-solve — the allocation was
    #: optimal for the whole set, so a swap here is the user overriding it,
    #: which is the point of letting them confirm rather than apply.
    alternatives: list[CarerCandidateOut] = []
    #: Who this resident would have got had each gap been filled in turn,
    #: most urgent first. Shown beside the suggestion wherever the two
    #: differ, because that difference is the reason the whole list is
    #: solved at once.
    one_at_a_time_employee_id: UUID | None = None
    one_at_a_time_employee_name: str | None = None


class SuggestAssignmentsOut(BaseModel):
    """A whole proposed allocation, with the comparison that justifies it.

    The two totals are not the sums of the chosen cells alone. A method that
    matches fewer residents scores a lower sum of cells while producing the
    worse outcome, so leaving a resident without a key worker carries a fixed
    penalty and both totals include it. Comparing the bare sums would let the
    worse plan look cheaper — the same trap the roster optimiser reports
    around.
    """

    #: Which question was asked — see CarerMatchingService.suggest_assignments.
    kind: AssignmentType = AssignmentType.PRIMARY
    hand_over_from_employee_id: UUID | None = None
    hand_over_from_name: str | None = None
    residents_needing_a_carer: int
    candidates_considered: int
    #: How many new residents one carer may take in this plan. 1 unless
    #: there are more residents than carers — see "slots".
    max_new_per_carer: int = 1
    suggestions: list[CarerSuggestionOut]
    #: What taking each gap in turn would have cost, for contrast. Shown so
    #: the allocation can be judged rather than trusted.
    greedy_total_cost: float
    optimal_total_cost: float
    improvement_over_greedy: float
    #: Residents each method could not match at all.
    unmatched_optimal: int = 0
    unmatched_greedy: int = 0
    #: What one unmatched resident costs in the comparison above.
    unmatched_penalty: float = 0.0
    solve_ms: float
