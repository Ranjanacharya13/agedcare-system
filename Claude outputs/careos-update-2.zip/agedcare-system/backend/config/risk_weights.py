"""Where the resident risk weights come from.

Previously these were five hand-picked point values with a comment admitting
they were "a starting guess". They are now derived by the Analytic Hierarchy
Process from the pairwise judgements below, which is a defensible method: the
judgements are the thing a domain expert can actually give you, and the
consistency ratio proves they do not contradict each other.

To re-elicit the weights, change only `JUDGEMENTS` — sit with a senior nurse
or care coordinator, ask each pairwise question, record the answer on the 1-9
scale, and run:

    uv run python -m backend.scripts.show_risk_weights

If the consistency ratio comes out at 0.10 or above, the answers contradict
each other somewhere and should be revisited rather than used.
"""

from backend.algorithms.ahp import derive_weights

#: The five signals that feed a resident's risk score. Order is cosmetic —
#: it only affects how the matrix is laid out — but keeping it descending by
#: importance makes the judgement table below readable.
RISK_CRITERIA = [
    "fall_risk",
    "recent_incidents",
    "assistance_level",
    "cognitive_status",
    "recent_behaviour",
]

#: Pairwise judgements on Saaty's 1-9 scale. Read `(a, b): n` as
#: "a is n times more important than b when judging risk of harm".
#:
#: Only the upper triangle is given; reciprocals are filled in automatically.
#: The rationale for each is recorded so the numbers can be argued with
#: rather than merely inherited:
JUDGEMENTS: dict[tuple[str, str], float] = {
    # Falls are the leading cause of injury and hospital transfer in
    # residential aged care, so fall risk leads — but a resident with a
    # recent incident history is in practice just as urgent, hence equal.
    ("fall_risk", "recent_incidents"): 1,
    ("fall_risk", "assistance_level"): 2,
    ("fall_risk", "cognitive_status"): 3,
    ("fall_risk", "recent_behaviour"): 4,
    # Incidents that already happened outrank standing characteristics,
    # because they are evidence rather than prediction.
    ("recent_incidents", "assistance_level"): 1,
    ("recent_incidents", "cognitive_status"): 2,
    ("recent_incidents", "recent_behaviour"): 3,
    # Needing two staff to transfer is a concrete daily risk; cognitive
    # status matters but is partly captured by the other signals.
    ("assistance_level", "cognitive_status"): 1,
    ("assistance_level", "recent_behaviour"): 2,
    # Behaviour events are the weakest signal on their own — they are
    # frequently recorded, vary by observer, and often reflect unmet need
    # rather than risk of harm.
    ("cognitive_status", "recent_behaviour"): 2,
}

#: Computed once at import. AHP on a 5x5 matrix is microseconds, but the
#: weights are a constant of the system, not a per-request calculation.
RISK_WEIGHT_MODEL = derive_weights(RISK_CRITERIA, JUDGEMENTS)

#: criterion -> weight in [0, 1]; the five sum to 1.
RISK_WEIGHTS = RISK_WEIGHT_MODEL.weights

# --- saturation points for the count-based criteria ----------------------
#
# Three of the five criteria are categorical and map straight onto [0, 1].
# The other two are counts, which need a ceiling: a resident with twelve
# incidents is not four times worse than one with three, they are both
# "as bad as this signal can indicate". These are the points at which each
# count-based signal reaches its maximum.

#: Severity-weighted incident total (Low 1, Medium 2, High 3, Critical 5)
#: at which the incident signal saturates. 6 means roughly two serious
#: incidents, or one critical plus one minor, in the lookback window.
INCIDENT_SATURATION = 6.0

#: Behaviour events in the lookback window at which that signal saturates.
BEHAVIOUR_SATURATION = 4.0

INCIDENT_LOOKBACK_DAYS = 90
BEHAVIOUR_LOOKBACK_DAYS = 30
