import base64
import hashlib
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import uuid4

import bcrypt
import jwt

from backend.config.settings import get_settings

ALGORITHM = "HS256"

#: bcrypt work factor. 12 is ~250ms on current hardware — slow enough to make
#: offline cracking expensive, fast enough that a nurse signing in does not
#: notice. Raise as hardware improves; existing hashes carry their own cost
#: parameter, so old passwords keep verifying.
BCRYPT_ROUNDS = 12


class TokenError(Exception):
    """Raised when a token is absent, malformed, expired or signed with the
    wrong key. The API layer turns this into a 401 — callers should not need
    to know which of those it was, and telling them helps only an attacker."""


def _prepare(password: str) -> bytes:
    """bcrypt silently ignores anything past the 72th byte, and the Python
    binding raises outright. Pre-hashing with SHA-256 gives a fixed 44-byte
    input, so a long passphrase keeps all of its entropy instead of being cut
    off — and a user cannot trigger a 500 by choosing a good password.

    Base64 rather than raw digest bytes because a raw digest can contain a
    NUL, which bcrypt treats as a string terminator.
    """
    digest = hashlib.sha256(password.encode("utf-8")).digest()
    return base64.b64encode(digest)


def hash_password(password: str) -> str:
    return bcrypt.hashpw(_prepare(password), bcrypt.gensalt(rounds=BCRYPT_ROUNDS)).decode()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        return bcrypt.checkpw(_prepare(plain_password), hashed_password.encode("utf-8"))
    except (ValueError, TypeError):
        # A malformed stored hash must read as "wrong password", never as an
        # exception that leaks the difference to the caller.
        return False


def create_access_token(
    subject: str,
    *,
    role: str | None = None,
    email: str | None = None,
    expires_delta: timedelta | None = None,
) -> str:
    """Mint a signed access token.

    The role travels inside the token so that authorisation costs no database
    round-trip on every request. The trade-off is that a role change does not
    take effect until the current token expires; with a 60-minute default that
    is an acceptable window, and `active=False` is still checked against the
    database on each request so a revoked account is locked out immediately.
    """
    settings = get_settings()
    now = datetime.now(timezone.utc)
    expire = now + (expires_delta or timedelta(minutes=settings.access_token_expire_minutes))
    payload: dict[str, Any] = {
        "sub": subject,
        "exp": expire,
        "iat": now,
        "jti": str(uuid4()),
    }
    if role is not None:
        payload["role"] = role
    if email is not None:
        payload["email"] = email
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict[str, Any]:
    settings = get_settings()
    try:
        return jwt.decode(
            token,
            settings.secret_key,
            algorithms=[ALGORITHM],
            options={"require": ["exp", "sub"]},
        )
    except jwt.PyJWTError as exc:
        raise TokenError(str(exc)) from exc
