"""Who may read and who may write, per group of resources.

Kept as one table in one file on purpose. The alternative — a decorator on
each of the ~150 generated routes — makes it impossible to answer "what can a
care worker actually see?" without reading the whole API. Here it is one
screenful, and `test_permissions.py` asserts every mounted router names a
group that exists.

Read covers GET/HEAD/OPTIONS; write covers POST/PUT/PATCH/DELETE. Granularity
finer than that (a nurse may PATCH but not DELETE) is expressed by giving the
group its own entry rather than by inventing a third verb class.
"""

from backend.models.user import AccessRole

ADMIN = AccessRole.ADMIN
MANAGER = AccessRole.MANAGER
NURSE = AccessRole.NURSE
CARE_WORKER = AccessRole.CARE_WORKER
FAMILY = AccessRole.FAMILY

ALL_STAFF = frozenset({ADMIN, MANAGER, NURSE, CARE_WORKER})
CLINICAL_STAFF = frozenset({ADMIN, MANAGER, NURSE})
LEADERSHIP = frozenset({ADMIN, MANAGER})
ADMIN_ONLY = frozenset({ADMIN})

READ = "read"
WRITE = "write"

_WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


def action_for_method(method: str) -> str:
    return WRITE if method.upper() in _WRITE_METHODS else READ


#: resource group -> {READ: roles, WRITE: roles}
PERMISSIONS: dict[str, dict[str, frozenset[AccessRole]]] = {
    # --- residents -----------------------------------------------------
    # Everyone on the floor needs to know who they are caring for; only
    # leadership and nurses admit, discharge or amend the record itself.
    "residents": {READ: ALL_STAFF, WRITE: CLINICAL_STAFF},
    # Day-to-day charting: behaviour, bowel, sleep, assistance, incidents.
    # Care workers write these — they are the ones at the bedside.
    "resident_charts": {READ: ALL_STAFF, WRITE: ALL_STAFF},
    # Clinical judgements: medications, medical history, fall-risk
    # assessments, medical inventory. Care workers read but do not author.
    "resident_clinical": {READ: ALL_STAFF, WRITE: CLINICAL_STAFF},
    # Who cares for whom. Every staff member needs to see the care team for
    # a resident they are working with; deciding it is a clinical staffing
    # call, so nurses and leadership write it but care workers do not.
    "assignments": {READ: ALL_STAFF, WRITE: CLINICAL_STAFF},
    # --- employees -----------------------------------------------------
    "employees": {READ: ALL_STAFF, WRITE: LEADERSHIP},
    # Rosters and timesheets: visible to all staff so people can see who is
    # on; only leadership changes them.
    "employee_roster": {READ: ALL_STAFF, WRITE: LEADERSHIP},
    # HR: contracts, payroll, performance, leave, supervision, registrations,
    # qualifications. A nurse has no business reading a colleague's pay.
    "employee_hr": {READ: LEADERSHIP, WRITE: LEADERSHIP},
    # --- other ---------------------------------------------------------
    "complaints": {READ: LEADERSHIP, WRITE: LEADERSHIP},
    "appointments": {READ: ALL_STAFF, WRITE: LEADERSHIP},
    # Computed endpoints. Reading a risk score means reading clinical signal,
    # so it follows the clinical audience. Nothing here is writable: these
    # resources have no table behind them.
    "analytics": {READ: ALL_STAFF, WRITE: frozenset()},
    # Running the roster optimiser. It stores nothing, but it is a POST
    # (the request carries a list of shifts), and deciding how to staff a
    # week is a leadership action rather than something any carer triggers.
    # Kept separate from "analytics" so that group can stay strictly
    # read-only — a group whose write audience is empty must never acquire
    # one just to let an endpoint through.
    "roster_planning": {READ: ALL_STAFF, WRITE: LEADERSHIP},
    # --- system --------------------------------------------------------
    "users": {READ: ADMIN_ONLY, WRITE: ADMIN_ONLY},
    # Read-only by construction; WRITE is empty so even an admin cannot
    # rewrite history through the API.
    "audit": {READ: LEADERSHIP, WRITE: frozenset()},
}


def roles_for(group: str, action: str) -> frozenset[AccessRole]:
    try:
        return PERMISSIONS[group][action]
    except KeyError as exc:  # pragma: no cover - guarded by test_permissions
        raise KeyError(f"Unknown permission group/action: {group}/{action}") from exc


def can(role: AccessRole, group: str, method: str) -> bool:
    return role in roles_for(group, action_for_method(method))
