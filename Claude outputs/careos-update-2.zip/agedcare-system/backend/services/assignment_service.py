"""Who cares for whom, answered from all three useful directions.

The raw `resident_assignments` rows are just pairs of ids. This service
joins them to the people involved, to live shift state, and to resident risk
scores, so a screen can be rendered from one request instead of the browser
fanning out a lookup per row.

All three entry points follow the same shape: fetch the independent pieces
concurrently, index them by id, then walk the assignments once. That keeps
the work O(n) in assignments rather than O(n) database round-trips.
"""

import asyncio
from datetime import date, datetime, timedelta, timezone

from fastapi import HTTPException, status
from supabase import AsyncClient

from backend.models.employee_shift import EmployeeShift
from backend.models.resident_assignment import AssignmentType, ResidentAssignment
from backend.repositories.base import SupabaseRepository
from backend.repositories.employee_repository import EmployeeRepository
from backend.repositories.resident_assignment_repository import (
    ResidentAssignmentRepository,
)
from backend.repositories.resident_repository import ResidentRepository
from backend.schemas.resident_assignment import (
    AssignmentCreate,
    AssignmentOut,
    AssignmentUpdate,
    BulkAssignmentFailure,
    BulkAssignmentItem,
    BulkAssignmentOut,
    CareTeamMemberOut,
    CareTeamOut,
    CaseloadOut,
    CaseloadResidentOut,
    CarerTeamOut,
    CoverageReportOut,
    HandOverItem,
    TeamResidentOut,
    UnassignedResidentOut,
    UnloadedEmployeeOut,
)
from backend.services.risk_scoring import RiskScoringService


#: Primary outranks secondary outranks relief — used to tell a promotion
#: from a duplicate.
_RANK = {AssignmentType.PRIMARY: 0, AssignmentType.SECONDARY: 1, AssignmentType.RELIEF: 2}


class AssignmentService:
    def __init__(self, client: AsyncClient, risk_scoring_service: RiskScoringService):
        self._repository = ResidentAssignmentRepository(client)
        self._resident_repository = ResidentRepository(client)
        self._employee_repository = EmployeeRepository(client)
        self._shift_repository = SupabaseRepository(
            client,
            "employee_shifts",
            EmployeeShift,
            order_column="shift_start",
            parent_field="employee_id",
        )
        self._risk_scoring_service = risk_scoring_service

    # --- CRUD ------------------------------------------------------------

    async def create_assignment(
        self, resident_id: str, data: AssignmentCreate
    ) -> ResidentAssignment:
        resident, employee = await asyncio.gather(
            self._resident_repository.get_by_id(resident_id),
            self._employee_repository.get_by_id(str(data.employee_id)),
        )
        if resident is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Resident not found")
        if employee is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Employee not found")

        existing = await self._repository.list_for_resident(resident_id, active_only=True)
        mine = next((a for a in existing if str(a.employee_id) == str(data.employee_id)), None)
        name = f"{employee.first_name} {employee.last_name}"

        # One primary carer, by definition — the point of a key worker is
        # that there is exactly one name to call.
        if data.assignment_type == AssignmentType.PRIMARY:
            current_primary = next(
                (a for a in existing if a.assignment_type == AssignmentType.PRIMARY), None
            )
            if current_primary is not None and current_primary is not mine:
                raise HTTPException(
                    status.HTTP_409_CONFLICT,
                    "This resident already has a primary carer. Change the existing one to "
                    "Secondary first, or end that assignment.",
                )

        if mine is not None:
            # Already on the team in a lesser role: this is a promotion — a
            # backup stepping up to key worker, relief becoming a regular
            # backup. Changing the existing row keeps one row per person,
            # so no caseload figure counts them twice.
            if _RANK[data.assignment_type] < _RANK[mine.assignment_type]:
                note = f"Moved from {mine.assignment_type.value.lower()} to {data.assignment_type.value.lower()}."
                updated = await self._repository.update(
                    str(mine.id),
                    {
                        "assignment_type": data.assignment_type.value,
                        "notes": " ".join(filter(None, [data.notes or mine.notes, note])),
                        "updated_at": datetime.now(timezone.utc).isoformat(),
                    },
                )
                return updated
            # The same person twice on one resident is a data-entry slip,
            # not a meaningful state, and it would double-count them in
            # every caseload figure downstream.
            raise HTTPException(
                status.HTTP_409_CONFLICT,
                f"{name} is already assigned to this resident",
            )

        assignment = ResidentAssignment(
            resident_id=resident.id, **data.model_dump()
        )
        return await self._repository.create(assignment)

    async def create_many(self, items: list[BulkAssignmentItem]) -> BulkAssignmentOut:
        """Confirm several assignments at once, one at a time.

        Each line goes through `create_assignment`, so the one-primary rule,
        the no-duplicate rule, the existence checks and the audit trail all
        apply exactly as they do to a single assignment — there is no faster
        path that skips the rules, because the rules are the reason the table
        is worth anything.

        Sequential rather than gathered on purpose. Two lines in the same
        batch can name the same resident, and running them concurrently would
        let both read "no primary yet" and both succeed, which is precisely
        the state the one-primary rule exists to prevent. A batch is at most
        a few dozen rows; correctness is worth the round-trips.
        """
        created: list[AssignmentOut] = []
        failed: list[BulkAssignmentFailure] = []

        for item in items:
            data = AssignmentCreate(
                employee_id=item.employee_id,
                assignment_type=item.assignment_type,
                start_date=item.start_date or date.today(),
                notes=item.notes,
            )
            try:
                assignment = await self.create_assignment(str(item.resident_id), data)
                # Converted here rather than left to the response model,
                # because this method returns the schema itself.
                created.append(
                    AssignmentOut.model_validate(assignment, from_attributes=True)
                )
            except HTTPException as rejection:
                # The rejection message is written for a person — reuse it
                # rather than inventing a second, vaguer vocabulary here.
                failed.append(
                    BulkAssignmentFailure(
                        resident_id=item.resident_id,
                        employee_id=item.employee_id,
                        reason=str(rejection.detail),
                    )
                )

        return BulkAssignmentOut(created=created, failed=failed)

    async def hand_over(
        self, from_employee_id: str, items: list[HandOverItem]
    ) -> BulkAssignmentOut:
        """Move residents from one carer to others, as a reviewed hand-over.

        For each line: close the departing carer's assignment (kept, with an
        end date, so the history still says who was responsible last month),
        then start the new carer in the same place — key worker or backup.

        Closed first, because the one-primary rule would otherwise reject the
        new key worker. And if the new assignment is rejected anyway, the old
        one is reopened: a resident must never lose the carer they had
        because the replacement did not go through.
        """
        leaver = await self._employee_repository.get_by_id(from_employee_id)
        if leaver is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Employee not found")
        leaver_name = f"{leaver.first_name} {leaver.last_name}"

        held = await self._repository.list_for_employee(from_employee_id, active_only=True)
        by_resident = {str(a.resident_id): a for a in held}
        today = date.today()

        created: list[AssignmentOut] = []
        failed: list[BulkAssignmentFailure] = []
        ended = []
        for item in items:
            old = by_resident.get(str(item.resident_id))
            if old is None:
                failed.append(
                    BulkAssignmentFailure(
                        resident_id=item.resident_id,
                        employee_id=item.employee_id,
                        reason=f"{leaver_name} no longer holds this resident",
                    )
                )
                continue

            await self._repository.update(
                str(old.id),
                {
                    "end_date": today.isoformat(),
                    "active": False,
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                },
            )
            try:
                assignment = await self.create_assignment(
                    str(item.resident_id),
                    AssignmentCreate(
                        employee_id=item.employee_id,
                        assignment_type=old.assignment_type,
                        start_date=today,
                        notes=f"Took over from {leaver_name}.",
                    ),
                )
            except HTTPException as rejection:
                await self._repository.update(
                    str(old.id),
                    {
                        "end_date": None,
                        "active": True,
                        "updated_at": datetime.now(timezone.utc).isoformat(),
                    },
                )
                failed.append(
                    BulkAssignmentFailure(
                        resident_id=item.resident_id,
                        employee_id=item.employee_id,
                        reason=str(rejection.detail),
                    )
                )
                continue
            created.append(AssignmentOut.model_validate(assignment, from_attributes=True))
            ended.append(old.id)

        return BulkAssignmentOut(created=created, failed=failed, ended=ended)

    async def list_for_resident(self, resident_id: str) -> list[ResidentAssignment]:
        if await self._resident_repository.get_by_id(resident_id) is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Resident not found")
        return await self._repository.list_for_resident(resident_id)

    async def update_assignment(
        self, resident_id: str, assignment_id: str, data: AssignmentUpdate
    ) -> ResidentAssignment:
        existing = await self._repository.get_by_id(assignment_id)
        if existing is None or str(existing.resident_id) != resident_id:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Assignment not found")

        updates = data.model_dump(mode="json", exclude_unset=True)
        updates["updated_at"] = datetime.now(timezone.utc).isoformat()

        # Ending an assignment should close it, not leave it counted as live.
        if updates.get("end_date") and "active" not in updates:
            updates["active"] = False

        updated = await self._repository.update(assignment_id, updates)
        if updated is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Assignment not found")
        return updated

    async def delete_assignment(self, resident_id: str, assignment_id: str) -> None:
        existing = await self._repository.get_by_id(assignment_id)
        if existing is None or str(existing.resident_id) != resident_id:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Assignment not found")
        await self._repository.delete(assignment_id)

    # --- resident -> care team -------------------------------------------

    async def get_care_team(self, resident_id: str) -> CareTeamOut:
        resident = await self._resident_repository.get_by_id(resident_id)
        if resident is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Resident not found")

        assignments = await self._repository.list_for_resident(resident_id)
        if not assignments:
            return CareTeamOut(
                resident_id=resident.id,
                resident_name=f"{resident.first_name} {resident.last_name}",
                members=[],
                has_primary=False,
                on_shift_count=0,
            )

        employee_ids = [str(a.employee_id) for a in assignments if a.employee_id]
        employees, shift_lists = await asyncio.gather(
            asyncio.gather(*(self._employee_repository.get_by_id(eid) for eid in employee_ids)),
            asyncio.gather(
                *(self._shift_repository.list_for_parent(eid, 0, 100) for eid in employee_ids)
            ),
        )
        by_id = {str(e.id): e for e in employees if e is not None}
        shifts_by_id = dict(zip(employee_ids, shift_lists))

        now = datetime.now(timezone.utc)
        members: list[CareTeamMemberOut] = []
        for assignment in assignments:
            employee = by_id.get(str(assignment.employee_id))
            if employee is None:
                continue  # employee deleted; the row is orphaned
            on_now, next_start, next_end = _shift_state(shifts_by_id.get(str(employee.id), []), now)
            members.append(
                CareTeamMemberOut(
                    assignment_id=assignment.id,
                    employee_id=employee.id,
                    first_name=employee.first_name,
                    last_name=employee.last_name,
                    role=employee.role,
                    assignment_type=assignment.assignment_type,
                    start_date=assignment.start_date,
                    end_date=assignment.end_date,
                    active=assignment.active,
                    on_shift_now=on_now,
                    next_shift_start=next_start,
                    next_shift_end=next_end,
                )
            )

        # Primary first, then secondary, then relief; ended assignments last.
        order = {AssignmentType.PRIMARY: 0, AssignmentType.SECONDARY: 1, AssignmentType.RELIEF: 2}
        members.sort(key=lambda m: (not m.active, order.get(m.assignment_type, 9), m.last_name))

        return CareTeamOut(
            resident_id=resident.id,
            resident_name=f"{resident.first_name} {resident.last_name}",
            members=members,
            has_primary=any(
                m.assignment_type == AssignmentType.PRIMARY and m.active for m in members
            ),
            on_shift_count=sum(1 for m in members if m.on_shift_now and m.active),
        )

    # --- employee -> caseload --------------------------------------------

    async def get_caseload(self, employee_id: str) -> CaseloadOut:
        employee = await self._employee_repository.get_by_id(employee_id)
        if employee is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Employee not found")

        assignments, shifts = await asyncio.gather(
            self._repository.list_for_employee(employee_id),
            self._shift_repository.list_for_parent(employee_id, 0, 200),
        )

        resident_ids = [str(a.resident_id) for a in assignments if a.resident_id]
        residents, scores = await asyncio.gather(
            asyncio.gather(*(self._resident_repository.get_by_id(rid) for rid in resident_ids)),
            asyncio.gather(
                *(self._risk_scoring_service.get_resident_score(rid) for rid in resident_ids)
            ),
        )
        residents_by_id = {str(r.id): r for r in residents if r is not None}
        scores_by_id = {str(s.resident_id): s for s in scores if s is not None}

        rows: list[CaseloadResidentOut] = []
        for assignment in assignments:
            resident = residents_by_id.get(str(assignment.resident_id))
            if resident is None:
                continue
            score = scores_by_id.get(str(resident.id))
            rows.append(
                CaseloadResidentOut(
                    assignment_id=assignment.id,
                    resident_id=resident.id,
                    first_name=resident.first_name,
                    last_name=resident.last_name,
                    room_number=resident.room_number,
                    assignment_type=assignment.assignment_type,
                    start_date=assignment.start_date,
                    active=assignment.active,
                    risk_score=score.score if score else None,
                    risk_band=score.band if score else None,
                )
            )

        # Riskiest residents first: that is the order a carer needs them in.
        rows.sort(key=lambda r: (not r.active, -(r.risk_score or 0)))

        week_key = datetime.now(timezone.utc).isocalendar()[:2]
        hours = sum(
            (s.shift_end - s.shift_start).total_seconds() / 3600
            for s in shifts
            if s.shift_start.isocalendar()[:2] == week_key
        )

        return CaseloadOut(
            employee_id=employee.id,
            employee_name=f"{employee.first_name} {employee.last_name}",
            residents=rows,
            primary_count=sum(
                1 for r in rows if r.active and r.assignment_type == AssignmentType.PRIMARY
            ),
            total_risk_load=sum(r.risk_score or 0 for r in rows if r.active),
            hours_this_week=round(hours, 2),
        )

    # --- facility-wide coverage ------------------------------------------

    async def get_coverage_report(self) -> CoverageReportOut:
        """The whole facility's care teams on one screen.

        Answers, in order: does every resident have a key worker, does every
        resident have a backup, and how evenly is the work spread — one card
        per carer with the residents they hold, heaviest load first.
        """
        residents, employees, assignments = await asyncio.gather(
            self._resident_repository.list_all(0, 1000),
            self._employee_repository.list_all(0, 1000),
            self._repository.list_all(0, 5000, active_only=True),
        )

        active_residents = [r for r in residents if r.active is not False]
        residents_by_id = {str(r.id): r for r in active_residents}
        active_employees = [e for e in employees if e.active]

        carers_by_resident: dict[str, list[ResidentAssignment]] = {}
        by_employee: dict[str, list[ResidentAssignment]] = {}
        for assignment in assignments:
            if str(assignment.resident_id) not in residents_by_id:
                continue  # a discharged resident's rows are not a live caseload
            carers_by_resident.setdefault(str(assignment.resident_id), []).append(assignment)
            if assignment.employee_id:
                by_employee.setdefault(str(assignment.employee_id), []).append(assignment)

        scores = await asyncio.gather(
            *(self._risk_scoring_service.get_resident_score(str(r.id)) for r in active_residents)
        )
        scores_by_id = {str(s.resident_id): s for s in scores if s is not None}

        def has(resident, kind) -> bool:
            return any(a.assignment_type == kind for a in carers_by_resident.get(str(resident.id), []))

        def gap_row(r) -> UnassignedResidentOut:
            score = scores_by_id.get(str(r.id))
            return UnassignedResidentOut(
                resident_id=r.id,
                first_name=r.first_name,
                last_name=r.last_name,
                room_number=r.room_number,
                risk_score=score.score if score else None,
                risk_band=score.band if score else None,
                has_any_carer=bool(carers_by_resident.get(str(r.id))),
            )

        unassigned = [gap_row(r) for r in active_residents if not has(r, AssignmentType.PRIMARY)]
        without_backup = [
            gap_row(r)
            for r in active_residents
            if has(r, AssignmentType.PRIMARY) and not has(r, AssignmentType.SECONDARY)
        ]
        unassigned.sort(key=lambda r: -(r.risk_score or 0))
        without_backup.sort(key=lambda r: -(r.risk_score or 0))

        order = {AssignmentType.PRIMARY: 0, AssignmentType.SECONDARY: 1, AssignmentType.RELIEF: 2}
        teams: list[CarerTeamOut] = []
        for employee in active_employees:
            held = by_employee.get(str(employee.id), [])
            if not held:
                continue
            rows = []
            for a in held:
                r = residents_by_id[str(a.resident_id)]
                score = scores_by_id.get(str(r.id))
                rows.append(
                    TeamResidentOut(
                        assignment_id=a.id,
                        resident_id=r.id,
                        first_name=r.first_name,
                        last_name=r.last_name,
                        room_number=r.room_number,
                        assignment_type=a.assignment_type,
                        start_date=a.start_date,
                        risk_score=score.score if score else None,
                        risk_band=score.band if score else None,
                        notes=a.notes,
                    )
                )
            rows.sort(key=lambda t: (order.get(t.assignment_type, 9), -(t.risk_score or 0)))
            teams.append(
                CarerTeamOut(
                    employee_id=employee.id,
                    first_name=employee.first_name,
                    last_name=employee.last_name,
                    role=employee.role,
                    key_worker_for=sum(1 for t in rows if t.assignment_type == AssignmentType.PRIMARY),
                    backup_for=sum(1 for t in rows if t.assignment_type == AssignmentType.SECONDARY),
                    risk_load=sum(t.risk_score or 0 for t in rows),
                    residents=rows,
                )
            )
        teams.sort(key=lambda t: (-t.risk_load, t.last_name))

        staff_without_caseload = [
            UnloadedEmployeeOut(
                employee_id=e.id, first_name=e.first_name, last_name=e.last_name, role=e.role
            )
            for e in active_employees
            if str(e.id) not in by_employee
        ]

        live = sum(len(v) for v in by_employee.values())
        average = round(live / len(teams), 2) if teams else 0.0

        return CoverageReportOut(
            total_residents=len(active_residents),
            total_active_staff=len(active_employees),
            residents_with_primary=len(active_residents) - len(unassigned),
            residents_without_primary=len(unassigned),
            residents_with_no_carer=sum(1 for r in unassigned if not r.has_any_carer),
            residents_with_backup=sum(1 for r in active_residents if has(r, AssignmentType.SECONDARY)),
            average_caseload=average,
            unassigned=unassigned,
            without_backup=without_backup,
            teams=teams,
            staff_without_caseload=staff_without_caseload,
        )


def _shift_state(
    shifts: list[EmployeeShift], now: datetime
) -> tuple[bool, datetime | None, datetime | None]:
    """Is this person mid-shift, and when is their next one?"""
    on_now = False
    next_shift: EmployeeShift | None = None

    for shift in shifts:
        start = _as_aware(shift.shift_start)
        end = _as_aware(shift.shift_end)
        if start <= now < end:
            on_now = True
        elif start > now and (next_shift is None or start < _as_aware(next_shift.shift_start)):
            next_shift = shift

    if next_shift is None:
        return on_now, None, None
    return on_now, _as_aware(next_shift.shift_start), _as_aware(next_shift.shift_end)


def _as_aware(value: datetime) -> datetime:
    # Same reason as in risk_scoring: some tables were created with a bare
    # `timestamp`, so Supabase can hand back naive datetimes that would
    # explode on comparison with an aware `now`.
    return value if value.tzinfo is not None else value.replace(tzinfo=timezone.utc)


__all__ = ["AssignmentService", "timedelta"]
