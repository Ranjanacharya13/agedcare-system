"""Suggesting who should care for whom.

Same algorithm as the roster optimiser, different problem. There the rows
were shifts; here they are residents who need a primary carer. In both
cases the question is "what is the best complete allocation", not "who is
best for this one row" — and the difference matters for the same reason:
the ideal carer for the highest-risk resident is often also the ideal carer
for the second highest, and whichever is considered first would take them.

Cost model
----------
cost(employee, resident) =
      RISK_LOAD_WEIGHT  * normalised current risk load
    + CASELOAD_WEIGHT   * normalised number of residents already held
    + ACUITY_WEIGHT     * this resident's acuity * (1 - the role's clinical skill)
    + CONTINUITY_WEIGHT * (1 - how well this carer already knows the resident)
    + ROLE_PENALTY      if the employee's job is not a caring role
    + MANAGEMENT_PENALTY if they manage the home (smaller: a last resort)
    + infinity          if they are already assigned to that resident

Weighting risk load above headcount is the same judgement the roster
optimiser makes: three critical residents are a heavier load than six
stable ones, so counting heads alone would quietly pile the difficult
residents onto whoever happens to have a short list.

The acuity term is the one that makes this a matching problem rather than a
sorting problem. Load and caseload describe the carer alone, so on those
two terms the ranking would be identical for every resident — "suggested
carers for Maya" would be the same list as for Gita. Acuity against
clinical skill is a property of the *pair*: a critical resident needs a
nurse and a stable one does not, so when there is one nurse and two
critical residents the allocation has a genuine trade-off to resolve, and
resolving it row by row gets it wrong.

The continuity term is the other pairwise one, and in practice the one that
matters most. A resident with dementia who settles with one carer should not
be handed to a stranger to even out a spreadsheet. "Knows" is measured from
the charts: how many entries this carer has written about this resident in
the last 30 days (sleep, bowel, behaviour, assistance, fall-risk, incidents).
Without it, the cheapest nurse wins every row and the person the resident
actually trusts never appears in the plan.

Nothing here writes. It proposes an allocation and a human accepts it —
deciding who knows a resident well enough to be their key worker is not a
call an arithmetic cost function should be making on its own.
"""

from __future__ import annotations

import asyncio
import math
import time
from datetime import datetime, timedelta, timezone

from supabase import AsyncClient

from backend.algorithms.hungarian import greedy_assignment, solve_assignment
from backend.models.employee import Employee, EmployeeRole
from backend.models.resident_assignment import AssignmentType
from backend.repositories.employee_repository import EmployeeRepository
from backend.repositories.resident_assignment_repository import (
    ResidentAssignmentRepository,
)
from backend.repositories.resident_repository import ResidentRepository
from backend.schemas.carer_suggestion import (
    CarerCandidateOut,
    CarerSuggestionOut,
    SuggestAssignmentsOut,
)
from backend.services.risk_scoring import RiskScoringService

RISK_LOAD_WEIGHT = 1.0
CASELOAD_WEIGHT = 0.5

#: Roles that do not hold a clinical caseload. They are penalised rather
#: than excluded: in a small facility an administrator may genuinely be
#: someone's key worker, and a suggestion the user can override beats a
#: candidate silently missing from the list.
NON_CARING_ROLES = frozenset(
    {EmployeeRole.KITCHEN_STAFF, EmployeeRole.LAUNDRY_STAFF, EmployeeRole.ADMINISTRATOR}
)
ROLE_PENALTY = 3.0

#: Managers can be someone's carer, and in a small home sometimes are, but
#: their day belongs to running the home. A smaller penalty than a
#: non-caring role: a manager is preferred to the kitchen, never to a free
#: carer.
MANAGEMENT_ROLES = frozenset({EmployeeRole.MANAGER})
MANAGEMENT_PENALTY = 1.0

#: How much clinical capability each role brings to a high-acuity resident,
#: in [0, 1]. This is scope of practice, not seniority: a manager sits above
#: a nurse on the org chart and still does not do wound care. Roles absent
#: from the table fall back to UNKNOWN_ROLE_SKILL rather than to zero, so a
#: role added to the enum and forgotten here degrades quietly instead of
#: becoming unassignable.
ROLE_SKILL = {
    EmployeeRole.REGISTERED_NURSE: 1.0,
    EmployeeRole.CARE_PLANNER: 0.7,
    EmployeeRole.CARE_COORDINATOR: 0.6,
    EmployeeRole.MANAGER: 0.4,
    EmployeeRole.ADMINISTRATOR: 0.0,
    EmployeeRole.KITCHEN_STAFF: 0.0,
    EmployeeRole.LAUNDRY_STAFF: 0.0,
}
UNKNOWN_ROLE_SKILL = 0.3

#: Large enough that acuity outranks a load difference — a critical resident
#: should go to the right nurse rather than to the emptiest diary — while a
#: low-acuity resident is nearly indifferent to role, because the term is
#: multiplied by their acuity.
ACUITY_WEIGHT = 1.5

#: Continuity of care: what it costs to give a resident to someone who has
#: not looked after them recently. Scaled down by familiarity, so a carer who
#: has written six or more chart entries about the resident this month pays
#: nothing. Sized to outweigh a moderate difference in load — continuity is
#: worth a somewhat busier carer — but not the acuity term for a critical
#: resident, where clinical scope comes first.
CONTINUITY_WEIGHT = 0.8
FAMILIARITY_LOOKBACK_DAYS = 30
FAMILIARITY_SATURATION = 6

#: Where familiarity is read from: (table, author column, date column).
#: These are the records a carer writes *about a resident*, so a count of
#: them is the nearest thing the system has to "has looked after".
FAMILIARITY_SOURCES = (
    ("resident_sleep_chart", "recorded_by", "sleep_date"),
    ("resident_bowel_chart", "recorded_by", "recorded_at"),
    ("resident_behaviour", "recorded_by", "recorded_at"),
    ("resident_assistance", "updated_by", "updated_at"),
    ("resident_fall_risk", "assessed_by", "assessment_date"),
    ("resident_incidents", "reported_by", "occurred_at"),
)

#: What one resident left without a key worker costs in the greedy
#: comparison. Deliberately far above any pairing cost: no arrangement of
#: carers is worth leaving someone with nobody named. Without this the
#: comparison would be ill-posed, because a method that matches fewer
#: residents has a smaller sum of chosen cells and would look cheaper.
UNMATCHED_RESIDENT_PENALTY = 10.0

#: How many other carers to offer per row when the plan is reviewed. Enough
#: to make a real choice, few enough that the dropdown is still readable.
ALTERNATIVES_PER_RESIDENT = 6

#: Denominators for normalisation, matching roster_optimisation's reasoning:
#: raw risk load is an unbounded sum of 0-100 scores, caseload is a small
#: count, so combining them raw would let risk load dominate entirely.
RISK_LOAD_SATURATION = 400.0
CASELOAD_SATURATION = 8.0
#: Risk scores are already expressed out of 100, so acuity is the score over
#: this. See risk_scoring: the weighted model is bounded at 100 by
#: construction, so no clipping is needed here.
MAX_RISK_SCORE = 100.0


def _full_name(employee: Employee) -> str:
    return f"{employee.first_name} {employee.last_name}"


class ChartFamiliarity:
    """Who has recently written about whom, as {(resident_id, employee_id): n}.

    One query per source table for the whole facility, not one per pair:
    the matrix is built from these counts in memory. Paged, because
    Supabase caps a response at 1000 rows by default and a busy month of
    charting in a larger home would silently lose the tail.
    """

    PAGE = 1000

    def __init__(self, client: AsyncClient):
        self._client = client

    async def counts(self) -> dict[tuple[str, str], int]:
        cutoff = datetime.now(timezone.utc) - timedelta(days=FAMILIARITY_LOOKBACK_DAYS)
        pages = await asyncio.gather(
            *(self._read(table, author, when, cutoff) for table, author, when in FAMILIARITY_SOURCES)
        )
        counts: dict[tuple[str, str], int] = {}
        for rows in pages:
            for resident_id, employee_id in rows:
                counts[(resident_id, employee_id)] = counts.get((resident_id, employee_id), 0) + 1
        return counts

    async def _read(self, table: str, author: str, when: str, cutoff: datetime):
        pairs, start = [], 0
        # A date column compares against a date; a timestamp against the
        # full instant. Sending the timestamp to a date column works in
        # Postgres but reads as "from midnight", which is close enough.
        while True:
            response = await (
                self._client.table(table)
                .select(f"resident_id,{author}")
                .gte(when, cutoff.isoformat())
                .not_.is_(author, "null")
                .range(start, start + self.PAGE - 1)
                .execute()
            )
            pairs.extend((row["resident_id"], row[author]) for row in response.data)
            if len(response.data) < self.PAGE:
                return pairs
            start += self.PAGE


class CarerMatchingService:
    def __init__(self, client: AsyncClient, risk_scoring_service: RiskScoringService):
        self._assignment_repository = ResidentAssignmentRepository(client)
        self._resident_repository = ResidentRepository(client)
        self._employee_repository = EmployeeRepository(client)
        self._risk_scoring_service = risk_scoring_service
        self._familiarity = ChartFamiliarity(client)

    # --- shared state gathering ------------------------------------------

    async def _staff_state(self) -> tuple[list[Employee], dict[str, dict]]:
        """Every active employee, with what they are already carrying."""
        employees, assignments = await asyncio.gather(
            self._employee_repository.list_all(0, 1000),
            self._assignment_repository.list_all(0, 5000, active_only=True),
        )
        active = [e for e in employees if e.active]

        held: dict[str, list[str]] = {}
        for assignment in assignments:
            if assignment.employee_id:
                held.setdefault(str(assignment.employee_id), []).append(
                    str(assignment.resident_id)
                )

        # Score each distinct resident once, not once per carer holding them.
        distinct = {rid for ids in held.values() for rid in ids}
        scored = await asyncio.gather(
            *(self._risk_scoring_service.get_resident_score(rid) for rid in distinct)
        )
        score_by_resident = {
            str(s.resident_id): s.score for s in scored if s is not None
        }

        state = {}
        for employee in active:
            resident_ids = held.get(str(employee.id), [])
            state[str(employee.id)] = {
                "employee": employee,
                "resident_ids": resident_ids,
                "risk_load": sum(score_by_resident.get(rid, 0) for rid in resident_ids),
                "caseload": len(resident_ids),
            }
        return active, state

    @staticmethod
    def _skill(employee: Employee) -> float:
        return ROLE_SKILL.get(employee.role, UNKNOWN_ROLE_SKILL)

    def _cost(
        self,
        staff: dict,
        resident_id: str,
        acuity: float = 0.0,
        familiar_entries: int = 0,
        forbidden: bool | None = None,
    ) -> tuple[float, dict]:
        """What it costs to give this resident to this carer.

        `acuity` is the resident's risk score over 100 — 0 when unknown,
        which makes the pairing term vanish and leaves the decision to load
        alone. That is the right failure mode: an unscored resident should
        not be treated as though a kitchen hand suits them, nor as though
        they are critical.
        """
        employee = staff["employee"]
        # By default anyone already on this resident's team is not a
        # candidate. The allocation passes its own rule instead, because
        # there a backup carer stepping up to key worker is the best
        # outcome, not a conflict.
        if forbidden is None:
            forbidden = resident_id in staff["resident_ids"]
        if forbidden:
            return math.inf, {}

        risk_component = RISK_LOAD_WEIGHT * min(
            staff["risk_load"] / RISK_LOAD_SATURATION, 1.0
        )
        caseload_component = CASELOAD_WEIGHT * min(
            staff["caseload"] / CASELOAD_SATURATION, 1.0
        )
        acuity_component = ACUITY_WEIGHT * acuity * (1.0 - self._skill(employee))
        familiarity = min(familiar_entries / FAMILIARITY_SATURATION, 1.0)
        continuity_component = CONTINUITY_WEIGHT * (1.0 - familiarity)
        if employee.role in NON_CARING_ROLES:
            role_component = ROLE_PENALTY
        elif employee.role in MANAGEMENT_ROLES:
            role_component = MANAGEMENT_PENALTY
        else:
            role_component = 0.0

        total = (
            risk_component
            + caseload_component
            + acuity_component
            + continuity_component
            + role_component
        )
        return total, {
            "risk_load": round(risk_component, 4),
            "caseload": round(caseload_component, 4),
            "acuity": round(acuity_component, 4),
            "continuity": round(continuity_component, 4),
            "familiar_entries": familiar_entries,
            "acuity_raw": round(acuity, 4),
            "role": role_component,
            "skill": self._skill(employee),
        }

    @staticmethod
    def _reason(staff: dict, parts: dict) -> str:
        """Plain-language justification. A suggestion a manager cannot
        interrogate is one they will either rubber-stamp or ignore; both are
        worse than one they can agree or disagree with."""
        bits = []
        # Familiarity first: it is the part of the reason a person checks
        # against what they know ("yes, he does settle with her").
        entries = parts.get("familiar_entries", 0)
        if entries:
            bits.append(f"knows this resident ({entries} chart entries in {FAMILIARITY_LOOKBACK_DAYS} days)")
        else:
            bits.append("has not cared for this resident recently")
        if staff["caseload"] == 0:
            bits.append("holds no residents yet")
        else:
            bits.append(
                f"currently {staff['caseload']} resident(s), risk load {staff['risk_load']}"
            )

        role = staff["employee"].role
        if parts.get("role") and role in MANAGEMENT_ROLES:
            bits.append("manager — only if nobody else suits")
        elif parts.get("role"):
            bits.append("not a clinical role")
        elif role:
            bits.append(str(role))

        # Skill is only worth mentioning for a resident unwell enough for it
        # to have mattered. For a stable resident the term is near zero, and
        # naming it would imply a judgement the model did not make.
        if parts.get("acuity_raw", 0) >= 0.5:
            if parts.get("skill", 1.0) >= 1.0:
                bits.append("full clinical scope for a resident this unwell")
            else:
                bits.append("limited clinical scope for a resident this unwell")
        return "; ".join(bits)

    # --- one resident: a ranked list -------------------------------------

    async def rank_candidates_for_resident(
        self, resident_id: str, limit: int = 5
    ) -> list[CarerCandidateOut]:
        """Who could take this resident, best first.

        Used while adding a single assignment. A ranked list is the right
        shape here — the user is choosing one person and wants to see the
        alternatives, not be handed a single answer.
        """
        (_, state), score, familiar = await asyncio.gather(
            self._staff_state(),
            self._risk_scoring_service.get_resident_score(resident_id),
            self._familiarity.counts(),
        )
        acuity = (score.score / MAX_RISK_SCORE) if score else 0.0

        scored = []
        for staff in state.values():
            entries = familiar.get((str(resident_id), str(staff["employee"].id)), 0)
            cost, parts = self._cost(staff, resident_id, acuity, entries)
            if math.isinf(cost):
                continue  # already assigned to this resident
            scored.append(self._candidate(staff, cost, self._reason(staff, parts)))

        scored.sort(key=lambda c: c.cost)
        return scored[:limit]

    @staticmethod
    def _candidate(staff: dict, cost: float, reason: str) -> CarerCandidateOut:
        return CarerCandidateOut(
            employee_id=staff["employee"].id,
            first_name=staff["employee"].first_name,
            last_name=staff["employee"].last_name,
            role=staff["employee"].role,
            current_caseload=staff["caseload"],
            current_risk_load=staff["risk_load"],
            cost=round(cost, 4),
            reason=reason,
        )

    # --- many residents at once: one optimal allocation -------------------

    async def suggest_assignments(
        self,
        limit: int = 50,
        kind: AssignmentType = AssignmentType.PRIMARY,
        hand_over_from: str | None = None,
    ) -> SuggestAssignmentsOut:
        """Propose a carer for every place on a care team that needs filling.

        Three questions, one method:

        * ``kind=Primary``   — who should be key worker for each resident
          who has none?
        * ``kind=Secondary`` — who should be the backup carer for each
          resident who has none?
        * ``hand_over_from`` — this carer is leaving (or moving wing): who
          takes over each of their residents, as key worker or as backup,
          whichever they were?

        This is where the Hungarian algorithm earns its place, in two ways.
        It balances the whole set rather than each gap in turn, and — the
        part that actually bites — it never strands a resident it could have
        matched. Greedy will: it hands the one remaining eligible carer to
        whichever resident happens to be the cheaper pairing, leaving the
        other with nobody at all. Because the algorithm treats a forbidden
        pair as worse than any real total, it fills as many residents as can
        be filled and only then minimises cost among those allocations.

        More residents than carers
        --------------------------
        The textbook algorithm pairs each row with at most one column, so
        with eleven residents and nine carers it would be forced to hand two
        residents to the kitchen. Real carers hold several residents, so
        each carer is offered as several columns ("slots"). Only as many
        slots as the arithmetic needs — ceil(residents / carers) — and each
        extra slot costs a little more than the one before, so the plan
        still spreads residents evenly and only doubles someone up when
        there is no better option. With fewer residents than carers there is
        one slot each, which is the plain assignment problem.
        """
        residents, (employees, state), familiar, assignments = await asyncio.gather(
            self._resident_repository.list_all(0, 1000),
            self._staff_state(),
            self._familiarity.counts(),
            self._assignment_repository.list_all(0, 5000, active_only=True),
        )
        kind = AssignmentType(kind)

        # Who is on each resident's team right now, and as what.
        team: dict[str, dict[str, AssignmentType]] = {}
        for a in assignments:
            if a.employee_id:
                team.setdefault(str(a.resident_id), {})[str(a.employee_id)] = a.assignment_type

        active_residents = {str(r.id): r for r in residents if r.active is not False}
        leaving: Employee | None = None
        rows: list[_Row] = []
        if hand_over_from:
            leaving = next((e for e in employees if str(e.id) == str(hand_over_from)), None)
            for a in assignments:
                if (
                    str(a.employee_id) == str(hand_over_from)
                    and a.assignment_type in (AssignmentType.PRIMARY, AssignmentType.SECONDARY)
                    and str(a.resident_id) in active_residents
                ):
                    rows.append(_Row(active_residents[str(a.resident_id)], a.assignment_type, a.id))
        else:
            for rid, resident in active_residents.items():
                if kind not in team.get(rid, {}).values():
                    rows.append(_Row(resident, kind, None))
        rows = rows[:limit]

        excluded = str(hand_over_from) if hand_over_from else None
        staff_list = [state[str(e.id)] for e in employees if str(e.id) != excluded]

        def empty() -> SuggestAssignmentsOut:
            return SuggestAssignmentsOut(
                kind=kind,
                hand_over_from_employee_id=leaving.id if leaving else None,
                hand_over_from_name=_full_name(leaving) if leaving else None,
                residents_needing_a_carer=len(rows),
                candidates_considered=len(staff_list),
                suggestions=[],
                greedy_total_cost=0.0,
                optimal_total_cost=0.0,
                improvement_over_greedy=0.0,
                unmatched_penalty=UNMATCHED_RESIDENT_PENALTY,
                solve_ms=0.0,
            )

        if not rows or not staff_list:
            return empty()

        # Most urgent first: key-worker places before backups, then by risk.
        # The allocation itself is order-independent — that is the point —
        # but the output should lead with what matters most.
        scores = await asyncio.gather(
            *(self._risk_scoring_service.get_resident_score(str(r.resident.id)) for r in rows)
        )
        score_by_id = {str(s.resident_id): s for s in scores if s is not None}

        def risk(row: _Row) -> int:
            score = score_by_id.get(str(row.resident.id))
            return score.score if score else 0

        rows.sort(key=lambda r: (r.kind != AssignmentType.PRIMARY, -risk(r)))

        # One cost per (row, carer). The forbidden pairs depend on the kind
        # of place being filled: a backup may step up to key worker, but
        # nobody can be a resident's backup while already on their team.
        base: list[list[float]] = []
        parts_matrix: list[list[dict]] = []
        for row in rows:
            rid = str(row.resident.id)
            current = team.get(rid, {})
            acuity = risk(row) / MAX_RISK_SCORE
            cost_row, parts_row = [], []
            for staff in staff_list:
                eid = str(staff["employee"].id)
                if row.kind == AssignmentType.PRIMARY:
                    forbidden = current.get(eid) == AssignmentType.PRIMARY
                else:
                    forbidden = current.get(eid) in (AssignmentType.PRIMARY, AssignmentType.SECONDARY)
                entries = familiar.get((rid, eid), 0)
                cost, parts = self._cost(staff, rid, acuity, entries, forbidden=forbidden)
                cost_row.append(cost)
                parts_row.append(parts)
            base.append(cost_row)
            parts_matrix.append(parts_row)

        # Slots: see the docstring. The step is what one more resident adds
        # to a carer's own load terms, using the average risk of the
        # residents being placed.
        caring = sum(
            1
            for s in staff_list
            if s["employee"].role not in NON_CARING_ROLES | MANAGEMENT_ROLES
        )
        slots = max(1, math.ceil(len(rows) / max(caring, 1)))
        mean_risk = sum(risk(r) for r in rows) / len(rows)
        slot_step = (
            CASELOAD_WEIGHT / CASELOAD_SATURATION
            + RISK_LOAD_WEIGHT * mean_risk / RISK_LOAD_SATURATION
        )
        n_staff = len(staff_list)
        expanded = [
            [cost + slot * slot_step for slot in range(slots) for cost in cost_row]
            for cost_row in base
        ]

        started = time.perf_counter()
        optimal = solve_assignment(expanded)
        greedy = greedy_assignment(expanded)
        solve_ms = (time.perf_counter() - started) * 1000

        suggestions = []
        for index, row in enumerate(rows):
            resident = row.resident
            score = score_by_id.get(str(resident.id))
            greedy_column = greedy.rows_to_cols[index]
            greedy_staff = (
                staff_list[greedy_column % n_staff]["employee"] if greedy_column is not None else None
            )
            common = {
                "resident_id": resident.id,
                "first_name": resident.first_name,
                "last_name": resident.last_name,
                "room_number": resident.room_number,
                "risk_score": score.score if score else None,
                "risk_band": score.band if score else None,
                "assignment_type": row.kind,
                "replaces_assignment_id": row.replaces,
                "one_at_a_time_employee_id": greedy_staff.id if greedy_staff else None,
                "one_at_a_time_employee_name": _full_name(greedy_staff) if greedy_staff else None,
                # Everyone this resident could have had, so the row can be
                # changed in place. Forbidden pairs are dropped rather than
                # shown greyed out: they are not choices.
                "alternatives": sorted(
                    (
                        self._candidate(
                            staff_list[col],
                            base[index][col],
                            self._reason(staff_list[col], parts_matrix[index][col]),
                        )
                        for col in range(n_staff)
                        if not math.isinf(base[index][col])
                    ),
                    key=lambda candidate: candidate.cost,
                )[:ALTERNATIVES_PER_RESIDENT],
            }

            column = optimal.rows_to_cols[index]
            if column is None or math.isinf(expanded[index][column]):
                suggestions.append(
                    CarerSuggestionOut(reason="No available staff member could be matched", **common)
                )
                continue

            staff = staff_list[column % n_staff]
            suggestions.append(
                CarerSuggestionOut(
                    employee_id=staff["employee"].id,
                    employee_name=_full_name(staff["employee"]),
                    employee_role=staff["employee"].role,
                    cost=round(base[index][column % n_staff], 4),
                    reason=self._reason(staff, parts_matrix[index][column % n_staff]),
                    **common,
                )
            )

        # Include the penalty for anyone left unmatched, so the two numbers
        # are comparable. Without it the method that abandons a resident wins.
        unmatched_optimal = len(rows) - optimal.assigned_count
        unmatched_greedy = len(rows) - greedy.assigned_count
        optimal_total = optimal.total_cost + unmatched_optimal * UNMATCHED_RESIDENT_PENALTY
        greedy_total = greedy.total_cost + unmatched_greedy * UNMATCHED_RESIDENT_PENALTY

        return SuggestAssignmentsOut(
            kind=kind,
            hand_over_from_employee_id=leaving.id if leaving else None,
            hand_over_from_name=_full_name(leaving) if leaving else None,
            residents_needing_a_carer=len(rows),
            candidates_considered=n_staff,
            max_new_per_carer=slots,
            suggestions=suggestions,
            greedy_total_cost=round(greedy_total, 4),
            optimal_total_cost=round(optimal_total, 4),
            improvement_over_greedy=round(greedy_total - optimal_total, 4),
            unmatched_optimal=unmatched_optimal,
            unmatched_greedy=unmatched_greedy,
            unmatched_penalty=UNMATCHED_RESIDENT_PENALTY,
            solve_ms=round(solve_ms, 3),
        )


class _Row:
    """One place on a care team that needs a person."""

    __slots__ = ("resident", "kind", "replaces")

    def __init__(self, resident, kind: AssignmentType, replaces):
        self.resident = resident
        self.kind = kind
        #: The assignment this row takes over, during a hand-over.
        self.replaces = replaces
