"""Summaries for the screens people scan: the resident list, the staff list,
and the dashboard.

Each method reads a handful of whole tables concurrently and joins them in
memory. That is deliberate for a care home — a few dozen residents, a few
dozen staff — where one round of parallel queries beats both a request per
row from the browser and a set of bespoke SQL views that would need their
own migrations.
"""

from __future__ import annotations

import asyncio
from datetime import date, datetime, timedelta, timezone

from supabase import AsyncClient

from backend.config.permissions import can
from backend.models.user import AccessRole
from backend.repositories.employee_repository import EmployeeRepository
from backend.repositories.resident_repository import ResidentRepository
from backend.schemas.overview import (
    AttentionItem,
    DashboardSummaryOut,
    ResidentSummaryOut,
    StaffSummaryOut,
)
from backend.services.risk_scoring import RiskScoringService

#: How far ahead a credential expiry becomes something to act on. Nepal
#: Nursing Council renewals take weeks, so a month's notice is not enough.
CREDENTIAL_WARNING_DAYS = 60
SUPPLY_WARNING_DAYS = 30
OPEN_SHIFT_HORIZON_DAYS = 14
CONTRACT_WARNING_DAYS = 30

_SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2}


def _parse(value) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        parsed = value
    else:
        text = str(value)
        parsed = datetime.fromisoformat(text) if "T" in text or " " in text else datetime.fromisoformat(text + "T00:00:00")
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _as_date(value) -> date | None:
    if value is None:
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    return _parse(value).date()


def _age(dob: date | None, today: date) -> int | None:
    if dob is None:
        return None
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


def _name(person) -> str:
    return f"{person.first_name} {person.last_name}"


def _days_phrase(days: int) -> str:
    if days < 0:
        return f"expired {-days} day{'s' if days != -1 else ''} ago"
    if days == 0:
        return "expires today"
    return f"expires in {days} day{'s' if days != 1 else ''}"


class OverviewService:
    def __init__(self, client: AsyncClient, risk_scoring_service: RiskScoringService):
        self._client = client
        self._risk = risk_scoring_service
        self._residents = ResidentRepository(client)
        self._employees = EmployeeRepository(client)

    async def _rows(self, table: str, columns: str = "*") -> list[dict]:
        response = await self._client.table(table).select(columns).range(0, 4999).execute()
        return response.data

    # --- residents -----------------------------------------------------------

    async def resident_summaries(self) -> list[ResidentSummaryOut]:
        residents, scores, assignments, employees, meds, incidents = await asyncio.gather(
            self._residents.list_all(0, 1000),
            self._risk.list_scores(0, 1000),
            self._rows("resident_assignments", "resident_id,employee_id,assignment_type,active"),
            self._employees.list_all(0, 1000),
            self._rows("resident_medications", "resident_id,active"),
            self._rows("resident_incidents", "resident_id,status"),
        )
        today = date.today()
        score_by = {str(s.resident_id): s for s in scores}
        staff_by = {str(e.id): e for e in employees}

        team: dict[str, list[dict]] = {}
        for row in assignments:
            if row.get("active"):
                team.setdefault(str(row["resident_id"]), []).append(row)

        med_count: dict[str, int] = {}
        for row in meds:
            if row.get("active") is not False:
                key = str(row["resident_id"])
                med_count[key] = med_count.get(key, 0) + 1

        open_count: dict[str, int] = {}
        for row in incidents:
            if row.get("status") != "Closed":
                key = str(row["resident_id"])
                open_count[key] = open_count.get(key, 0) + 1

        out = []
        for resident in residents:
            key = str(resident.id)
            members = team.get(key, [])
            primary = next((m for m in members if m["assignment_type"] == "Primary"), None)
            carer = staff_by.get(str(primary["employee_id"])) if primary else None
            score = score_by.get(key)
            out.append(
                ResidentSummaryOut(
                    id=resident.id,
                    first_name=resident.first_name,
                    last_name=resident.last_name,
                    room_number=resident.room_number,
                    age=_age(resident.dob, today),
                    gender=resident.gender,
                    cognitive_status=str(resident.cognitive_status) if resident.cognitive_status else None,
                    admission_date=resident.admission_date,
                    active=resident.active is not False,
                    risk_score=score.score if score else None,
                    risk_band=score.band if score else None,
                    primary_carer_id=carer.id if carer else None,
                    primary_carer_name=_name(carer) if carer else None,
                    care_team_size=len(members),
                    active_medications=med_count.get(key, 0),
                    open_incidents=open_count.get(key, 0),
                )
            )
        out.sort(key=lambda r: (r.room_number or "zzz", r.last_name))
        return out

    # --- staff ---------------------------------------------------------------

    async def staff_summaries(self) -> list[StaffSummaryOut]:
        now = datetime.now(timezone.utc)
        week_start = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
        week_end = week_start + timedelta(days=7)

        employees, assignments, scores, shifts = await asyncio.gather(
            self._employees.list_all(0, 1000),
            self._rows("resident_assignments", "resident_id,employee_id,assignment_type,active"),
            self._risk.list_scores(0, 1000),
            self._client.table("employee_shifts")
            .select("employee_id,shift_start,shift_end,status")
            .gte("shift_end", (week_start - timedelta(days=1)).isoformat())
            .range(0, 4999)
            .execute(),
        )
        score_by = {str(s.resident_id): s.score for s in scores}

        caseload: dict[str, set] = {}
        primaries: dict[str, int] = {}
        for row in assignments:
            if not row.get("active") or not row.get("employee_id"):
                continue
            key = str(row["employee_id"])
            caseload.setdefault(key, set()).add(str(row["resident_id"]))
            if row["assignment_type"] == "Primary":
                primaries[key] = primaries.get(key, 0) + 1

        hours: dict[str, float] = {}
        upcoming: dict[str, datetime] = {}
        on_now: set[str] = set()
        for row in shifts.data:
            if not row.get("employee_id") or row.get("status") == "Cancelled":
                continue
            key = str(row["employee_id"])
            start, end = _parse(row["shift_start"]), _parse(row["shift_end"])
            if week_start <= start < week_end:
                hours[key] = hours.get(key, 0.0) + (end - start).total_seconds() / 3600
            if start <= now < end:
                on_now.add(key)
            elif start > now and (key not in upcoming or start < upcoming[key]):
                upcoming[key] = start

        out = []
        for employee in employees:
            key = str(employee.id)
            held = caseload.get(key, set())
            out.append(
                StaffSummaryOut(
                    id=employee.id,
                    first_name=employee.first_name,
                    last_name=employee.last_name,
                    role=str(employee.role) if employee.role else None,
                    employment_status=str(employee.employment_status) if employee.employment_status else None,
                    active=employee.active is not False,
                    phone=employee.phone,
                    email=employee.email,
                    caseload=len(held),
                    primary_for=primaries.get(key, 0),
                    risk_load=sum(score_by.get(r, 0) for r in held),
                    hours_this_week=round(hours.get(key, 0.0), 1),
                    next_shift_start=upcoming.get(key),
                    on_shift_now=key in on_now,
                )
            )
        out.sort(key=lambda s: (not s.active, s.first_name, s.last_name))
        return out

    # --- dashboard -----------------------------------------------------------

    async def dashboard(self, role: AccessRole) -> DashboardSummaryOut:
        """Counts and a to-do list, restricted to what this role may read.

        A tile the user is not allowed to see is left out (None), not shown
        as zero: "0 open complaints" to a care worker would be a claim about
        data they have no access to.
        """
        allowed = lambda group: can(role, group, "GET")  # noqa: E731
        today = date.today()
        now = datetime.now(timezone.utc)

        residents, scores, employees, assignments, incidents, shifts = await asyncio.gather(
            self._residents.list_all(0, 1000),
            self._risk.list_scores(0, 1000),
            self._employees.list_all(0, 1000),
            self._rows("resident_assignments", "resident_id,employee_id,assignment_type,active"),
            self._rows("resident_incidents",
                       "id,resident_id,incident_type,severity,status,occurred_at"),
            self._client.table("employee_shifts")
            .select("id,employee_id,shift_start,shift_end,status")
            .gte("shift_end", now.isoformat())
            .lte("shift_start", (now + timedelta(days=OPEN_SHIFT_HORIZON_DAYS)).isoformat())
            .range(0, 4999)
            .execute(),
        )
        resident_by = {str(r.id): r for r in residents}
        employee_by = {str(e.id): e for e in employees}
        summary = DashboardSummaryOut(
            residents_total=sum(1 for r in residents if r.active is not False),
            staff_active=sum(1 for e in employees if e.active is not False),
        )
        attention: list[AttentionItem] = []

        bands: dict[str, int] = {}
        band_by = {}
        for score in scores:
            bands[score.band] = bands.get(score.band, 0) + 1
            band_by[str(score.resident_id)] = score
        summary.residents_by_band = bands

        # --- coverage
        if allowed("assignments"):
            with_primary = {
                str(a["resident_id"]) for a in assignments
                if a.get("active") and a.get("assignment_type") == "Primary"
            }
            gaps = [r for r in residents if r.active is not False and str(r.id) not in with_primary]
            summary.residents_without_primary = len(gaps)
            for resident in sorted(gaps, key=lambda r: -(band_by[str(r.id)].score if str(r.id) in band_by else 0)):
                score = band_by.get(str(resident.id))
                urgent = score is not None and score.band in ("Critical", "High")
                attention.append(AttentionItem(
                    kind="coverage",
                    severity="high" if urgent else "medium",
                    title=f"{_name(resident)} has no primary carer",
                    detail=(f"{score.band} risk ({score.score}) · room {resident.room_number}"
                            if score else f"Room {resident.room_number}"),
                    link="/admin/coverage",
                ))

            with_backup = {
                str(a["resident_id"]) for a in assignments
                if a.get("active") and a.get("assignment_type") == "Secondary"
            }
            no_backup = [
                r for r in residents
                if r.active is not False and str(r.id) in with_primary and str(r.id) not in with_backup
            ]
            if no_backup:
                attention.append(AttentionItem(
                    kind="coverage",
                    severity="low",
                    title=f"{len(no_backup)} resident{'s have' if len(no_backup) != 1 else ' has'} no backup carer",
                    detail="Care teams can suggest who should cover for each key worker.",
                    link="/admin/coverage",
                ))

        # --- contracts ending: a carer leaving takes their residents with them
        if allowed("assignments") and allowed("employee_hr"):
            contracts = await self._rows("employee_contracts", "employee_id,contract_type,end_date")
            holding: dict[str, int] = {}
            for a in assignments:
                if a.get("active") and a.get("employee_id"):
                    holding[str(a["employee_id"])] = holding.get(str(a["employee_id"]), 0) + 1
            for contract in contracts:
                end = _as_date(contract.get("end_date"))
                employee = employee_by.get(str(contract["employee_id"]))
                count = holding.get(str(contract["employee_id"]), 0)
                if end is None or employee is None or not count:
                    continue
                days = (end - today).days
                if 0 <= days <= CONTRACT_WARNING_DAYS:
                    attention.append(AttentionItem(
                        kind="handover",
                        severity="medium",
                        title=f"{_name(employee)} leaves in {days} day{'s' if days != 1 else ''} — "
                              f"{count} resident{'s' if count != 1 else ''} to hand over",
                        detail=f"{contract.get('contract_type') or 'Contract'} ends {end:%d %b}. "
                               "Care teams will suggest who takes over each one.",
                        link=f"/admin/coverage?handover={employee.id}",
                    ))

        # --- who is working
        if allowed("employee_roster"):
            summary.staff_on_shift_now = len({
                str(s["employee_id"]) for s in shifts.data
                if s.get("employee_id") and s.get("status") != "Cancelled"
                and _parse(s["shift_start"]) <= now < _parse(s["shift_end"])
            })
        if allowed("roster_planning"):
            open_shifts = [s for s in shifts.data if not s.get("employee_id") and s.get("status") != "Cancelled"]
            summary.open_shifts_next_14_days = len(open_shifts)
            if open_shifts:
                first = min(_parse(s["shift_start"]) for s in open_shifts)
                monday = (first - timedelta(days=first.weekday())).date()
                attention.append(AttentionItem(
                    kind="roster",
                    severity="medium",
                    title=f"{len(open_shifts)} open shift{'s' if len(open_shifts) != 1 else ''} in the next two weeks",
                    detail="Nobody is rostered yet — the Roster page can suggest who should take them.",
                    link=f"/admin/roster?week={monday.isoformat()}",
                ))

        # --- incidents
        if allowed("resident_charts"):
            open_incidents = [i for i in incidents if i.get("status") != "Closed"]
            summary.open_incidents = len(open_incidents)
            for incident in sorted(open_incidents, key=lambda i: i.get("occurred_at") or "", reverse=True):
                if incident.get("severity") not in ("High", "Critical"):
                    continue
                resident = resident_by.get(str(incident["resident_id"]))
                if resident is None:
                    continue
                days = (now - _parse(incident["occurred_at"])).days
                attention.append(AttentionItem(
                    kind="incident",
                    severity="high",
                    title=f"{incident['incident_type']} — {_name(resident)}",
                    detail=f"{incident['severity']} severity · {incident['status']} · {days} day{'s' if days != 1 else ''} ago",
                    link=f"/admin/residents/{resident.id}/incidents",
                ))

        # --- supplies (clinical)
        if allowed("resident_clinical"):
            supplies = await self._rows("resident_medical_inventory", "resident_id,item_name,expiry_date")
            for item in supplies:
                expiry = _as_date(item.get("expiry_date"))
                if expiry is None:
                    continue
                days = (expiry - today).days
                resident = resident_by.get(str(item["resident_id"]))
                if days <= SUPPLY_WARNING_DAYS and resident is not None:
                    attention.append(AttentionItem(
                        kind="supplies",
                        severity="medium" if days <= 7 else "low",
                        title=f"{item['item_name']} for {_name(resident)} — {_days_phrase(days)}",
                        link=f"/admin/residents/{resident.id}/medical-inventory",
                    ))

        # --- HR: credentials and leave
        if allowed("employee_hr"):
            registrations, qualifications, leave = await asyncio.gather(
                self._rows("employee_registration", "employee_id,registration_type,expiry_date"),
                self._rows("employee_qualifications", "employee_id,qualification_name,expiry_date"),
                self._rows("employee_leave", "employee_id,leave_type,start_date,status"),
            )
            expiring = 0
            for rows, label, slug in (
                (registrations, "registration_type", "registration"),
                (qualifications, "qualification_name", "qualifications"),
            ):
                for row in rows:
                    expiry = _as_date(row.get("expiry_date"))
                    employee = employee_by.get(str(row["employee_id"]))
                    if expiry is None or employee is None:
                        continue
                    days = (expiry - today).days
                    if days <= CREDENTIAL_WARNING_DAYS:
                        expiring += 1
                        attention.append(AttentionItem(
                            kind="credential",
                            severity="high" if days < 0 else "medium",
                            title=f"{_name(employee)} — {row[label]} {_days_phrase(days)}",
                            link=f"/admin/employees/{employee.id}/{slug}",
                        ))
            summary.expiring_credentials = expiring

            pending = [row for row in leave if row.get("status") == "Pending"]
            summary.pending_leave = len(pending)
            for row in pending:
                employee = employee_by.get(str(row["employee_id"]))
                if employee:
                    attention.append(AttentionItem(
                        kind="leave",
                        severity="low",
                        title=f"{_name(employee)} — {row['leave_type']} awaiting approval",
                        detail=f"From {_as_date(row['start_date']):%d %b}",
                        link=f"/admin/employees/{employee.id}/leave",
                    ))

        # --- front desk
        if allowed("complaints"):
            complaints = await self._rows("complaints_feedback", "status,category")
            open_complaints = [c for c in complaints if c.get("status") in ("Open", "Investigating")]
            summary.open_complaints = len(open_complaints)
            if open_complaints:
                attention.append(AttentionItem(
                    kind="complaint",
                    severity="medium",
                    title=f"{len(open_complaints)} complaint{'s' if len(open_complaints) != 1 else ''} still open",
                    link="/admin/complaints",
                ))
        if allowed("appointments"):
            appointments = await self._rows("appointments", "status")
            pending_appointments = sum(1 for a in appointments if a.get("status") == "Pending")
            summary.pending_appointments = pending_appointments
            if pending_appointments:
                attention.append(AttentionItem(
                    kind="appointment",
                    severity="low",
                    title=f"{pending_appointments} enquir{'ies' if pending_appointments != 1 else 'y'} waiting for a reply",
                    link="/admin/appointments",
                ))

        attention.sort(key=lambda item: _SEVERITY_ORDER[item.severity])
        summary.attention = attention
        return summary
