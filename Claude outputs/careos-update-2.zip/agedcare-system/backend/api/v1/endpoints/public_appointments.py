"""The one endpoint anyone on the internet may call.

Kept in its own module, with its own schema, so the public attack surface is
a single file you can read end to end. The admin routes in `appointments.py`
sit behind auth and are not reachable from the landing page.
"""

import logging

from fastapi import APIRouter, Depends, Request, status
from pydantic import BaseModel, Field

from backend.api.deps import get_appointment_service
from backend.config.settings import get_settings
from backend.core.rate_limit import (
    SlidingWindowLimiter,
    client_ip,
    rate_limit_dependency,
)
from backend.schemas.appointment import AppointmentCreate
from backend.services.appointment_service import AppointmentService

logger = logging.getLogger(__name__)

_settings = get_settings()
_limiter = SlidingWindowLimiter(
    max_requests=_settings.public_form_rate_limit,
    window_seconds=_settings.public_form_rate_window_seconds,
)

router = APIRouter(dependencies=[Depends(rate_limit_dependency(_limiter))])


class PublicAppointmentRequest(AppointmentCreate):
    """The publicly submittable fields, plus a honeypot.

    `website` is rendered off-screen and left blank by humans; bots fill every
    input they find. It is only on this schema, never on the admin one, so the
    admin form config cannot accidentally surface it.
    """

    website: str | None = Field(default=None, max_length=200)


class PublicAppointmentAck(BaseModel):
    """Deliberately thin. The public caller learns that the request was
    received and nothing else — no id, no status — so this endpoint cannot be
    used to enumerate or confirm stored records."""

    received: bool = True
    message: str = "Thanks — we'll be in touch within one business day."


@router.post(
    "/public",
    response_model=PublicAppointmentAck,
    status_code=status.HTTP_201_CREATED,
    summary="Submit an appointment enquiry (public, rate limited)",
)
async def submit_public_appointment(
    payload: PublicAppointmentRequest,
    request: Request,
    service: AppointmentService = Depends(get_appointment_service),
):
    if payload.website:
        # Answer exactly as if it worked. Telling a bot it was caught only
        # teaches whoever wrote it to leave the field alone next time.
        logger.info("Discarded honeypot appointment submission from %s", client_ip(request))
        return PublicAppointmentAck()

    data = AppointmentCreate(**payload.model_dump(exclude={"website"}))
    await service.create_appointment(data)
    return PublicAppointmentAck()
