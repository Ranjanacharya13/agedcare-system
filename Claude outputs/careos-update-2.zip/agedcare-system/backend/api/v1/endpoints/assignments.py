from fastapi import APIRouter, Depends, status

from backend.api.deps import get_assignment_service
from backend.schemas.resident_assignment import (
    AssignmentCreate,
    AssignmentOut,
    AssignmentUpdate,
    BulkAssignmentIn,
    BulkAssignmentOut,
    CareTeamOut,
    CaseloadOut,
    CoverageReportOut,
    HandOverIn,
)
from backend.services.assignment_service import AssignmentService

#: Resident-scoped CRUD: /residents/{id}/assignments
router = APIRouter()

#: Cross-cutting read-only views that do not hang off a single parent.
views_router = APIRouter()


@router.post("", response_model=AssignmentOut, status_code=status.HTTP_201_CREATED)
async def assign_employee(
    resident_id: str,
    data: AssignmentCreate,
    service: AssignmentService = Depends(get_assignment_service),
):
    """Assign a staff member to a resident as primary, secondary or relief."""
    return await service.create_assignment(resident_id, data)


@router.get("", response_model=list[AssignmentOut])
async def list_assignments(
    resident_id: str, service: AssignmentService = Depends(get_assignment_service)
):
    return await service.list_for_resident(resident_id)


@router.patch("/{assignment_id}", response_model=AssignmentOut)
async def update_assignment(
    resident_id: str,
    assignment_id: str,
    data: AssignmentUpdate,
    service: AssignmentService = Depends(get_assignment_service),
):
    return await service.update_assignment(resident_id, assignment_id, data)


@router.delete("/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_assignment(
    resident_id: str,
    assignment_id: str,
    service: AssignmentService = Depends(get_assignment_service),
):
    await service.delete_assignment(resident_id, assignment_id)


# --- enriched views ------------------------------------------------------


@views_router.get("/residents/{resident_id}/care-team", response_model=CareTeamOut)
async def get_care_team(
    resident_id: str, service: AssignmentService = Depends(get_assignment_service)
):
    """Who looks after this resident, and which of them is on shift now."""
    return await service.get_care_team(resident_id)


@views_router.get("/employees/{employee_id}/caseload", response_model=CaseloadOut)
async def get_caseload(
    employee_id: str, service: AssignmentService = Depends(get_assignment_service)
):
    """Which residents this employee is responsible for, riskiest first."""
    return await service.get_caseload(employee_id)


@views_router.get("/coverage", response_model=CoverageReportOut)
async def get_coverage_report(
    service: AssignmentService = Depends(get_assignment_service),
):
    """Facility-wide staffing gaps: residents with no named key worker,
    highest risk first, and staff carrying no caseload at all."""
    return await service.get_coverage_report()


@views_router.post("/coverage/assignments", response_model=BulkAssignmentOut)
async def create_assignments_in_bulk(
    payload: BulkAssignmentIn,
    service: AssignmentService = Depends(get_assignment_service),
):
    """Confirm a set of assignments in one action.

    This is where a suggested allocation becomes real. The suggestion
    endpoint proposes and writes nothing; this takes whatever the user
    actually approved — which may not be what was proposed — and creates it.

    Always 200, never partial-failure-as-error: the body reports what was
    created and what was rejected, because "4 created, 1 rejected because
    that resident now has a primary carer" is an outcome the user can act
    on, and a 409 for the whole batch is not.
    """
    return await service.create_many(payload.assignments)


@views_router.post("/coverage/hand-over", response_model=BulkAssignmentOut)
async def hand_over(
    payload: HandOverIn,
    service: AssignmentService = Depends(get_assignment_service),
):
    """Move a departing carer's residents to the people chosen for them.

    Each line closes the old assignment (kept as history) and starts the new
    one in the same place. Reported line by line, like the bulk confirm.
    """
    return await service.hand_over(str(payload.from_employee_id), payload.assignments)
