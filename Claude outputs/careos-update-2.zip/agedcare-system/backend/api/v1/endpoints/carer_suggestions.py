from fastapi import APIRouter, Depends, Query

from backend.api.deps import get_carer_matching_service
from backend.models.resident_assignment import AssignmentType
from backend.schemas.carer_suggestion import CarerCandidateOut, SuggestAssignmentsOut
from backend.services.carer_matching import CarerMatchingService

router = APIRouter()


@router.get("/residents/{resident_id}/suggested-carers", response_model=list[CarerCandidateOut])
async def suggested_carers(
    resident_id: str,
    limit: int = Query(default=5, ge=1, le=20),
    service: CarerMatchingService = Depends(get_carer_matching_service),
):
    """Who could take this resident, best first.

    Called while adding a single assignment, so the user sees the ranking
    and the reasoning rather than a bare dropdown of every employee.
    """
    return await service.rank_candidates_for_resident(resident_id, limit)


@router.post("/coverage/suggest-assignments", response_model=SuggestAssignmentsOut)
async def suggest_assignments(
    limit: int = Query(default=50, ge=1, le=200),
    kind: AssignmentType = Query(default=AssignmentType.PRIMARY),
    hand_over_from: str | None = Query(default=None),
    service: CarerMatchingService = Depends(get_carer_matching_service),
):
    """Propose carers for a set of places, allocating the whole set at once
    (Hungarian algorithm) rather than filling each gap independently.

    * `kind=Primary` (default): a key worker for every resident without one.
    * `kind=Secondary`: a backup carer for every resident without one.
    * `hand_over_from=<employee id>`: who takes over each resident that
      employee currently holds, as key worker or backup — for when they
      leave, change wing or go on long leave.

    Suggests only — nothing is written.
    """
    return await service.suggest_assignments(limit, kind=kind, hand_over_from=hand_over_from)
